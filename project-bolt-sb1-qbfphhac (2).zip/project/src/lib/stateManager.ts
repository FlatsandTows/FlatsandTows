// Centralized State Management & Synchronization
import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface AppState {
  // User state
  user: any | null
  profile: any | null
  isAuthenticated: boolean
  
  // App state
  currentView: string
  isLoading: boolean
  error: string | null
  
  // Job state
  activeJob: any | null
  jobHistory: any[]
  
  // Location state
  userLocation: { lat: number; lng: number } | null
  nearbyInstallers: any[]
  
  // UI state
  showMobileMenu: boolean
  showAIChatbot: boolean
  
  // Actions
  setUser: (user: any) => void
  setProfile: (profile: any) => void
  setCurrentView: (view: string) => void
  setLoading: (loading: boolean) => void
  setError: (error: string | null) => void
  setActiveJob: (job: any) => void
  addToJobHistory: (job: any) => void
  setUserLocation: (location: { lat: number; lng: number } | null) => void
  setNearbyInstallers: (installers: any[]) => void
  toggleMobileMenu: () => void
  toggleAIChatbot: () => void
  clearError: () => void
  reset: () => void
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Initial state
      user: null,
      profile: null,
      isAuthenticated: false,
      currentView: 'home',
      isLoading: false,
      error: null,
      activeJob: null,
      jobHistory: [],
      userLocation: null,
      nearbyInstallers: [],
      showMobileMenu: false,
      showAIChatbot: false,

      // Actions
      setUser: (user) => set({ user, isAuthenticated: !!user }),
      setProfile: (profile) => set({ profile }),
      setCurrentView: (view) => set({ currentView: view, showMobileMenu: false }),
      setLoading: (loading) => set({ isLoading: loading }),
      setError: (error) => set({ error }),
      setActiveJob: (job) => set({ activeJob: job }),
      addToJobHistory: (job) => set((state) => ({ 
        jobHistory: [job, ...state.jobHistory.slice(0, 49)] // Keep last 50 jobs
      })),
      setUserLocation: (location) => set({ userLocation: location }),
      setNearbyInstallers: (installers) => set({ nearbyInstallers: installers }),
      toggleMobileMenu: () => set((state) => ({ showMobileMenu: !state.showMobileMenu })),
      toggleAIChatbot: () => set((state) => ({ showAIChatbot: !state.showAIChatbot })),
      clearError: () => set({ error: null }),
      reset: () => set({
        user: null,
        profile: null,
        isAuthenticated: false,
        currentView: 'home',
        isLoading: false,
        error: null,
        activeJob: null,
        userLocation: null,
        nearbyInstallers: [],
        showMobileMenu: false,
        showAIChatbot: false
      })
    }),
    {
      name: 'flats-tows-storage',
      partialize: (state) => ({
        // Only persist essential data
        jobHistory: state.jobHistory,
        userLocation: state.userLocation,
        currentView: state.currentView
      })
    }
  )
)

// Selectors for optimized re-renders
export const useUser = () => useAppStore((state) => state.user)
export const useProfile = () => useAppStore((state) => state.profile)
export const useIsAuthenticated = () => useAppStore((state) => state.isAuthenticated)
export const useCurrentView = () => useAppStore((state) => state.currentView)
export const useIsLoading = () => useAppStore((state) => state.isLoading)
export const useError = () => useAppStore((state) => state.error)
export const useActiveJob = () => useAppStore((state) => state.activeJob)
export const useJobHistory = () => useAppStore((state) => state.jobHistory)
export const useUserLocation = () => useAppStore((state) => state.userLocation)
export const useNearbyInstallers = () => useAppStore((state) => state.nearbyInstallers)