import { loadStripe, Stripe } from '@stripe/stripe-js'

const stripePublishableKey = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY

if (!stripePublishableKey) {
  throw new Error('Missing Stripe publishable key')
}

// Initialize Stripe lazily to avoid top-level await
let stripePromise: Promise<Stripe | null> | null = null

export const getStripe = (): Promise<Stripe | null> => {
  if (!stripePromise) {
    stripePromise = loadStripe(stripePublishableKey)
  }
  return stripePromise
}

// Stripe payment processing functions
export const createPaymentIntent = async (amount: number, jobId: string) => {
  const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-payment-intent`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      amount: Math.round(amount * 100), // Convert to cents
      jobId,
      currency: 'usd'
    })
  })

  if (!response.ok) {
    throw new Error('Failed to create payment intent')
  }

  return response.json()
}

export const confirmPayment = async (paymentIntentId: string, paymentMethodId: string) => {
  const stripe = await getStripe()
  if (!stripe) throw new Error('Stripe not loaded')

  const { error, paymentIntent } = await stripe.confirmCardPayment(paymentIntentId, {
    payment_method: paymentMethodId
  })

  if (error) {
    throw new Error(error.message)
  }

  return paymentIntent
}

// Create Stripe Connect account for installers
export const createConnectAccount = async (installerData: {
  email: string
  businessName: string
  phone: string
}) => {
  const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-connect-account`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(installerData)
  })

  if (!response.ok) {
    throw new Error('Failed to create Connect account')
  }

  return response.json()
}

// Process payout to installer
export const processInstallerPayout = async (jobId: string, amount: number, stripeAccountId: string) => {
  const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/process-payout`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      jobId,
      amount: Math.round(amount * 100), // Convert to cents
      stripeAccountId
    })
  })

  if (!response.ok) {
    throw new Error('Failed to process payout')
  }

  return response.json()
}