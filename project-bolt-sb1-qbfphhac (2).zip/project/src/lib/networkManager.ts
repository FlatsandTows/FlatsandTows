// Network Connection & API Management
import { useState, useEffect } from 'react'

export class NetworkManager {
  private static instance: NetworkManager
  private isOnline: boolean = navigator.onLine
  private retryQueue: Array<() => Promise<any>> = []
  private maxRetries: number = 3
  private baseDelay: number = 1000

  static getInstance(): NetworkManager {
    if (!NetworkManager.instance) {
      NetworkManager.instance = new NetworkManager()
    }
    return NetworkManager.instance
  }

  constructor() {
    this.setupEventListeners()
  }

  private setupEventListeners() {
    window.addEventListener('online', () => {
      this.isOnline = true
      this.processRetryQueue()
    })

    window.addEventListener('offline', () => {
      this.isOnline = false
    })
  }

  async makeRequest<T>(
    url: string,
    options: RequestInit = {},
    retries: number = this.maxRetries
  ): Promise<T> {
    if (!this.isOnline) {
      throw new Error('No internet connection')
    }

    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 30000) // 30 second timeout

    try {
      const response = await fetch(url, {
        ...options,
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
          ...options.headers
        }
      })

      clearTimeout(timeoutId)

      if (!response.ok) {
        if (response.status >= 500 && retries > 0) {
          // Server error - retry with exponential backoff
          await this.delay(this.baseDelay * Math.pow(2, this.maxRetries - retries))
          return this.makeRequest(url, options, retries - 1)
        }
        throw new Error(`HTTP ${response.status}: ${response.statusText}`)
      }

      return await response.json()
    } catch (error) {
      clearTimeout(timeoutId)
      
      if (error.name === 'AbortError') {
        throw new Error('Request timeout')
      }

      if (retries > 0 && this.shouldRetry(error)) {
        await this.delay(this.baseDelay * Math.pow(2, this.maxRetries - retries))
        return this.makeRequest(url, options, retries - 1)
      }

      throw error
    }
  }

  private shouldRetry(error: any): boolean {
    return (
      error.name === 'TypeError' || // Network error
      error.message.includes('fetch') ||
      error.message.includes('network')
    )
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms))
  }

  private async processRetryQueue() {
    while (this.retryQueue.length > 0 && this.isOnline) {
      const request = this.retryQueue.shift()
      if (request) {
        try {
          await request()
        } catch (error) {
          console.error('Retry queue request failed:', error)
        }
      }
    }
  }

  addToRetryQueue(request: () => Promise<any>) {
    this.retryQueue.push(request)
  }

  getConnectionStatus(): boolean {
    return this.isOnline
  }
}

// React hook for network status
export const useNetworkStatus = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine)

  useEffect(() => {
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)

    return () => {
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
    }
  }, [])

  return isOnline
}