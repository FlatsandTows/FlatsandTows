// Simple Location Services without Google Maps API
interface LocationData {
  lat: number
  lng: number
  accuracy?: number
  timestamp?: number
}

// Get current location with high accuracy and fallback
export const getCurrentLocation = (): Promise<LocationData> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      // Fallback to default location (Miami, FL)
      resolve({
        lat: 25.7617,
        lng: -80.1918,
        accuracy: 1000,
        timestamp: Date.now()
      })
      return
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: position.timestamp
        })
      },
      (error) => {
        console.warn('Geolocation error, using fallback location:', error)
        // Fallback to default location
        resolve({
          lat: 25.7617,
          lng: -80.1918,
          accuracy: 1000,
          timestamp: Date.now()
        })
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000
      }
    )
  })
}

// Calculate simple ETA based on distance (no traffic data)
export const calculateETA = async (
  origin: LocationData,
  destination: LocationData
): Promise<number> => {
  try {
    const distance = calculateDistance(origin.lat, origin.lng, destination.lat, destination.lng)
    
    // Assume average speed of 30 mph (48 km/h) in city traffic
    const averageSpeedKmh = 48
    const distanceKm = distance / 1000
    const timeHours = distanceKm / averageSpeedKmh
    const timeMinutes = Math.round(timeHours * 60)
    
    // Add buffer time for city driving
    return Math.max(timeMinutes + 5, 10) // Minimum 10 minutes
  } catch (error) {
    console.error('ETA calculation error:', error)
    return 15 // Default fallback
  }
}

// Simple distance calculation using Haversine formula
export const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
  const R = 6371e3 // Earth's radius in meters
  const φ1 = lat1 * Math.PI / 180
  const φ2 = lat2 * Math.PI / 180
  const Δφ = (lat2 - lat1) * Math.PI / 180
  const Δλ = (lng2 - lng1) * Math.PI / 180

  const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
          Math.cos(φ1) * Math.cos(φ2) *
          Math.sin(Δλ/2) * Math.sin(Δλ/2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))

  return R * c // Distance in meters
}

// Simple reverse geocoding with fallback
export const reverseGeocode = async (location: LocationData): Promise<string> => {
  try {
    // Use a free geocoding service with error handling
    const response = await fetch(
      `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${location.lat}&longitude=${location.lng}&localityLanguage=en`,
      { 
        method: 'GET',
        headers: {
          'Accept': 'application/json'
        }
      }
    )
    
    if (!response.ok) {
      throw new Error('Geocoding service unavailable')
    }
    
    const data = await response.json()
    
    if (data.locality && data.principalSubdivision) {
      return `${data.locality}, ${data.principalSubdivision}`
    }
    
    // Fallback to coordinates
    return `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`
  } catch (error) {
    console.error('Reverse geocoding error:', error)
    // Return a friendly fallback based on coordinates
    if (location.lat > 25 && location.lat < 27 && location.lng > -81 && location.lng < -79) {
      return 'Miami, FL Area'
    }
    return `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`
  }
}

// Check if location services are available
export const isLocationAvailable = (): boolean => {
  return 'geolocation' in navigator
}

// Request location permission with graceful fallback
export const requestLocationPermission = async (): Promise<boolean> => {
  if (!isLocationAvailable()) {
    return false
  }
  
  try {
    await getCurrentLocation()
    return true
  } catch (error) {
    console.error('Location permission denied:', error)
    return false
  }
}

// Create geofence with error handling
export const createGeofence = (
  targetLocation: LocationData,
  radius: number = 100, // meters
  onEnter: () => void,
  onExit?: () => void
) => {
  if (!isLocationAvailable()) {
    console.warn('Geolocation not available for geofencing')
    return () => {} // Return empty cleanup function
  }

  let isInside = false
  let watchId: number | null = null
  
  try {
    watchId = navigator.geolocation.watchPosition((position) => {
      const currentLocation = {
        lat: position.coords.latitude,
        lng: position.coords.longitude
      }
      
      const distance = calculateDistance(
        currentLocation.lat,
        currentLocation.lng,
        targetLocation.lat,
        targetLocation.lng
      )
      
      const wasInside = isInside
      isInside = distance <= radius
      
      if (!wasInside && isInside) {
        onEnter()
      } else if (wasInside && !isInside && onExit) {
        onExit()
      }
    }, (error) => {
      console.error('Geofence location error:', error)
    }, {
      enableHighAccuracy: true,
      timeout: 5000,
      maximumAge: 30000
    })
  } catch (error) {
    console.error('Geofence setup error:', error)
  }
  
  // Return cleanup function
  return () => {
    if (watchId !== null) {
      navigator.geolocation.clearWatch(watchId)
    }
  }
}

// Watch location changes for real-time tracking with error handling
export const watchLocation = (
  callback: (location: LocationData) => void,
  errorCallback?: (error: GeolocationPositionError) => void
) => {
  if (!navigator.geolocation) {
    console.warn('Geolocation not supported')
    return null
  }

  return navigator.geolocation.watchPosition(
    (position) => {
      callback({
        lat: position.coords.latitude,
        lng: position.coords.longitude,
        accuracy: position.coords.accuracy,
        timestamp: position.timestamp
      })
    },
    (error) => {
      console.error('Location watch error:', error)
      if (errorCallback) {
        errorCallback(error)
      }
    },
    {
      enableHighAccuracy: true,
      timeout: 5000,
      maximumAge: 30000
    }
  )
}

// Real-time location sharing with error handling
export const startLocationSharing = async (jobId: string, installerId: string) => {
  let watchId: number | null = null
  
  try {
    watchId = watchLocation(
      async (location) => {
        try {
          // In demo mode, just log the location update
          console.log(`Location update for job ${jobId}:`, location)
        } catch (error) {
          console.error('Location sharing error:', error)
        }
      },
      (error) => {
        console.error('Location tracking error:', error)
      }
    )
    
    return {
      stop: () => {
        if (watchId !== null) {
          navigator.geolocation.clearWatch(watchId)
        }
      }
    }
  } catch (error) {
    console.error('Location sharing setup error:', error)
    return {
      stop: () => {}
    }
  }
}