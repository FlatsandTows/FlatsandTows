import { supabase, isDemo } from './supabase'

// Demo data for when database is not available
const demoInstallers = [
  {
    id: 'demo-installer-1',
    business_name: 'Quick Fix Auto',
    specialties: ['tire', 'battery'],
    is_premium: true,
    is_online: true,
    current_location: { lat: 26.1224, lng: -80.1373 },
    distance_miles: 2.3,
    response_time_avg: 12,
    completion_rate: 0.98,
    total_jobs: 247,
    base_rates: { tire: 55, battery: 45 },
    stripe_account_id: 'demo-stripe-account',
    stripe_onboarding_complete: true
  },
  {
    id: 'demo-installer-2',
    business_name: 'Road Hero Services',
    specialties: ['towing', 'mechanic'],
    is_premium: false,
    is_online: true,
    current_location: { lat: 26.1324, lng: -80.1273 },
    distance_miles: 3.7,
    response_time_avg: 18,
    completion_rate: 0.94,
    total_jobs: 156,
    base_rates: { towing: 120, mechanic: 85 },
    stripe_account_id: 'demo-stripe-account-2',
    stripe_onboarding_complete: true
  }
]

// Location-based installer search with demo fallback
export const findNearbyInstallers = async (
  latitude: number, 
  longitude: number, 
  radiusMiles: number = 25,
  serviceType?: string
) => {
  if (isDemo) {
    // Return demo installers
    return demoInstallers.filter(installer => 
      !serviceType || installer.specialties.includes(serviceType)
    )
  }

  try {
    let query = supabase!
      .rpc('get_nearby_installers', {
        user_lat: latitude,
        user_lng: longitude,
        radius_miles: radiusMiles
      })

    if (serviceType) {
      query = query.contains('specialties', [serviceType])
    }

    const { data, error } = await query
    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Error finding installers:', error)
    return demoInstallers
  }
}

// Real-time service request creation with demo mode
export const createServiceRequestWithMatching = async (requestData: {
  service_type: string
  location: { lat: number; lng: number }
  address: string
  description?: string
  urgency_level?: number
  max_budget?: number
}) => {
  if (isDemo) {
    // Return demo service request
    return {
      id: `demo-request-${Date.now()}`,
      ...requestData,
      status: 'pending',
      surge_multiplier: 1.2,
      bidding_ends_at: new Date(Date.now() + 10 * 60 * 1000).toISOString(),
      created_at: new Date().toISOString()
    }
  }

  try {
    const { data: request, error: requestError } = await supabase!
      .from('service_requests')
      .insert({
        ...requestData,
        location: `POINT(${requestData.location.lng} ${requestData.location.lat})`,
        status: 'pending',
        surge_multiplier: calculateSurgeMultiplier(),
        bidding_ends_at: new Date(Date.now() + 10 * 60 * 1000).toISOString()
      })
      .select()
      .single()

    if (requestError) throw requestError

    // Find and notify nearby installers
    const nearbyInstallers = await findNearbyInstallers(
      requestData.location.lat,
      requestData.location.lng,
      25,
      requestData.service_type
    )

    console.log(`Notifying ${nearbyInstallers.length} installers about new job`)
    return request
  } catch (error) {
    console.error('Error creating service request:', error)
    throw error
  }
}

// Dynamic surge pricing calculation
const calculateSurgeMultiplier = () => {
  const hour = new Date().getHours()
  const day = new Date().getDay()
  
  let multiplier = 1.0
  
  // Rush hours
  if ((hour >= 7 && hour <= 9) || (hour >= 17 && hour <= 19)) {
    multiplier *= 1.4
  }
  
  // Night premium
  if (hour < 6 || hour > 22) {
    multiplier *= 1.6
  }
  
  // Weekend premium
  if (day === 0 || day === 6) {
    multiplier *= 1.2
  }
  
  return Math.round(multiplier * 100) / 100
}

// Real-time bidding system with demo mode
export const createBid = async (bidData: {
  request_id: string
  price: number
  estimated_arrival: number
  message?: string
}) => {
  if (isDemo) {
    return {
      id: `demo-bid-${Date.now()}`,
      ...bidData,
      expires_at: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
      match_score: 95,
      installer: demoInstallers[0],
      created_at: new Date().toISOString()
    }
  }

  try {
    const { data, error } = await supabase!
      .from('bids')
      .insert({
        ...bidData,
        expires_at: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
        match_score: calculateMatchScore(bidData)
      })
      .select(`
        *,
        installer:installer_profiles(*)
      `)
      .single()

    if (error) throw error
    return data
  } catch (error) {
    console.error('Error creating bid:', error)
    throw error
  }
}

// AI matching score calculation
const calculateMatchScore = (bidData: any) => {
  let score = 50 // Base score
  
  // Price competitiveness (lower price = higher score)
  if (bidData.price < 60) score += 20
  if (bidData.price < 40) score += 10
  
  // Response time (faster = higher score)
  if (bidData.estimated_arrival < 15) score += 15
  if (bidData.estimated_arrival < 10) score += 10
  
  return Math.min(100, score)
}

// Accept bid and create job with demo mode
export const acceptBidAndCreateJob = async (bidId: string) => {
  if (isDemo) {
    const demoBid = {
      id: bidId,
      price: 65,
      installer_id: 'demo-installer-1',
      request_id: 'demo-request-1',
      installer: demoInstallers[0],
      request: {
        customer_id: 'demo-user-id',
        service_type: 'tire',
        location: { lat: 26.1224, lng: -80.1373 },
        address: '123 Demo Street, Miami, FL'
      }
    }

    const demoJob = {
      id: `demo-job-${Date.now()}`,
      request_id: demoBid.request_id,
      installer_id: demoBid.installer_id,
      customer_id: demoBid.request.customer_id,
      bid_id: bidId,
      service_type: demoBid.request.service_type,
      agreed_price: demoBid.price,
      platform_fee: Math.round(demoBid.price * 0.12),
      processing_fee: 2.99,
      installer_payout: demoBid.price * 0.88 - 2.99,
      location: demoBid.request.location,
      address: demoBid.request.address,
      status: 'assigned',
      created_at: new Date().toISOString()
    }

    return { bid: demoBid, job: demoJob }
  }

  try {
    const { data: bid, error: bidError } = await supabase!
      .from('bids')
      .select(`
        *,
        request:service_requests(*),
        installer:installer_profiles(*)
      `)
      .eq('id', bidId)
      .single()

    if (bidError) throw bidError

    // Update bid status
    await supabase!
      .from('bids')
      .update({ status: 'accepted' })
      .eq('id', bidId)

    // Update request status
    await supabase!
      .from('service_requests')
      .update({ 
        status: 'assigned',
        assigned_installer_id: bid.installer_id
      })
      .eq('id', bid.request_id)

    // Create job
    const platformFee = Math.round(bid.price * 0.12)
    const processingFee = 2.99
    const installerPayout = bid.price - platformFee - processingFee

    const { data: job, error: jobError } = await supabase!
      .from('jobs')
      .insert({
        request_id: bid.request_id,
        installer_id: bid.installer_id,
        customer_id: bid.request.customer_id,
        bid_id: bidId,
        service_type: bid.request.service_type,
        agreed_price: bid.price,
        platform_fee: platformFee,
        processing_fee: processingFee,
        installer_payout: installerPayout,
        location: bid.request.location,
        address: bid.request.address
      })
      .select()
      .single()

    if (jobError) throw jobError

    return { bid, job }
  } catch (error) {
    console.error('Error accepting bid:', error)
    throw error
  }
}

// Real-time subscriptions with demo mode
export const subscribeToServiceRequest = (requestId: string, callback: (payload: any) => void) => {
  if (isDemo) {
    // Return a mock subscription
    return {
      unsubscribe: () => console.log('Demo subscription unsubscribed')
    }
  }

  return supabase!
    .channel(`service_request_${requestId}`)
    .on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'service_requests',
      filter: `id=eq.${requestId}`
    }, callback)
    .subscribe()
}

export const subscribeToBids = (requestId: string, callback: (payload: any) => void) => {
  if (isDemo) {
    // Simulate incoming bids in demo mode
    setTimeout(() => {
      callback({
        eventType: 'INSERT',
        new: {
          id: `demo-bid-${Date.now()}`,
          request_id: requestId,
          installer_id: 'demo-installer-1',
          price: 65,
          estimated_arrival: 12,
          message: 'Professional tire service - I can be there in 12 minutes!',
          match_score: 95,
          installer: demoInstallers[0],
          created_at: new Date().toISOString()
        }
      })
    }, 3000)

    setTimeout(() => {
      callback({
        eventType: 'INSERT',
        new: {
          id: `demo-bid-${Date.now() + 1}`,
          request_id: requestId,
          installer_id: 'demo-installer-2',
          price: 58,
          estimated_arrival: 18,
          message: 'Quick and reliable service - competitive pricing!',
          match_score: 88,
          installer: demoInstallers[1],
          created_at: new Date().toISOString()
        }
      })
    }, 7000)

    return {
      unsubscribe: () => console.log('Demo bids subscription unsubscribed')
    }
  }

  return supabase!
    .channel(`bids_${requestId}`)
    .on('postgres_changes', {
      event: 'INSERT',
      schema: 'public',
      table: 'bids',
      filter: `request_id=eq.${requestId}`
    }, callback)
    .subscribe()
}