// SMS and Push Notification Service
import { supabase } from './supabase'

interface NotificationData {
  to: string
  message: string
  type: 'sms' | 'push' | 'email'
  jobId?: string
  urgency?: 'low' | 'medium' | 'high' | 'emergency'
}

// SMS Notifications via Twilio
export const sendSMS = async (to: string, message: string, jobId?: string) => {
  try {
    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-sms`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        to,
        message,
        jobId
      })
    })

    if (!response.ok) {
      throw new Error('Failed to send SMS')
    }

    return await response.json()
  } catch (error) {
    console.error('SMS sending error:', error)
    throw error
  }
}

// Push Notifications
export const sendPushNotification = async (userId: string, title: string, body: string, data?: any) => {
  try {
    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-push`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userId,
        title,
        body,
        data
      })
    })

    if (!response.ok) {
      throw new Error('Failed to send push notification')
    }

    return await response.json()
  } catch (error) {
    console.error('Push notification error:', error)
    throw error
  }
}

// Automated notification templates
export const NotificationTemplates = {
  // Customer notifications
  bidReceived: (installerName: string, price: number, eta: number) => 
    `🔧 New bid from ${installerName}: $${price} • ${eta} min ETA. Accept now!`,
  
  installerEnRoute: (installerName: string, eta: number) => 
    `🚗 ${installerName} is on the way! ETA: ${eta} minutes. Track progress in app.`,
  
  serviceStarted: (installerName: string) => 
    `🔧 ${installerName} has started your service. You'll be notified when complete.`,
  
  serviceCompleted: (installerName: string, amount: number) => 
    `✅ Service completed by ${installerName}! $${amount} charged. Rate your experience.`,
  
  paymentProcessed: (amount: number) => 
    `💳 Payment of $${amount} processed successfully. Installer paid automatically.`,

  // Installer notifications
  newJobAlert: (serviceType: string, location: string, price: number) => 
    `🚨 NEW JOB: ${serviceType} in ${location} • $${price} • Bid now!`,
  
  bidAccepted: (customerName: string, amount: number) => 
    `🎉 Bid accepted! ${customerName} paid $${amount}. Start service now.`,
  
  paymentReceived: (amount: number) => 
    `💰 Payment received: $${amount} deposited to your account instantly!`,
  
  ratingReceived: (rating: number, review?: string) => 
    `⭐ New ${rating}-star rating${review ? `: "${review}"` : ''}`,

  // Emergency notifications
  emergencyRequest: (serviceType: string, location: string) => 
    `🚨 EMERGENCY: ${serviceType} needed in ${location}. Premium rates apply!`,
  
  disputeCreated: (jobId: string) => 
    `⚠️ Dispute created for job #${jobId}. Auto-resolution in progress.`,
}

// Send job-related notifications
export const sendJobNotifications = async (
  jobId: string, 
  type: 'created' | 'accepted' | 'started' | 'completed' | 'disputed',
  additionalData?: any
) => {
  try {
    // Get job details
    const { data: job, error } = await supabase
      .from('jobs')
      .select(`
        *,
        customer:profiles!jobs_customer_id_fkey(*),
        installer:installer_profiles(*)
      `)
      .eq('id', jobId)
      .single()

    if (error || !job) {
      throw new Error('Job not found')
    }

    const customerPhone = job.customer.phone
    const installerPhone = job.installer?.phone

    switch (type) {
      case 'created':
        // Notify nearby installers
        if (installerPhone) {
          await sendSMS(
            installerPhone,
            NotificationTemplates.newJobAlert(
              job.service_type,
              job.address,
              job.agreed_price
            ),
            jobId
          )
        }
        break

      case 'accepted':
        // Notify customer
        if (customerPhone) {
          await sendSMS(
            customerPhone,
            NotificationTemplates.installerEnRoute(
              job.installer.business_name,
              15 // Default ETA
            ),
            jobId
          )
        }
        
        // Notify installer
        if (installerPhone) {
          await sendSMS(
            installerPhone,
            NotificationTemplates.bidAccepted(
              job.customer.full_name || 'Customer',
              job.agreed_price
            ),
            jobId
          )
        }
        break

      case 'started':
        if (customerPhone) {
          await sendSMS(
            customerPhone,
            NotificationTemplates.serviceStarted(job.installer.business_name),
            jobId
          )
        }
        break

      case 'completed':
        if (customerPhone) {
          await sendSMS(
            customerPhone,
            NotificationTemplates.serviceCompleted(
              job.installer.business_name,
              job.agreed_price
            ),
            jobId
          )
        }
        
        if (installerPhone) {
          await sendSMS(
            installerPhone,
            NotificationTemplates.paymentReceived(job.installer_payout),
            jobId
          )
        }
        break
    }
  } catch (error) {
    console.error('Job notification error:', error)
  }
}

// Emergency broadcast system
export const sendEmergencyBroadcast = async (
  location: { lat: number; lng: number },
  serviceType: string,
  radius: number = 25
) => {
  try {
    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/emergency-broadcast`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        location,
        serviceType,
        radius
      })
    })

    return await response.json()
  } catch (error) {
    console.error('Emergency broadcast error:', error)
    throw error
  }
}