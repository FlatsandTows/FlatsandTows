// Enhanced AI Integration for Flats & Tows with OpenAI
import { supabase } from './supabase'

interface ChatMessage {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp: Date
  metadata?: any
}

interface AIResponse {
  message: string
  confidence: number
  suggestedActions?: string[]
  escalate?: boolean
}

// Enhanced AI Chatbot with OpenAI GPT-4 integration
export class FlatsToysAI {
  private apiKey: string
  private baseUrl = 'https://api.openai.com/v1/chat/completions'
  
  constructor() {
    this.apiKey = import.meta.env.VITE_OPENAI_API_KEY || ''
  }

  async generateResponse(
    messages: ChatMessage[],
    context?: {
      userType: 'customer' | 'installer'
      currentJob?: any
      userProfile?: any
    }
  ): Promise<AIResponse> {
    try {
      if (!this.apiKey) {
        return this.getFallbackResponse(messages[messages.length - 1].content)
      }

      const systemPrompt = this.buildSystemPrompt(context)
      
      const requestBody = {
        model: 'gpt-4-turbo-preview', // Latest GPT-4 model for best performance
        messages: [
          { role: 'system', content: systemPrompt },
          ...messages.map(msg => ({
            role: msg.role,
            content: msg.content
          }))
        ],
        max_tokens: 500,
        temperature: 0.7,
        stream: false,
        response_format: { type: "text" }
      }

      const response = await fetch(this.baseUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
          'OpenAI-Beta': 'assistants=v2' // Enable latest features
        },
        body: JSON.stringify(requestBody)
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(`OpenAI API request failed: ${response.status} - ${errorData.error?.message || 'Unknown error'}`)
      }

      const data = await response.json()
      const aiMessage = data.choices[0]?.message?.content || ''

      return {
        message: aiMessage,
        confidence: 0.95, // High confidence with GPT-4
        suggestedActions: this.extractSuggestedActions(aiMessage),
        escalate: this.shouldEscalate(aiMessage)
      }
    } catch (error) {
      console.error('OpenAI AI response error:', error)
      return this.getFallbackResponse(messages[messages.length - 1].content)
    }
  }

  private buildSystemPrompt(context?: any): string {
    const basePrompt = `You are an AI assistant for Flats & Tows, the world's most advanced autonomous roadside assistance marketplace with pickup & delivery services. 

PLATFORM OVERVIEW:
- 96.3% autonomous operations with AI-powered dispatch
- Services: Emergency roadside assistance + Pickup & delivery for auto parts/tires
- Real-time bidding with custom pricing negotiation
- Instant payments via Stripe, 60-second installer payouts
- 24/7 availability with GPS tracking and verified installers

SERVICES AVAILABLE:
1. EMERGENCY ROADSIDE:
   - Tire services ($55-150): Flat repair, tire change, roadside assistance
   - Battery services ($45-120): Jump start, battery replacement, testing
   - Towing services ($120-300): Emergency towing, vehicle transport
   - Lockout services ($65-140): Vehicle unlock, key replacement
   - Fuel delivery ($35-80): Emergency gas delivery
   - Mobile mechanic ($85-250): On-site repairs, diagnostics

2. PICKUP & DELIVERY (NEW):
   - Auto parts pickup/delivery with custom pricing
   - Tire pickup/delivery with flexible scheduling
   - Custom offers with detailed fee breakdowns
   - Negotiable pricing between providers and customers

PRICING STRUCTURE:
- Dynamic pricing based on demand, time, location
- Platform fee: 12% + $2.99 processing fee
- VIP members: Reduced fees + priority service
- Custom offers: Providers set pickup fees, delivery fees, handling fees, rush fees, distance fees

AI CAPABILITIES:
- Autonomous job matching (96.8% accuracy)
- Dynamic pricing optimization
- Predictive analytics and scaling
- Auto-dispute resolution (94.7% success rate)
- Real-time fraud detection

GUIDELINES:
- Be helpful, professional, and concise
- Provide accurate pricing information for all services
- Explain autonomous marketplace features
- Highlight new pickup/delivery service with custom negotiation
- Direct users to appropriate app actions
- Emphasize safety, security, and verification features
- Mention that all services are performed by independent contractors
- For complex issues, suggest escalation to human support

CURRENT CONTEXT: ${context ? JSON.stringify(context) : 'General inquiry'}

RESPONSE STYLE:
- Professional yet friendly tone
- Focus on solutions and next steps
- Highlight unique autonomous features
- Emphasize speed, reliability, and transparency`

    return basePrompt
  }

  private getFallbackResponse(userMessage: string): AIResponse {
    const message = userMessage.toLowerCase()
    
    const responses = {
      pricing: "Our pricing is dynamic and competitive! Emergency services: Tire ($55-150), Battery ($45-120), Towing ($120-300), Lockout ($65-140), Fuel ($35-80), Mobile Mechanic ($85-250). NEW: Pickup & delivery starts at $35 with custom pricing options. Providers can create detailed offers with pickup fees, delivery fees, handling fees, and more. VIP members save 50% on platform fees!",
      
      pickup: "🚀 NEW SERVICE: Pickup & delivery for auto parts and tires! Choose pickup only, delivery only, or full service. Providers create custom offers with transparent pricing breakdowns including pickup fees ($10-25), delivery fees ($15-30), handling fees ($5-15), and distance fees. You can negotiate terms directly with providers for the best deal!",
      
      delivery: "Our pickup & delivery service revolutionizes auto parts shopping! Get tires, parts, and accessories delivered with custom pricing. Providers offer flexible scheduling, detailed cost breakdowns, and negotiable terms. Perfect for busy schedules or when you need parts but can't leave your location.",
      
      autonomous: "We're 96.3% autonomous! Our AI handles job matching (96.8% accuracy), dynamic pricing, dispute resolution (94.7% auto-resolved), and predictive scaling. Installers are paid automatically within 60 seconds of completion. The platform essentially runs itself while ensuring premium service quality.",
      
      payment: "Secure payments via Stripe with instant processing. Payment required before service dispatch for security. Installers receive automatic payouts within 60 seconds of job completion - no waiting, no hassle. We support all major credit cards and digital wallets.",
      
      safety: "All installers are independent contractors with background checks, insurance verification, and real-time GPS tracking. We provide 24/7 customer support, secure payments, and comprehensive dispute resolution. Your safety and satisfaction are guaranteed.",
      
      eta: "Emergency services: 15-30 minutes average arrival. Pickup & delivery: 2-6 hours depending on distance and provider availability. Premium installers often have faster response times. You'll see exact ETAs when reviewing offers from providers.",
      
      vip: "VIP membership ($29.99/month) includes: 50% reduced platform fees, priority service dispatch, access to premium installers, 24/7 priority support, and exclusive pricing. Pays for itself in just 2 services! Upgrade in your profile settings.",
      
      dispute: "Our AI resolves 94.7% of disputes automatically within 15 minutes using advanced algorithms. For complex issues, we escalate to human specialists. You can file disputes through the app after service completion with full documentation support.",
      
      custom: "Providers create custom offers with detailed pricing: base service + pickup fees + delivery fees + handling fees + rush fees + distance fees + item-specific fees. You can negotiate terms, timing, and pricing directly through our secure platform. Full transparency, no hidden costs!",
      
      emergency: "🚨 EMERGENCY HELP: Tap the red emergency button for instant dispatch! Our AI finds the nearest qualified installer in under 5 seconds. Average response time: 15 minutes. Available 24/7 with real-time tracking and automatic payments.",
      
      default: "I'm your AI assistant for Flats & Tows - the world's most advanced autonomous roadside assistance marketplace! I can help with emergency services, pickup & delivery, pricing, tracking, custom offers, and more. Our platform is 96.3% autonomous with instant payments and verified installers. How can I assist you today?"
    }

    let responseKey = 'default'
    
    if (message.includes('price') || message.includes('cost') || message.includes('fee') || message.includes('rate')) {
      responseKey = 'pricing'
    } else if (message.includes('pickup') || message.includes('pick up')) {
      responseKey = 'pickup'
    } else if (message.includes('delivery') || message.includes('deliver')) {
      responseKey = 'delivery'
    } else if (message.includes('autonomous') || message.includes('ai') || message.includes('automatic')) {
      responseKey = 'autonomous'
    } else if (message.includes('custom') || message.includes('negotiate') || message.includes('offer')) {
      responseKey = 'custom'
    } else if (message.includes('payment') || message.includes('pay') || message.includes('card') || message.includes('stripe')) {
      responseKey = 'payment'
    } else if (message.includes('safe') || message.includes('secure') || message.includes('trust') || message.includes('verify')) {
      responseKey = 'safety'
    } else if (message.includes('time') || message.includes('eta') || message.includes('arrive') || message.includes('fast')) {
      responseKey = 'eta'
    } else if (message.includes('vip') || message.includes('premium') || message.includes('membership')) {
      responseKey = 'vip'
    } else if (message.includes('dispute') || message.includes('problem') || message.includes('issue') || message.includes('complaint')) {
      responseKey = 'dispute'
    } else if (message.includes('emergency') || message.includes('urgent') || message.includes('help') || message.includes('911')) {
      responseKey = 'emergency'
    }

    return {
      message: responses[responseKey],
      confidence: 0.8,
      suggestedActions: this.getSuggestedActions(responseKey),
      escalate: false
    }
  }

  private extractSuggestedActions(message: string): string[] {
    const actions = []
    
    if (message.includes('start') || message.includes('request') || message.includes('emergency')) {
      actions.push('🚨 Emergency Help')
    }
    if (message.includes('pickup') || message.includes('delivery')) {
      actions.push('📦 Pickup & Delivery')
    }
    if (message.includes('track') || message.includes('status')) {
      actions.push('📍 Track Service')
    }
    if (message.includes('payment') || message.includes('billing')) {
      actions.push('💳 Payment History')
    }
    if (message.includes('support') || message.includes('help')) {
      actions.push('📞 Contact Support')
    }
    if (message.includes('custom') || message.includes('negotiate')) {
      actions.push('💰 Custom Offers')
    }
    if (message.includes('vip') || message.includes('upgrade')) {
      actions.push('👑 Upgrade VIP')
    }
    
    return actions
  }

  private getSuggestedActions(responseType: string): string[] {
    const actionMap = {
      pricing: ['🚨 Emergency Help', '📦 Pickup & Delivery', '👑 Upgrade VIP'],
      pickup: ['📦 Start Pickup/Delivery', '💰 Custom Offers', '📍 Find Providers'],
      delivery: ['📦 Pickup & Delivery', '💰 Negotiate Pricing', '⏰ Schedule Service'],
      autonomous: ['🤖 View AI Engine', '📊 Platform Stats', '🚨 Emergency Help'],
      custom: ['💰 Create Custom Offer', '📦 Pickup & Delivery', '🤝 Negotiate Terms'],
      payment: ['💳 Payment Methods', '📊 Payment History', '👑 VIP Benefits'],
      safety: ['🛡️ Installer Profiles', '📋 Safety Guidelines', '📞 Support'],
      eta: ['🚨 Emergency Help', '📍 Track Service', '⏰ Schedule Service'],
      vip: ['👑 Upgrade VIP', '💰 View Benefits', '🎯 Priority Service'],
      dispute: ['📝 File Dispute', '📞 Contact Support', '🤖 Auto Resolution'],
      emergency: ['🚨 EMERGENCY HELP', '📞 Call Support', '📍 Share Location'],
      default: ['🚨 Emergency Help', '📦 Pickup & Delivery', '👑 Upgrade VIP', '🤖 AI Engine']
    }
    
    return actionMap[responseType] || actionMap.default
  }

  private shouldEscalate(message: string): boolean {
    const escalationKeywords = [
      'emergency', 'urgent', 'complaint', 'refund', 'legal',
      'police', 'accident', 'injury', 'fraud', 'scam', 'lawsuit',
      'attorney', 'lawyer', 'sue', 'court', 'dangerous'
    ]
    
    return escalationKeywords.some(keyword => 
      message.toLowerCase().includes(keyword)
    )
  }
}

// Advanced pricing algorithm with OpenAI integration
export const calculateDynamicPricing = async (
  serviceType: string,
  location: { lat: number; lng: number },
  urgencyLevel: number = 1,
  useAI: boolean = true
): Promise<{
  basePrice: number
  surgeMultiplier: number
  finalPrice: number
  factors: string[]
  aiRecommendation?: string
}> => {
  try {
    const { data, error } = await supabase
      .rpc('calculate_surge_multiplier', {
        service_location: `POINT(${location.lng} ${location.lat})`,
        service_type_param: serviceType,
        request_time: new Date().toISOString()
      })

    if (error) throw error

    const basePrices = {
      tire: 55,
      battery: 45,
      towing: 120,
      lockout: 65,
      fuel: 35,
      mechanic: 85,
      pickup_delivery: 35
    }

    const basePrice = basePrices[serviceType] || 55
    const surgeMultiplier = data || 1.0
    const urgencyMultiplier = 1 + (urgencyLevel - 1) * 0.2
    
    const finalPrice = Math.round(basePrice * surgeMultiplier * urgencyMultiplier)

    const factors = []
    if (surgeMultiplier > 1.2) factors.push('High demand')
    if (urgencyLevel > 3) factors.push('Emergency service')
    
    const hour = new Date().getHours()
    if (hour < 6 || hour > 22) factors.push('Night premium')
    if (hour >= 7 && hour <= 9 || hour >= 17 && hour <= 19) factors.push('Rush hour')

    let aiRecommendation = ''
    
    // Get AI pricing recommendation if enabled
    if (useAI && import.meta.env.VITE_OPENAI_API_KEY) {
      try {
        const ai = new FlatsToysAI()
        const response = await ai.generateResponse([{
          id: 'pricing-request',
          role: 'user',
          content: `Analyze pricing for ${serviceType} service at urgency level ${urgencyLevel} with ${factors.join(', ')} factors. Base price: $${basePrice}, Final price: $${finalPrice}. Provide brief pricing insight.`,
          timestamp: new Date()
        }])
        aiRecommendation = response.message
      } catch (aiError) {
        console.log('AI pricing recommendation unavailable:', aiError)
      }
    }

    return {
      basePrice,
      surgeMultiplier,
      finalPrice,
      factors,
      aiRecommendation
    }
  } catch (error) {
    console.error('Pricing calculation error:', error)
    
    // Fallback pricing
    const basePrices = {
      tire: 55,
      battery: 45,
      towing: 120,
      lockout: 65,
      fuel: 35,
      mechanic: 85,
      pickup_delivery: 35
    }
    
    const basePrice = basePrices[serviceType] || 55
    
    return {
      basePrice,
      surgeMultiplier: 1.0,
      finalPrice: basePrice,
      factors: []
    }
  }
}

// AI-powered fraud detection
export const detectFraudulentActivity = async (
  userId: string,
  activityType: 'payment' | 'request' | 'bid',
  metadata: any
): Promise<{
  riskScore: number
  flags: string[]
  shouldBlock: boolean
  aiAnalysis?: string
}> => {
  try {
    // Get user's recent activity
    const { data: recentActivity, error } = await supabase
      .from('user_activity_log')
      .select('*')
      .eq('user_id', userId)
      .gte('created_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
      .order('created_at', { ascending: false })
      .limit(50)

    if (error) throw error

    let riskScore = 0
    const flags = []

    // Check for suspicious patterns
    const activityCounts = recentActivity?.reduce((acc, activity) => {
      acc[activity.activity_type] = (acc[activity.activity_type] || 0) + 1
      return acc
    }, {}) || {}

    // Too many requests in short time
    if (activityCounts.request > 10) {
      riskScore += 30
      flags.push('Excessive service requests')
    }

    // Multiple failed payments
    if (activityCounts.payment_failed > 3) {
      riskScore += 40
      flags.push('Multiple payment failures')
    }

    // Unusual location patterns
    if (metadata.location) {
      const locationChanges = recentActivity?.filter(a => 
        a.metadata?.location && 
        calculateLocationDistance(a.metadata.location, metadata.location) > 100
      ).length || 0

      if (locationChanges > 5) {
        riskScore += 25
        flags.push('Unusual location patterns')
      }
    }

    // New account with high-value requests
    const { data: profile } = await supabase
      .from('profiles')
      .select('created_at')
      .eq('id', userId)
      .single()

    if (profile) {
      const accountAge = Date.now() - new Date(profile.created_at).getTime()
      const isNewAccount = accountAge < 7 * 24 * 60 * 60 * 1000 // 7 days

      if (isNewAccount && metadata.amount > 200) {
        riskScore += 35
        flags.push('New account with high-value request')
      }
    }

    let aiAnalysis = ''
    
    // Get AI fraud analysis if available
    if (import.meta.env.VITE_OPENAI_API_KEY && flags.length > 0) {
      try {
        const ai = new FlatsToysAI()
        const response = await ai.generateResponse([{
          id: 'fraud-analysis',
          role: 'user',
          content: `Analyze fraud risk: Risk score ${riskScore}, Flags: ${flags.join(', ')}, Activity type: ${activityType}. Provide brief security assessment.`,
          timestamp: new Date()
        }])
        aiAnalysis = response.message
      } catch (aiError) {
        console.log('AI fraud analysis unavailable:', aiError)
      }
    }

    return {
      riskScore,
      flags,
      shouldBlock: riskScore > 70,
      aiAnalysis
    }
  } catch (error) {
    console.error('Fraud detection error:', error)
    return {
      riskScore: 0,
      flags: [],
      shouldBlock: false
    }
  }
}

// Helper function to calculate distance between locations
const calculateLocationDistance = (loc1: any, loc2: any): number => {
  if (!loc1 || !loc2) return 0
  
  const R = 6371 // Earth's radius in km
  const dLat = (loc2.lat - loc1.lat) * Math.PI / 180
  const dLng = (loc2.lng - loc1.lng) * Math.PI / 180
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
          Math.cos(loc1.lat * Math.PI / 180) * Math.cos(loc2.lat * Math.PI / 180) *
          Math.sin(dLng/2) * Math.sin(dLng/2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
  return R * c
}

// Export AI instance
export const flatsToysAI = new FlatsToysAI()