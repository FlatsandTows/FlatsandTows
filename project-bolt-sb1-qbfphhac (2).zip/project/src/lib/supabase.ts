import { createClient } from '@supabase/supabase-js'

// Use placeholder values for demo mode when environment variables are missing
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://demo.supabase.co'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'demo-key'

// Create a demo mode flag
const isDemoMode = !import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY

export const supabase = isDemoMode ? null : createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
})

// Database types
export interface Profile {
  id: string
  email: string
  full_name?: string
  phone?: string
  role: 'customer' | 'installer' | 'admin'
  avatar_url?: string
  location?: { lat: number; lng: number }
  address?: string
  city?: string
  state?: string
  zip_code?: string
  is_verified: boolean
  membership_type: 'free' | 'vip' | 'premium'
  membership_expires_at?: string
  referral_code?: string
  referred_by?: string
  total_referral_earnings: number
  created_at: string
  updated_at: string
}

// Enhanced service request interface for pickup/delivery
export interface ServiceRequest {
  id: string
  customer_id: string
  service_type: 'tire' | 'battery' | 'towing' | 'lockout' | 'fuel' | 'mechanic' | 'pickup_delivery'
  status: 'pending' | 'bidding' | 'assigned' | 'in_progress' | 'completed' | 'cancelled' | 'disputed'
  location: { lat: number; lng: number }
  address: string
  description?: string
  urgency_level?: number
  max_budget?: number
  
  // Pickup & Delivery specific fields
  delivery_type?: 'pickup_only' | 'delivery_only' | 'pickup_and_delivery'
  pickup_location?: { lat: number; lng: number; address: string }
  delivery_location?: { lat: number; lng: number; address: string }
  item_details?: {
    type: 'auto_parts' | 'tires' | 'other'
    description: string
    quantity: number
    weight?: number
    dimensions?: string
    special_handling?: string
  }
  preferred_pickup_time?: string
  preferred_delivery_time?: string
  
  created_at: string
  updated_at: string
}

// Custom offer interface
export interface CustomOffer {
  id: string
  request_id: string
  installer_id: string
  offer_type: 'standard_bid' | 'custom_offer'
  base_price: number
  custom_pricing: {
    pickup_fee?: number
    delivery_fee?: number
    handling_fee?: number
    rush_fee?: number
    distance_fee?: number
    item_specific_fee?: number
  }
  total_price: number
  estimated_pickup_time?: string
  estimated_delivery_time?: string
  message: string
  terms_and_conditions?: string
  valid_until: string
  status: 'pending' | 'accepted' | 'rejected' | 'expired' | 'countered'
  created_at: string
  updated_at: string
}

// Demo data for when Supabase is not available
const demoProfile: Profile = {
  id: 'demo-user-id',
  email: 'demo@example.com',
  full_name: 'Demo User',
  phone: '(555) 123-4567',
  role: 'customer',
  city: 'Miami',
  state: 'FL',
  is_verified: true,
  membership_type: 'free',
  total_referral_earnings: 0,
  created_at: new Date().toISOString(),
  updated_at: new Date().toISOString()
}

// Enhanced auth helpers with demo mode support
export const signUp = async (email: string, password: string, userData: Partial<Profile>) => {
  if (isDemoMode) {
    // Return demo success response
    return {
      user: { id: 'demo-user-id', email },
      session: null
    }
  }

  try {
    const { data, error } = await supabase!.auth.signUp({
      email,
      password,
      options: {
        data: userData
      }
    })
    
    if (error) throw error
    
    // Create profile
    if (data.user) {
      const { error: profileError } = await supabase!
        .from('profiles')
        .insert({
          id: data.user.id,
          email,
          ...userData,
          referral_code: `HERO${Math.random().toString(36).substr(2, 6).toUpperCase()}`
        })
      
      if (profileError) throw profileError
    }
    
    return data
  } catch (error) {
    console.error('Sign up error:', error)
    throw error
  }
}

export const signIn = async (email: string, password: string) => {
  if (isDemoMode) {
    // Return demo success response
    return {
      user: { id: 'demo-user-id', email },
      session: { access_token: 'demo-token' }
    }
  }

  try {
    const { data, error } = await supabase!.auth.signInWithPassword({
      email,
      password
    })
    
    if (error) throw error
    return data
  } catch (error) {
    console.error('Sign in error:', error)
    throw error
  }
}

export const signOut = async () => {
  if (isDemoMode) return

  try {
    const { error } = await supabase!.auth.signOut()
    if (error) throw error
  } catch (error) {
    console.error('Sign out error:', error)
    throw error
  }
}

export const getCurrentUser = async () => {
  if (isDemoMode) {
    return { id: 'demo-user-id', email: 'demo@example.com' }
  }

  try {
    const { data: { user }, error } = await supabase!.auth.getUser()
    if (error) throw error
    return user
  } catch (error) {
    console.error('Get current user error:', error)
    return null
  }
}

export const getProfile = async (userId: string): Promise<Profile> => {
  if (isDemoMode) {
    return demoProfile
  }

  try {
    const { data, error } = await supabase!
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single()
    
    if (error) throw error
    return data as Profile
  } catch (error) {
    console.error('Get profile error:', error)
    return demoProfile
  }
}

export const updateProfile = async (userId: string, updates: Partial<Profile>) => {
  if (isDemoMode) {
    return { ...demoProfile, ...updates }
  }

  try {
    const { data, error } = await supabase!
      .from('profiles')
      .update(updates)
      .eq('id', userId)
      .select()
      .single()
    
    if (error) throw error
    return data as Profile
  } catch (error) {
    console.error('Update profile error:', error)
    throw error
  }
}

// Custom offer functions
export const createCustomOffer = async (offerData: Partial<CustomOffer>) => {
  if (isDemoMode) {
    return {
      id: `demo-offer-${Date.now()}`,
      ...offerData,
      status: 'pending',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }
  }

  try {
    const { data, error } = await supabase!
      .from('custom_offers')
      .insert(offerData)
      .select()
      .single()
    
    if (error) throw error
    return data as CustomOffer
  } catch (error) {
    console.error('Create custom offer error:', error)
    throw error
  }
}

export const getCustomOffers = async (requestId: string) => {
  if (isDemoMode) {
    return [
      {
        id: 'demo-offer-1',
        request_id: requestId,
        installer_id: 'demo-installer-1',
        offer_type: 'custom_offer',
        base_price: 45,
        custom_pricing: {
          pickup_fee: 15,
          delivery_fee: 20,
          handling_fee: 5
        },
        total_price: 85,
        estimated_pickup_time: '2 hours',
        estimated_delivery_time: '4 hours',
        message: 'Professional pickup and delivery service with careful handling',
        status: 'pending',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }
    ]
  }

  try {
    const { data, error } = await supabase!
      .from('custom_offers')
      .select('*')
      .eq('request_id', requestId)
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data as CustomOffer[]
  } catch (error) {
    console.error('Get custom offers error:', error)
    return []
  }
}

// Demo mode indicator
export const isDemo = isDemoMode