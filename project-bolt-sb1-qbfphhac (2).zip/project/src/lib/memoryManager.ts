// Memory Management & Cleanup
import { useEffect } from 'react'

export class MemoryManager {
  private static instance: MemoryManager
  private cleanupTasks: Set<() => void> = new Set()
  private intervalId: number | null = null

  static getInstance(): MemoryManager {
    if (!MemoryManager.instance) {
      MemoryManager.instance = new MemoryManager()
    }
    return MemoryManager.instance
  }

  constructor() {
    this.startCleanupCycle()
    this.setupUnloadHandler()
  }

  private startCleanupCycle() {
    this.intervalId = window.setInterval(() => {
      this.performCleanup()
    }, 60000) // Run every minute
  }

  private setupUnloadHandler() {
    window.addEventListener('beforeunload', () => {
      this.performCleanup()
    })
  }

  addCleanupTask(task: () => void) {
    this.cleanupTasks.add(task)
  }

  removeCleanupTask(task: () => void) {
    this.cleanupTasks.delete(task)
  }

  private performCleanup() {
    // Run all cleanup tasks
    this.cleanupTasks.forEach(task => {
      try {
        task()
      } catch (error) {
        console.error('Cleanup task failed:', error)
      }
    })

    // Clear old console logs in production
    if (import.meta.env.PROD && console.clear) {
      console.clear()
    }

    // Force garbage collection if available
    if ('gc' in window && typeof window.gc === 'function') {
      window.gc()
    }
  }

  // Memory usage monitoring
  getMemoryUsage(): { used: number; total: number; percentage: number } | null {
    if ('memory' in performance) {
      const memory = (performance as any).memory
      return {
        used: Math.round(memory.usedJSHeapSize / 1024 / 1024), // MB
        total: Math.round(memory.totalJSHeapSize / 1024 / 1024), // MB
        percentage: Math.round((memory.usedJSHeapSize / memory.jsHeapSizeLimit) * 100)
      }
    }
    return null
  }

  // Clean up specific data types
  cleanupImageCache() {
    // Remove unused image elements
    const images = document.querySelectorAll('img[data-cleanup="true"]')
    images.forEach(img => {
      if (img.parentNode) {
        img.parentNode.removeChild(img)
      }
    })
  }

  cleanupEventListeners() {
    // This would be called by components to clean up their listeners
    // Components should register their cleanup functions
  }

  destroy() {
    if (this.intervalId) {
      clearInterval(this.intervalId)
    }
    this.performCleanup()
    this.cleanupTasks.clear()
  }
}

// React hook for memory management
export const useMemoryCleanup = (cleanupFn: () => void) => {
  useEffect(() => {
    const memoryManager = MemoryManager.getInstance()
    memoryManager.addCleanupTask(cleanupFn)

    return () => {
      memoryManager.removeCleanupTask(cleanupFn)
    }
  }, [cleanupFn])
}