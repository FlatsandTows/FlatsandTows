import { useState, useEffect } from 'react'
import { User } from '@supabase/supabase-js'
import { supabase, Profile, getProfile, isDemo } from '../lib/supabase'

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let mounted = true

    const initializeAuth = async () => {
      try {
        if (isDemo) {
          // Demo mode - set demo user and profile
          const demoUser = { id: 'demo-user-id', email: 'demo@example.com' } as User
          const demoProfile = await getProfile('demo-user-id')
          
          if (mounted) {
            setUser(demoUser)
            setProfile(demoProfile)
            setLoading(false)
          }
          return
        }

        // Get initial session
        const { data: { session }, error: sessionError } = await supabase!.auth.getSession()
        
        if (sessionError) {
          throw sessionError
        }

        if (mounted) {
          setUser(session?.user ?? null)
          if (session?.user) {
            await loadProfile(session.user.id)
          } else {
            setLoading(false)
          }
        }
      } catch (error) {
        console.error('Auth initialization error:', error)
        if (mounted) {
          setLoading(false)
        }
      }
    }

    // Listen for auth changes (only in non-demo mode)
    let subscription: any = null
    if (!isDemo && supabase) {
      subscription = supabase.auth.onAuthStateChange(
        async (event, session) => {
          if (!mounted) return

          try {
            setUser(session?.user ?? null)
            
            if (session?.user) {
              await loadProfile(session.user.id)
            } else {
              setProfile(null)
              setLoading(false)
            }
          } catch (error) {
            console.error('Auth state change error:', error)
            setLoading(false)
          }
        }
      )
    }

    const loadProfile = async (userId: string) => {
      try {
        const profileData = await getProfile(userId)
        if (mounted) {
          setProfile(profileData)
        }
      } catch (error) {
        console.error('Error loading profile:', error)
      } finally {
        if (mounted) {
          setLoading(false)
        }
      }
    }

    initializeAuth()

    return () => {
      mounted = false
      if (subscription?.data?.subscription) {
        subscription.data.subscription.unsubscribe()
      }
    }
  }, [])

  return {
    user,
    profile,
    loading,
    isAuthenticated: !!user,
    isInstaller: profile?.role === 'installer',
    isCustomer: profile?.role === 'customer',
    isVIP: profile?.membership_type === 'vip',
    isPremium: profile?.membership_type === 'premium'
  }
}