import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

// Real-time hooks for live updates

export const useServiceRequestUpdates = (requestId: string) => {
  const [request, setRequest] = useState(null)
  const [bids, setBids] = useState([])

  useEffect(() => {
    if (!requestId) return

    // Subscribe to request updates
    const requestChannel = supabase
      .channel(`service_request_${requestId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'service_requests',
        filter: `id=eq.${requestId}`
      }, (payload) => {
        setRequest(payload.new)
      })
      .subscribe()

    // Subscribe to new bids
    const bidsChannel = supabase
      .channel(`bids_${requestId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'bids',
        filter: `request_id=eq.${requestId}`
      }, (payload) => {
        setBids(prev => [...prev, payload.new])
      })
      .subscribe()

    return () => {
      requestChannel.unsubscribe()
      bidsChannel.unsubscribe()
    }
  }, [requestId])

  return { request, bids }
}

export const useInstallerLocation = (installerId: string) => {
  const [location, setLocation] = useState(null)

  useEffect(() => {
    if (!installerId) return

    const channel = supabase
      .channel(`installer_location_${installerId}`)
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'installer_profiles',
        filter: `id=eq.${installerId}`
      }, (payload) => {
        setLocation(payload.new.current_location)
      })
      .subscribe()

    return () => channel.unsubscribe()
  }, [installerId])

  return location
}

export const useJobUpdates = (jobId: string) => {
  const [job, setJob] = useState(null)

  useEffect(() => {
    if (!jobId) return

    const channel = supabase
      .channel(`job_${jobId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'jobs',
        filter: `id=eq.${jobId}`
      }, (payload) => {
        setJob(payload.new)
      })
      .subscribe()

    return () => channel.unsubscribe()
  }, [jobId])

  return job
}