import React, { useState, useEffect, Suspense } from 'react'
import { ErrorBoundary } from './lib/errorBoundary'
import { LoadingFallback } from './components/LoadingFallback'
import { useAuth } from './hooks/useAuth'
import { isDemo } from './lib/supabase'

// Lazy load components for better performance
const EnhancedLandingPage = React.lazy(() => 
  import('./components/EnhancedLandingPage').then(module => ({ default: module.EnhancedLandingPage }))
)
const FlatsAndTowsApp = React.lazy(() => import('./flats-tows-app'))

function App() {
  const { user, profile, loading } = useAuth()
  const [showLanding, setShowLanding] = useState(true)
  const [isInitialized, setIsInitialized] = useState(false)

  // Initialize app
  useEffect(() => {
    const initializeApp = async () => {
      try {
        // Show demo notice if in demo mode
        if (isDemo) {
          console.log('🚀 Running in DEMO MODE - No database connection required')
        }
        
        setIsInitialized(true)
      } catch (error) {
        console.error('App initialization failed:', error)
      }
    }

    initializeApp()
  }, [])

  // Determine if we should show landing page
  useEffect(() => {
    if (user && profile) {
      setShowLanding(false)
    }
  }, [user, profile])

  // Show loading screen during initialization
  if (!isInitialized || loading) {
    return (
      <LoadingFallback 
        message={isDemo ? "Loading demo marketplace..." : "Initializing cosmic marketplace..."} 
        type="cosmic" 
      />
    )
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen">
        {/* Demo Mode Banner */}
        {isDemo && (
          <div className="bg-yellow-500/20 border-b border-yellow-500/30 p-2 text-center">
            <p className="text-yellow-300 text-sm font-semibold">
              🚀 DEMO MODE - Experience the full app without database setup
            </p>
          </div>
        )}
        
        <Suspense fallback={<LoadingFallback type="cosmic" />}>
          {showLanding && !user ? (
            <EnhancedLandingPage 
              onSignupSuccess={() => setShowLanding(false)} 
            />
          ) : (
            <FlatsAndTowsApp />
          )}
        </Suspense>
      </div>
    </ErrorBoundary>
  )
}

export default App