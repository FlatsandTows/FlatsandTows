import React, { useState, useEffect } from 'react'
import { Package, MapPin, Clock, DollarSign, Truck, ArrowRight, Plus, Minus, Calendar, AlertCircle, CheckCircle, Star, Navigation, Phone } from 'lucide-react'
import { LocationPicker } from './LocationPicker'
import { CustomOfferModal } from './CustomOfferModal'
import { createCustomOffer, getCustomOffers, CustomOffer } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'

interface PickupDeliveryFlowProps {
  onComplete: (request: any) => void
  onBack: () => void
}

export const PickupDeliveryFlow: React.FC<PickupDeliveryFlowProps> = ({ onComplete, onBack }) => {
  const { user } = useAuth()
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [showCustomOfferModal, setShowCustomOfferModal] = useState(false)
  const [selectedInstaller, setSelectedInstaller] = useState(null)
  const [customOffers, setCustomOffers] = useState<CustomOffer[]>([])
  
  const [requestData, setRequestData] = useState({
    delivery_type: 'pickup_and_delivery',
    item_details: {
      type: 'auto_parts',
      description: '',
      quantity: 1,
      weight: '',
      dimensions: '',
      special_handling: ''
    },
    pickup_location: null,
    delivery_location: null,
    preferred_pickup_time: '',
    preferred_delivery_time: '',
    max_budget: '',
    description: '',
    urgency_level: 2
  })

  const deliveryTypes = [
    {
      id: 'pickup_only',
      name: 'Pickup Only',
      description: 'Pick up items from a location',
      icon: Package,
      color: 'from-blue-500 to-cyan-600'
    },
    {
      id: 'delivery_only',
      name: 'Delivery Only',
      description: 'Deliver items to a location',
      icon: Truck,
      color: 'from-green-500 to-emerald-600'
    },
    {
      id: 'pickup_and_delivery',
      name: 'Pickup & Delivery',
      description: 'Full pickup and delivery service',
      icon: ArrowRight,
      color: 'from-purple-500 to-pink-600'
    }
  ]

  const itemTypes = [
    { id: 'auto_parts', name: 'Auto Parts', description: 'Engine parts, filters, belts, etc.' },
    { id: 'tires', name: 'Tires', description: 'New or used tires' },
    { id: 'other', name: 'Other', description: 'Other automotive items' }
  ]

  const mockInstallers = [
    {
      id: 'installer-1',
      business_name: 'Quick Parts Delivery',
      rating: 4.9,
      total_jobs: 156,
      specialties: ['pickup_delivery'],
      is_premium: true,
      response_time: '15 min',
      base_rates: { pickup_delivery: 35 }
    },
    {
      id: 'installer-2',
      business_name: 'Auto Express Courier',
      rating: 4.7,
      total_jobs: 89,
      specialties: ['pickup_delivery'],
      is_premium: false,
      response_time: '25 min',
      base_rates: { pickup_delivery: 30 }
    }
  ]

  const updateRequestData = (field: string, value: any) => {
    setRequestData(prev => ({ ...prev, [field]: value }))
  }

  const updateItemDetails = (field: string, value: any) => {
    setRequestData(prev => ({
      ...prev,
      item_details: { ...prev.item_details, [field]: value }
    }))
  }

  const handleSubmitRequest = async () => {
    setLoading(true)
    setError('')

    try {
      // Validate required fields
      if (!requestData.pickup_location && requestData.delivery_type !== 'delivery_only') {
        throw new Error('Pickup location is required')
      }
      if (!requestData.delivery_location && requestData.delivery_type !== 'pickup_only') {
        throw new Error('Delivery location is required')
      }
      if (!requestData.item_details.description) {
        throw new Error('Item description is required')
      }

      // Create service request
      const request = {
        id: `demo-request-${Date.now()}`,
        customer_id: user?.id || 'demo-user',
        service_type: 'pickup_delivery',
        status: 'bidding',
        location: requestData.pickup_location || requestData.delivery_location,
        address: requestData.pickup_location?.address || requestData.delivery_location?.address,
        description: requestData.description,
        urgency_level: requestData.urgency_level,
        max_budget: requestData.max_budget ? parseFloat(requestData.max_budget) : null,
        delivery_type: requestData.delivery_type,
        pickup_location: requestData.pickup_location,
        delivery_location: requestData.delivery_location,
        item_details: requestData.item_details,
        preferred_pickup_time: requestData.preferred_pickup_time,
        preferred_delivery_time: requestData.preferred_delivery_time,
        created_at: new Date().toISOString()
      }

      setStep(4) // Move to offers step
      
      // Simulate receiving offers
      setTimeout(() => {
        const demoOffers = mockInstallers.map(installer => ({
          id: `offer-${installer.id}`,
          request_id: request.id,
          installer_id: installer.id,
          installer,
          offer_type: 'standard_bid',
          base_price: installer.base_rates.pickup_delivery,
          custom_pricing: {
            pickup_fee: requestData.delivery_type !== 'delivery_only' ? 15 : 0,
            delivery_fee: requestData.delivery_type !== 'pickup_only' ? 20 : 0,
            handling_fee: 5
          },
          total_price: installer.base_rates.pickup_delivery + 
                      (requestData.delivery_type !== 'delivery_only' ? 15 : 0) +
                      (requestData.delivery_type !== 'pickup_only' ? 20 : 0) + 5,
          estimated_pickup_time: '2-3 hours',
          estimated_delivery_time: '4-6 hours',
          message: `Professional ${requestData.delivery_type.replace('_', ' ')} service with careful handling`,
          status: 'pending',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }))
        setCustomOffers(demoOffers)
      }, 2000)

    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleAcceptOffer = (offer: CustomOffer) => {
    onComplete({
      request: requestData,
      accepted_offer: offer,
      service_type: 'pickup_delivery'
    })
  }

  const handleCustomOffer = (installer: any) => {
    setSelectedInstaller(installer)
    setShowCustomOfferModal(true)
  }

  const handleCustomOfferSubmit = async (customOfferData: any) => {
    try {
      const offer = await createCustomOffer({
        request_id: 'demo-request',
        installer_id: selectedInstaller.id,
        offer_type: 'custom_offer',
        ...customOfferData
      })
      
      setCustomOffers(prev => [...prev, { ...offer, installer: selectedInstaller }])
      setShowCustomOfferModal(false)
    } catch (error) {
      console.error('Error creating custom offer:', error)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-800 to-blue-900 p-4 pt-20">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="text-center mb-6 mt-8">
          <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Package className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Pickup & Delivery</h2>
          <p className="text-white/80">Auto parts and tire delivery service</p>
          
          {/* Progress Indicator */}
          <div className="flex justify-center space-x-2 mt-4">
            {[1, 2, 3, 4].map((stepNum) => (
              <div
                key={stepNum}
                className={`w-3 h-3 rounded-full ${
                  stepNum <= step ? 'bg-purple-500' : 'bg-white/20'
                }`}
              />
            ))}
          </div>
        </div>

        {error && (
          <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3 mb-6">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-red-400" />
              <p className="text-red-300 text-sm">{error}</p>
            </div>
          </div>
        )}

        {/* Step 1: Service Type */}
        {step === 1 && (
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-white mb-4">Select Service Type</h3>
            
            <div className="space-y-3">
              {deliveryTypes.map((type) => {
                const IconComponent = type.icon
                return (
                  <button
                    key={type.id}
                    onClick={() => updateRequestData('delivery_type', type.id)}
                    className={`w-full p-4 rounded-xl border transition-all ${
                      requestData.delivery_type === type.id
                        ? 'bg-purple-500/20 border-purple-500/50'
                        : 'bg-white/10 border-white/20 hover:bg-white/20'
                    }`}
                  >
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 bg-gradient-to-r ${type.color} rounded-lg flex items-center justify-center`}>
                        <IconComponent className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-left">
                        <div className="text-white font-semibold">{type.name}</div>
                        <div className="text-white/60 text-sm">{type.description}</div>
                      </div>
                    </div>
                  </button>
                )
              })}
            </div>

            <button
              onClick={() => setStep(2)}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-600 text-white py-3 rounded-lg font-semibold hover:scale-105 transition-transform"
            >
              Continue
            </button>
          </div>
        )}

        {/* Step 2: Item Details */}
        {step === 2 && (
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-white mb-4">Item Details</h3>
            
            {/* Item Type */}
            <div>
              <label className="block text-white/80 text-sm font-medium mb-2">Item Type</label>
              <div className="space-y-2">
                {itemTypes.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => updateItemDetails('type', type.id)}
                    className={`w-full p-3 rounded-lg border text-left transition-all ${
                      requestData.item_details.type === type.id
                        ? 'bg-purple-500/20 border-purple-500/50'
                        : 'bg-white/10 border-white/20 hover:bg-white/20'
                    }`}
                  >
                    <div className="text-white font-medium">{type.name}</div>
                    <div className="text-white/60 text-sm">{type.description}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-white/80 text-sm font-medium mb-2">Item Description *</label>
              <textarea
                value={requestData.item_details.description}
                onChange={(e) => updateItemDetails('description', e.target.value)}
                placeholder="Describe the items to be picked up/delivered..."
                className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-white/50 text-sm focus:outline-none focus:border-purple-500"
                rows={3}
              />
            </div>

            {/* Quantity */}
            <div>
              <label className="block text-white/80 text-sm font-medium mb-2">Quantity</label>
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => updateItemDetails('quantity', Math.max(1, requestData.item_details.quantity - 1))}
                  className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center text-white hover:bg-white/30"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="text-white font-semibold text-lg w-12 text-center">
                  {requestData.item_details.quantity}
                </span>
                <button
                  onClick={() => updateItemDetails('quantity', requestData.item_details.quantity + 1)}
                  className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center text-white hover:bg-white/30"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Optional Details */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-white/80 text-sm font-medium mb-2">Weight (lbs)</label>
                <input
                  type="number"
                  value={requestData.item_details.weight}
                  onChange={(e) => updateItemDetails('weight', e.target.value)}
                  placeholder="Optional"
                  className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-white/50 text-sm focus:outline-none focus:border-purple-500"
                />
              </div>
              <div>
                <label className="block text-white/80 text-sm font-medium mb-2">Dimensions</label>
                <input
                  type="text"
                  value={requestData.item_details.dimensions}
                  onChange={(e) => updateItemDetails('dimensions', e.target.value)}
                  placeholder="L x W x H"
                  className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-white/50 text-sm focus:outline-none focus:border-purple-500"
                />
              </div>
            </div>

            {/* Special Handling */}
            <div>
              <label className="block text-white/80 text-sm font-medium mb-2">Special Handling</label>
              <input
                type="text"
                value={requestData.item_details.special_handling}
                onChange={(e) => updateItemDetails('special_handling', e.target.value)}
                placeholder="Fragile, heavy, requires tools, etc."
                className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-white/50 text-sm focus:outline-none focus:border-purple-500"
              />
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setStep(1)}
                className="flex-1 bg-white/20 text-white py-3 rounded-lg font-semibold"
              >
                Back
              </button>
              <button
                onClick={() => setStep(3)}
                disabled={!requestData.item_details.description}
                className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600 text-white py-3 rounded-lg font-semibold hover:scale-105 transition-transform disabled:opacity-50"
              >
                Continue
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Locations & Timing */}
        {step === 3 && (
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-white mb-4">Locations & Timing</h3>
            
            {/* Pickup Location */}
            {requestData.delivery_type !== 'delivery_only' && (
              <div>
                <h4 className="text-white font-semibold mb-3">📍 Pickup Location</h4>
                <LocationPicker
                  onLocationSelect={(location) => updateRequestData('pickup_location', location)}
                  className="mb-4"
                />
                
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Preferred Pickup Time</label>
                  <input
                    type="datetime-local"
                    value={requestData.preferred_pickup_time}
                    onChange={(e) => updateRequestData('preferred_pickup_time', e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>
            )}

            {/* Delivery Location */}
            {requestData.delivery_type !== 'pickup_only' && (
              <div>
                <h4 className="text-white font-semibold mb-3">🚚 Delivery Location</h4>
                <LocationPicker
                  onLocationSelect={(location) => updateRequestData('delivery_location', location)}
                  className="mb-4"
                />
                
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Preferred Delivery Time</label>
                  <input
                    type="datetime-local"
                    value={requestData.preferred_delivery_time}
                    onChange={(e) => updateRequestData('preferred_delivery_time', e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>
            )}

            {/* Budget & Urgency */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-white/80 text-sm font-medium mb-2">Max Budget</label>
                <input
                  type="number"
                  value={requestData.max_budget}
                  onChange={(e) => updateRequestData('max_budget', e.target.value)}
                  placeholder="Optional"
                  className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-white/50 text-sm focus:outline-none focus:border-purple-500"
                />
              </div>
              <div>
                <label className="block text-white/80 text-sm font-medium mb-2">Urgency (1-5)</label>
                <select
                  value={requestData.urgency_level}
                  onChange={(e) => updateRequestData('urgency_level', parseInt(e.target.value))}
                  className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                >
                  <option value={1}>1 - No rush</option>
                  <option value={2}>2 - Standard</option>
                  <option value={3}>3 - Moderate</option>
                  <option value={4}>4 - Urgent</option>
                  <option value={5}>5 - Emergency</option>
                </select>
              </div>
            </div>

            {/* Additional Notes */}
            <div>
              <label className="block text-white/80 text-sm font-medium mb-2">Additional Notes</label>
              <textarea
                value={requestData.description}
                onChange={(e) => updateRequestData('description', e.target.value)}
                placeholder="Any special instructions or requirements..."
                className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-white/50 text-sm focus:outline-none focus:border-purple-500"
                rows={3}
              />
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setStep(2)}
                className="flex-1 bg-white/20 text-white py-3 rounded-lg font-semibold"
              >
                Back
              </button>
              <button
                onClick={handleSubmitRequest}
                disabled={loading}
                className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600 text-white py-3 rounded-lg font-semibold hover:scale-105 transition-transform disabled:opacity-50"
              >
                {loading ? 'Submitting...' : 'Find Providers'}
              </button>
            </div>
          </div>
        )}

        {/* Step 4: Offers & Negotiation */}
        {step === 4 && (
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-white mb-4">Provider Offers</h3>
            
            {customOffers.length === 0 ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-white">Finding providers...</p>
                <p className="text-white/60 text-sm">Sending alerts to qualified couriers</p>
              </div>
            ) : (
              <div className="space-y-4">
                {customOffers.map((offer) => (
                  <div key={offer.id} className="bg-white/10 border border-white/20 rounded-xl p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                          <span className="text-white font-bold text-sm">
                            {offer.installer?.business_name?.charAt(0) || 'P'}
                          </span>
                        </div>
                        <div>
                          <div className="text-white font-semibold">{offer.installer?.business_name}</div>
                          <div className="flex items-center space-x-2 text-xs">
                            <Star className="w-3 h-3 text-yellow-400 fill-current" />
                            <span className="text-white/70">{offer.installer?.rating}</span>
                            <span className="text-white/50">• {offer.installer?.total_jobs} jobs</span>
                            {offer.installer?.is_premium && (
                              <span className="bg-yellow-500 text-black text-xs px-2 py-1 rounded-full font-bold">
                                PREMIUM
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-white font-bold text-xl">${offer.total_price}</div>
                        <div className="text-white/60 text-xs">Total</div>
                      </div>
                    </div>

                    {/* Pricing Breakdown */}
                    <div className="bg-white/5 rounded-lg p-3 mb-3">
                      <div className="text-white/80 text-sm font-medium mb-2">Pricing Breakdown:</div>
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span className="text-white/70">Base Service</span>
                          <span className="text-white">${offer.base_price}</span>
                        </div>
                        {offer.custom_pricing.pickup_fee > 0 && (
                          <div className="flex justify-between">
                            <span className="text-white/70">Pickup Fee</span>
                            <span className="text-white">${offer.custom_pricing.pickup_fee}</span>
                          </div>
                        )}
                        {offer.custom_pricing.delivery_fee > 0 && (
                          <div className="flex justify-between">
                            <span className="text-white/70">Delivery Fee</span>
                            <span className="text-white">${offer.custom_pricing.delivery_fee}</span>
                          </div>
                        )}
                        {offer.custom_pricing.handling_fee > 0 && (
                          <div className="flex justify-between">
                            <span className="text-white/70">Handling Fee</span>
                            <span className="text-white">${offer.custom_pricing.handling_fee}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Timing */}
                    <div className="flex items-center space-x-4 text-sm text-white/70 mb-3">
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>Pickup: {offer.estimated_pickup_time}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Truck className="w-4 h-4" />
                        <span>Delivery: {offer.estimated_delivery_time}</span>
                      </div>
                    </div>

                    {offer.message && (
                      <p className="text-white/80 text-sm italic mb-3">"{offer.message}"</p>
                    )}

                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleAcceptOffer(offer)}
                        className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white py-2 rounded-lg font-semibold text-sm hover:scale-105 transition-transform"
                      >
                        Accept ${offer.total_price}
                      </button>
                      <button
                        onClick={() => handleCustomOffer(offer.installer)}
                        className="bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold text-sm hover:bg-blue-500 transition-colors"
                      >
                        Negotiate
                      </button>
                      <button className="bg-white/20 text-white px-4 py-2 rounded-lg font-semibold text-sm hover:bg-white/30 transition-colors">
                        <Phone className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <button
              onClick={onBack}
              className="w-full bg-white/20 text-white py-3 rounded-lg font-semibold"
            >
              ← Back to Services
            </button>
          </div>
        )}
      </div>

      {/* Custom Offer Modal */}
      <CustomOfferModal
        isOpen={showCustomOfferModal}
        onClose={() => setShowCustomOfferModal(false)}
        installer={selectedInstaller}
        requestData={requestData}
        onSubmit={handleCustomOfferSubmit}
      />
    </div>
  )
}