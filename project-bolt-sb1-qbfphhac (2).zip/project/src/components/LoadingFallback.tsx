import React from 'react'
import { Loader2, Truck, Zap } from 'lucide-react'

interface LoadingFallbackProps {
  message?: string
  type?: 'default' | 'cosmic' | 'minimal'
}

export const LoadingFallback: React.FC<LoadingFallbackProps> = ({ 
  message = 'Loading...', 
  type = 'cosmic' 
}) => {
  if (type === 'minimal') {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
        <span className="ml-2 text-gray-600">{message}</span>
      </div>
    )
  }

  if (type === 'cosmic') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          {/* Cosmic Loading Animation */}
          <div className="relative w-24 h-24 mx-auto mb-8">
            {/* Central Orb */}
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 rounded-full animate-pulse"></div>
            
            {/* Rotating Rings */}
            <div className="absolute inset-2 border-2 border-cyan-300/50 rounded-full animate-spin"></div>
            <div className="absolute inset-4 border border-blue-300/30 rounded-full animate-spin-reverse"></div>
            
            {/* Energy Particles */}
            <div className="absolute top-2 left-2 w-2 h-2 bg-white rounded-full animate-ping"></div>
            <div className="absolute bottom-2 right-2 w-2 h-2 bg-cyan-300 rounded-full animate-ping delay-300"></div>
            <div className="absolute top-2 right-2 w-1 h-1 bg-blue-200 rounded-full animate-ping delay-700"></div>
            
            {/* Central Icon */}
            <div className="absolute inset-0 flex items-center justify-center">
              <Truck className="w-8 h-8 text-white animate-bounce" />
            </div>
          </div>
          
          <h2 className="text-2xl font-bold text-white mb-2">Flats & Tows</h2>
          <p className="text-white/80 mb-4">{message}</p>
          
          {/* Progress Indicators */}
          <div className="flex justify-center space-x-2">
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-100"></div>
            <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce delay-200"></div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex items-center justify-center min-h-64 bg-gray-50">
      <div className="text-center">
        <div className="w-16 h-16 border-4 border-blue-500/30 border-t-blue-500 rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-gray-600 font-medium">{message}</p>
      </div>
    </div>
  )
}

// Skeleton loading components
export const SkeletonCard: React.FC = () => (
  <div className="bg-white/10 rounded-xl p-4 animate-pulse">
    <div className="h-4 bg-white/20 rounded w-3/4 mb-2"></div>
    <div className="h-3 bg-white/20 rounded w-1/2 mb-4"></div>
    <div className="h-8 bg-white/20 rounded w-full"></div>
  </div>
)

export const SkeletonList: React.FC<{ count?: number }> = ({ count = 3 }) => (
  <div className="space-y-4">
    {Array.from({ length: count }).map((_, i) => (
      <SkeletonCard key={i} />
    ))}
  </div>
)