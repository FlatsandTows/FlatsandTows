import React from 'react'

interface CosmicLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl'
  className?: string
}

export const CosmicLogo: React.FC<CosmicLogoProps> = ({ size = 'md', className = '' }) => {
  const sizeClasses = {
    sm: 'w-32 h-12',
    md: 'w-48 h-18',
    lg: 'w-64 h-24',
    xl: 'w-80 h-30'
  }

  return (
    <div className={`${sizeClasses[size]} ${className} relative group cursor-pointer`}>
      {/* Cosmic Background Aura */}
      <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-blue-500/20 rounded-2xl blur-xl animate-pulse"></div>
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 via-indigo-600/10 to-purple-600/10 rounded-xl blur-lg animate-pulse delay-500"></div>
      
      {/* Main Logo Container */}
      <div className="relative bg-gradient-to-br from-slate-900/95 via-indigo-900/95 to-purple-900/95 backdrop-blur-xl border border-cyan-400/30 rounded-2xl p-4 shadow-2xl group-hover:scale-105 transition-all duration-500">
        
        {/* Cosmic Energy Rings */}
        <div className="absolute -inset-1 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 rounded-2xl opacity-20 animate-spin-slow"></div>
        <div className="absolute -inset-2 bg-gradient-to-r from-purple-600 via-pink-500 to-cyan-400 rounded-2xl opacity-10 animate-spin-reverse"></div>
        
        {/* Logo Content */}
        <div className="relative flex items-center justify-center space-x-3">
          
          {/* Cosmic Symbol */}
          <div className="relative">
            {/* Central Orb */}
            <div className="w-12 h-12 bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-2xl relative overflow-hidden">
              {/* Inner Energy Core */}
              <div className="w-8 h-8 bg-gradient-to-br from-white via-cyan-200 to-blue-300 rounded-full animate-pulse shadow-inner"></div>
              
              {/* Rotating Energy Rings */}
              <div className="absolute inset-0 border-2 border-cyan-300/50 rounded-full animate-spin"></div>
              <div className="absolute inset-1 border border-blue-300/30 rounded-full animate-spin-reverse"></div>
              
              {/* Energy Particles */}
              <div className="absolute top-1 left-1 w-1 h-1 bg-white rounded-full animate-ping"></div>
              <div className="absolute bottom-1 right-1 w-1 h-1 bg-cyan-300 rounded-full animate-ping delay-300"></div>
              <div className="absolute top-1 right-1 w-0.5 h-0.5 bg-blue-200 rounded-full animate-ping delay-700"></div>
            </div>
            
            {/* Orbital Elements */}
            <div className="absolute -top-2 -right-2 w-3 h-3 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full animate-bounce shadow-lg"></div>
            <div className="absolute -bottom-2 -left-2 w-2 h-2 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full animate-bounce delay-500 shadow-lg"></div>
          </div>
          
          {/* Typography */}
          <div className="flex flex-col">
            {/* Main Text */}
            <div className="text-2xl font-black tracking-tight">
              <span className="bg-gradient-to-r from-cyan-300 via-blue-200 to-white bg-clip-text text-transparent drop-shadow-2xl">
                FLATS
              </span>
              <span className="text-white/90 mx-1">&</span>
              <span className="bg-gradient-to-r from-white via-purple-200 to-cyan-300 bg-clip-text text-transparent drop-shadow-2xl">
                TOWS
              </span>
            </div>
            
            {/* Cosmic Subtitle */}
            <div className="text-xs font-bold tracking-widest">
              <span className="bg-gradient-to-r from-cyan-400 via-purple-400 to-blue-400 bg-clip-text text-transparent">
                COSMIC ROADSIDE DOMINION
              </span>
            </div>
          </div>
          
          {/* Power Indicators */}
          <div className="flex flex-col space-y-1">
            <div className="w-1 h-3 bg-gradient-to-t from-green-500 to-emerald-400 rounded-full animate-pulse"></div>
            <div className="w-1 h-4 bg-gradient-to-t from-blue-500 to-cyan-400 rounded-full animate-pulse delay-200"></div>
            <div className="w-1 h-3 bg-gradient-to-t from-purple-500 to-pink-400 rounded-full animate-pulse delay-400"></div>
          </div>
        </div>
        
        {/* Cosmic Energy Waves */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden rounded-2xl pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-pulse"></div>
          <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-purple-400 to-transparent animate-pulse delay-1000"></div>
          <div className="absolute top-0 left-0 w-0.5 h-full bg-gradient-to-b from-transparent via-blue-400 to-transparent animate-pulse delay-500"></div>
          <div className="absolute top-0 right-0 w-0.5 h-full bg-gradient-to-b from-transparent via-pink-400 to-transparent animate-pulse delay-1500"></div>
        </div>
      </div>
      
      {/* Holographic Effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/5 via-transparent to-purple-500/5 rounded-2xl group-hover:from-cyan-500/10 group-hover:to-purple-500/10 transition-all duration-500"></div>
    </div>
  )
}

// Custom CSS for advanced animations
const style = document.createElement('style')
style.textContent = `
  @keyframes spin-slow {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }
  
  @keyframes spin-reverse {
    from { transform: rotate(360deg); }
    to { transform: rotate(0deg); }
  }
  
  .animate-spin-slow {
    animation: spin-slow 8s linear infinite;
  }
  
  .animate-spin-reverse {
    animation: spin-reverse 12s linear infinite;
  }
`
document.head.appendChild(style)