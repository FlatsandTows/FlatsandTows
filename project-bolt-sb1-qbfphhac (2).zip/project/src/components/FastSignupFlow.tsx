import React, { useState } from 'react'
import { X, Mail, Phone, MapPin, Zap, Crown, CheckCircle, ArrowRight, Sparkles, Shield, FileText, Camera } from 'lucide-react'
import { signUp } from '../lib/supabase'
import { LegalDisclaimers } from './LegalDisclaimers'
import { ProviderVerificationFlow } from './ProviderVerificationFlow'

interface FastSignupFlowProps {
  isOpen: boolean
  onClose: () => void
  userType: 'customer' | 'installer'
  onSuccess: () => void
}

export const FastSignupFlow: React.FC<FastSignupFlowProps> = ({ isOpen, onClose, userType, onSuccess }) => {
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [showLegalDisclaimers, setShowLegalDisclaimers] = useState(false)
  const [showVerification, setShowVerification] = useState(false)
  const [legalAccepted, setLegalAccepted] = useState(false)
  const [newUserId, setNewUserId] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    email: '',
    phone: '',
    name: '',
    location: ''
  })

  if (!isOpen) return null

  const handleQuickSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Show legal disclaimers first
    if (!legalAccepted) {
      setShowLegalDisclaimers(true)
      return
    }

    setLoading(true)
    setError('')

    try {
      // Generate a temporary password
      const tempPassword = `temp${Math.random().toString(36).substr(2, 8)}`
      
      const result = await signUp(formData.email, tempPassword, {
        full_name: formData.name,
        phone: formData.phone,
        role: userType,
        city: formData.location.split(',')[0]?.trim() || '',
        state: formData.location.split(',')[1]?.trim() || ''
      })
      
      if (result.user) {
        setNewUserId(result.user.id)
        
        if (userType === 'installer') {
          // Show verification flow for installers
          setShowVerification(true)
        } else {
          // Complete signup for customers
          setStep(3)
          setTimeout(() => {
            onSuccess()
            onClose()
          }, 2000)
        }
      }
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleLegalAcceptance = (accepted: boolean) => {
    setLegalAccepted(accepted)
    setShowLegalDisclaimers(false)
    
    if (accepted) {
      // Proceed with signup
      handleQuickSignup(new Event('submit') as any)
    }
  }

  const handleVerificationComplete = (verificationData: any) => {
    setShowVerification(false)
    setStep(3) // Success step
    setTimeout(() => {
      onSuccess()
      onClose()
    }, 2000)
  }

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  return (
    <>
      <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div className="bg-gradient-to-br from-slate-900/95 to-purple-900/95 backdrop-blur-xl border border-purple-500/30 rounded-3xl max-w-md w-full overflow-hidden">
          
          {step === 1 && (
            <>
              {/* Header */}
              <div className="relative bg-gradient-to-r from-purple-600 to-pink-600 p-6 text-center">
                <button onClick={onClose} className="absolute top-4 right-4 text-white/70 hover:text-white">
                  <X className="w-6 h-6" />
                </button>
                
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  {userType === 'installer' ? <Crown className="w-8 h-8 text-white" /> : <Zap className="w-8 h-8 text-white" />}
                </div>
                
                <h3 className="text-2xl font-bold text-white mb-2">
                  {userType === 'installer' ? '💰 Start Earning Today' : '🚨 Get Help in 60 Seconds'}
                </h3>
                <p className="text-white/80 text-sm">
                  {userType === 'installer' 
                    ? 'Join 2,000+ installers earning $300+ per day' 
                    : 'Emergency roadside assistance in under 15 minutes'
                  }
                </p>
              </div>

              {/* Quick Benefits */}
              <div className="p-6">
                <div className="grid grid-cols-2 gap-3 mb-6">
                  {(userType === 'installer' ? [
                    { icon: '⚡', text: 'Instant payouts' },
                    { icon: '🎯', text: 'AI job matching' },
                    { icon: '📱', text: 'Mobile app' },
                    { icon: '🛡️', text: 'Insurance covered' }
                  ] : [
                    { icon: '🚨', text: '24/7 emergency' },
                    { icon: '⚡', text: '15-min response' },
                    { icon: '💳', text: 'Secure payment' },
                    { icon: '⭐', text: '4.9★ rated' }
                  ]).map((benefit, index) => (
                    <div key={index} className="bg-white/10 rounded-lg p-3 text-center">
                      <div className="text-2xl mb-1">{benefit.icon}</div>
                      <div className="text-white text-xs font-medium">{benefit.text}</div>
                    </div>
                  ))}
                </div>

                {/* Fast-Track Verification for Installers */}
                {userType === 'installer' && (
                  <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-xl p-4 mb-6">
                    <h4 className="text-green-300 font-semibold mb-2 flex items-center">
                      <Zap className="w-4 h-4 mr-2" />
                      🚀 FAST-TRACK VERIFICATION
                    </h4>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div className="text-center">
                        <FileText className="w-6 h-6 text-green-400 mx-auto mb-1" />
                        <div className="text-green-200">1099 Tax Form</div>
                      </div>
                      <div className="text-center">
                        <Shield className="w-6 h-6 text-blue-400 mx-auto mb-1" />
                        <div className="text-blue-200">Driver's License</div>
                      </div>
                      <div className="text-center">
                        <Camera className="w-6 h-6 text-purple-400 mx-auto mb-1" />
                        <div className="text-purple-200">Profile Photo</div>
                      </div>
                    </div>
                    <div className="text-center mt-3">
                      <span className="bg-yellow-500 text-black text-xs px-3 py-1 rounded-full font-bold">
                        ⚡ 24-HOUR APPROVAL
                      </span>
                    </div>
                  </div>
                )}

                <button
                  onClick={() => setStep(2)}
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-4 rounded-xl font-bold text-lg hover:scale-105 transition-transform flex items-center justify-center"
                >
                  <Sparkles className="w-5 h-5 mr-2" />
                  Get Started - 30 Seconds
                  <ArrowRight className="w-5 h-5 ml-2" />
                </button>
                
                <p className="text-white/60 text-xs text-center mt-3">
                  No credit card required • Join 50,000+ users
                </p>
              </div>
            </>
          )}

          {step === 2 && (
            <>
              {/* Quick Form */}
              <div className="p-6 border-b border-purple-500/20">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold text-white">Almost Done!</h3>
                  <div className="text-purple-300 text-sm">30 seconds</div>
                </div>
                <p className="text-purple-200 text-sm mt-1">
                  {userType === 'installer' 
                    ? 'Basic info + instant verification' 
                    : 'Just 4 quick details to get started'
                  }
                </p>
              </div>
              
              <form onSubmit={handleQuickSignup} className="p-6 space-y-4">
                {error && (
                  <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3">
                    <p className="text-red-300 text-sm">{error}</p>
                  </div>
                )}

                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">
                    📧 Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/50" />
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => updateFormData('email', e.target.value)}
                      className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">
                    📱 Phone Number
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/50" />
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => updateFormData('phone', e.target.value)}
                      className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                      placeholder="(555) 123-4567"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">
                    👤 {userType === 'installer' ? 'Business Name' : 'Your Name'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => updateFormData('name', e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                    placeholder={userType === 'installer' ? 'Your Business Name' : 'Your Full Name'}
                  />
                </div>

                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">
                    📍 Location
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/50" />
                    <input
                      type="text"
                      required
                      value={formData.location}
                      onChange={(e) => updateFormData('location', e.target.value)}
                      className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                      placeholder="Miami, FL"
                    />
                  </div>
                </div>

                {/* Legal Notice */}
                <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3">
                  <div className="flex items-start space-x-2">
                    <Shield className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-red-300 text-xs font-semibold mb-1">LEGAL DISCLAIMERS REQUIRED</p>
                      <p className="text-red-200 text-xs">
                        You must review and accept our legal disclaimers before creating your account. 
                        {userType === 'installer' && ' Plus instant verification for faster approval!'}
                      </p>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500 text-white py-4 rounded-xl font-bold text-lg transition-all duration-300 disabled:opacity-50 flex items-center justify-center"
                >
                  {loading ? (
                    <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <Shield className="w-5 h-5 mr-2" />
                      {userType === 'installer' 
                        ? 'Create Account + Verify Instantly' 
                        : 'Review Legal Terms & Create Account'
                      }
                    </>
                  )}
                </button>

                <p className="text-white/60 text-xs text-center">
                  By continuing, you agree to review our legal disclaimers
                  {userType === 'installer' && ' and complete instant verification'}
                </p>
              </form>
            </>
          )}

          {step === 3 && (
            <div className="p-8 text-center">
              <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-3">Welcome Aboard! 🎉</h3>
              <p className="text-white/80 mb-4">
                {userType === 'installer' 
                  ? 'Verification complete! You\'re ready to start earning within 24 hours.'
                  : 'Your account is ready! You can now request emergency assistance.'
                }
              </p>
              <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-4">
                <p className="text-green-300 text-sm font-semibold">
                  ⚡ {userType === 'installer' ? 'First job bonus: +$50' : 'First service: 20% off'}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Legal Disclaimers Modal */}
      <LegalDisclaimers
        userType={userType}
        onAccept={handleLegalAcceptance}
        isOpen={showLegalDisclaimers}
        onClose={() => setShowLegalDisclaimers(false)}
        context="signup"
      />

      {/* Provider Verification Flow */}
      {showVerification && newUserId && (
        <ProviderVerificationFlow
          isOpen={showVerification}
          onClose={() => setShowVerification(false)}
          onComplete={handleVerificationComplete}
          installerId={newUserId}
        />
      )}
    </>
  )
}