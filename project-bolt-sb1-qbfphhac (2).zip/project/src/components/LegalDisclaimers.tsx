import React, { useState } from 'react'
import { Shield, AlertTriangle, CheckCircle, Scale, FileText, Lock, Eye, X } from 'lucide-react'

interface LegalDisclaimersProps {
  userType: 'customer' | 'installer'
  onAccept: (accepted: boolean) => void
  isOpen: boolean
  onClose: () => void
  context: 'signup' | 'checkout'
}

export const LegalDisclaimers: React.FC<LegalDisclaimersProps> = ({
  userType,
  onAccept,
  isOpen,
  onClose,
  context
}) => {
  const [currentSection, setCurrentSection] = useState(0)
  const [acceptedSections, setAcceptedSections] = useState<boolean[]>([])
  const [hasReadAll, setHasReadAll] = useState(false)

  if (!isOpen) return null

  const customerDisclaimers = [
    {
      title: "🛡️ SERVICE PROVIDER INDEPENDENCE",
      icon: Shield,
      content: `
        CRITICAL UNDERSTANDING: All service providers ("Installers") are INDEPENDENT CONTRACTORS, not employees or agents of Flats & Tows. We operate solely as a TECHNOLOGY PLATFORM connecting customers with independent service providers.

        • Flats & Tows does NOT provide roadside assistance services directly
        • We do NOT employ, supervise, or control any service providers
        • All services are performed by independent third-party contractors
        • Service quality, safety, and performance are the SOLE responsibility of the chosen installer
        • We are NOT liable for any actions, omissions, or negligence of service providers
      `
    },
    {
      title: "⚠️ ASSUMPTION OF RISK & RELEASE",
      icon: AlertTriangle,
      content: `
        BY USING THIS SERVICE, YOU ACKNOWLEDGE AND ASSUME ALL RISKS INCLUDING:

        • Vehicle damage during service (mechanical, electrical, cosmetic)
        • Personal injury or property damage at service location
        • Theft, loss, or damage to personal property
        • Service delays, cancellations, or no-shows
        • Inadequate or improper service performance
        • Weather-related risks and hazardous conditions

        YOU HEREBY RELEASE Flats & Tows from ALL LIABILITY for any damages, injuries, losses, or claims arising from or related to services provided by independent contractors.
      `
    },
    {
      title: "💳 PAYMENT & FINANCIAL TERMS",
      icon: FileText,
      content: `
        BINDING FINANCIAL OBLIGATIONS:

        • ALL PAYMENTS ARE FINAL AND NON-REFUNDABLE except as required by law
        • Platform fees (12% + $2.99) are NON-REFUNDABLE under any circumstances
        • Dispute resolution may result in partial refunds at our sole discretion
        • You authorize automatic payment processing upon service acceptance
        • Surge pricing may apply during high-demand periods (up to 3x base rates)
        • Additional charges may apply for premium services, after-hours, or emergency calls
        • Failed payments may result in account suspension and collection actions
      `
    },
    {
      title: "🚫 LIMITATION OF LIABILITY",
      icon: Scale,
      content: `
        MAXIMUM LIABILITY PROTECTION:

        • Our total liability is LIMITED to the amount you paid for the specific service
        • We are NOT liable for consequential, incidental, or punitive damages
        • No liability for lost wages, business interruption, or opportunity costs
        • No warranty of service availability, response times, or outcomes
        • Force majeure events (weather, natural disasters, etc.) void all guarantees
        • Class action lawsuits are PROHIBITED - disputes must be resolved individually
        • Arbitration is MANDATORY for all disputes exceeding $500
      `
    },
    {
      title: "📱 TECHNOLOGY & DATA DISCLAIMER",
      icon: Lock,
      content: `
        TECHNOLOGY LIMITATIONS:

        • GPS tracking may be inaccurate or unavailable
        • App functionality depends on internet connectivity and device compatibility
        • We do NOT guarantee real-time location accuracy or ETA predictions
        • System outages may prevent service requests or communications
        • Your data may be shared with service providers as necessary for service delivery
        • We use AI matching algorithms that may not always produce optimal results
        • Emergency services should be contacted directly for life-threatening situations
      `
    }
  ]

  const installerDisclaimers = [
    {
      title: "🏢 INDEPENDENT CONTRACTOR STATUS",
      icon: Shield,
      content: `
        MANDATORY CONTRACTOR RELATIONSHIP:

        • You are an INDEPENDENT CONTRACTOR, not an employee of Flats & Tows
        • You are responsible for ALL taxes, insurance, licenses, and permits
        • No employment benefits, workers compensation, or unemployment coverage
        • You control your work schedule, methods, and service delivery
        • You provide your own tools, equipment, and vehicle
        • You are solely responsible for compliance with all local, state, and federal laws
        • Flats & Tows has NO control over your work performance or methods
      `
    },
    {
      title: "🛡️ INSURANCE & LIABILITY REQUIREMENTS",
      icon: AlertTriangle,
      content: `
        MANDATORY INSURANCE COVERAGE:

        • You MUST maintain comprehensive general liability insurance (minimum $1M)
        • Commercial auto insurance covering business use of your vehicle
        • Professional liability insurance for your services
        • You are SOLELY LIABLE for all damages, injuries, or losses during service
        • You INDEMNIFY Flats & Tows against all claims arising from your services
        • Proof of insurance must be provided and kept current
        • Insurance lapses result in immediate account suspension
      `
    },
    {
      title: "💰 PAYMENT & COMMISSION STRUCTURE",
      icon: FileText,
      content: `
        BINDING FINANCIAL TERMS:

        • Platform commission: 12% of service price + $2.99 processing fee
        • Payments processed within 60 seconds of job completion
        • Chargebacks, refunds, or disputes may be deducted from your earnings
        • You are responsible for all payment processing fees
        • Tax reporting: 1099 forms issued for earnings over $600 annually
        • Account suspension may freeze pending payments
        • Fraudulent activity results in forfeiture of all earnings
      `
    },
    {
      title: "⚖️ SERVICE STANDARDS & COMPLIANCE",
      icon: Scale,
      content: `
        MANDATORY SERVICE REQUIREMENTS:

        • You warrant that you are properly licensed and qualified for all services offered
        • All work must comply with industry standards and local regulations
        • You are liable for warranty claims and service defects
        • Customer safety is your SOLE responsibility
        • Background checks and verification may be required
        • Account termination for safety violations, poor ratings, or misconduct
        • You may NOT subcontract work without explicit platform approval
      `
    },
    {
      title: "🚫 PLATFORM USAGE & RESTRICTIONS",
      icon: Lock,
      content: `
        BINDING USAGE TERMS:

        • Account termination may occur at any time for any reason
        • No guarantee of job availability or minimum income
        • Platform algorithms determine job matching and visibility
        • Customer information is confidential and may NOT be used for direct solicitation
        • You may NOT compete directly with the platform or solicit customers off-platform
        • Intellectual property rights belong exclusively to Flats & Tows
        • Violation of terms results in immediate account termination and legal action
      `
    }
  ]

  const disclaimers = userType === 'customer' ? customerDisclaimers : installerDisclaimers
  const currentDisclaimer = disclaimers[currentSection]

  const handleSectionAccept = () => {
    const newAccepted = [...acceptedSections]
    newAccepted[currentSection] = true
    setAcceptedSections(newAccepted)

    if (currentSection < disclaimers.length - 1) {
      setCurrentSection(currentSection + 1)
    } else {
      setHasReadAll(true)
    }
  }

  const handleFinalAccept = () => {
    onAccept(true)
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-br from-slate-900/95 to-red-900/95 backdrop-blur-xl border border-red-500/30 rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-red-600 to-orange-600 p-6 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <Scale className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-white">LEGAL DISCLAIMERS</h3>
              <p className="text-white/80 text-sm">
                {context === 'signup' ? 'Required for Account Creation' : 'Required Before Payment'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-white text-sm">
              Section {currentSection + 1} of {disclaimers.length}
            </div>
            <button onClick={onClose} className="text-white/70 hover:text-white">
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="bg-red-900/50 p-2">
          <div className="w-full bg-red-900/30 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-red-500 to-orange-500 h-2 rounded-full transition-all duration-500"
              style={{ width: `${((currentSection + 1) / disclaimers.length) * 100}%` }}
            ></div>
          </div>
        </div>

        {!hasReadAll ? (
          /* Current Disclaimer Section */
          <div className="p-8 overflow-y-auto max-h-[60vh]">
            <div className="flex items-center space-x-3 mb-6">
              <currentDisclaimer.icon className="w-8 h-8 text-red-400" />
              <h4 className="text-2xl font-bold text-white">{currentDisclaimer.title}</h4>
            </div>
            
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-6 mb-6">
              <pre className="text-white/90 whitespace-pre-wrap font-mono text-sm leading-relaxed">
                {currentDisclaimer.content.trim()}
              </pre>
            </div>

            <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-lg p-4 mb-6">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h5 className="text-yellow-300 font-semibold mb-2">CRITICAL LEGAL NOTICE</h5>
                  <p className="text-yellow-200 text-sm">
                    By proceeding, you acknowledge that you have READ, UNDERSTOOD, and AGREE to be legally bound by these terms. 
                    These disclaimers limit our liability and establish your responsibilities. 
                    Consult with an attorney if you have questions about these terms.
                  </p>
                </div>
              </div>
            </div>

            <button
              onClick={handleSectionAccept}
              className="w-full bg-gradient-to-r from-red-600 to-orange-600 text-white py-4 rounded-xl font-bold text-lg hover:scale-105 transition-transform flex items-center justify-center"
            >
              <CheckCircle className="w-5 h-5 mr-2" />
              I Have Read and Understand This Section
            </button>
          </div>
        ) : (
          /* Final Acceptance */
          <div className="p-8 text-center">
            <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-white" />
            </div>
            
            <h4 className="text-2xl font-bold text-white mb-4">FINAL LEGAL ACKNOWLEDGMENT</h4>
            
            <div className="bg-red-500/20 border border-red-500/30 rounded-xl p-6 mb-6">
              <p className="text-white/90 text-lg leading-relaxed">
                You have reviewed all {disclaimers.length} sections of our legal disclaimers. 
                By clicking "I ACCEPT ALL TERMS" below, you acknowledge that:
              </p>
              
              <ul className="text-white/80 text-left mt-4 space-y-2">
                <li>• You have read and understood all disclaimers</li>
                <li>• You agree to be legally bound by these terms</li>
                <li>• You understand the risks and limitations of liability</li>
                <li>• You waive certain legal rights and remedies</li>
                <li>• These terms are enforceable and binding</li>
              </ul>
            </div>

            <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-lg p-4 mb-6">
              <p className="text-yellow-200 text-sm">
                <strong>FINAL WARNING:</strong> These disclaimers significantly limit our liability and your legal remedies. 
                If you do not agree to these terms, you cannot use our platform.
              </p>
            </div>

            <div className="flex space-x-4">
              <button
                onClick={() => onAccept(false)}
                className="flex-1 bg-gray-600 text-white py-3 rounded-lg font-semibold"
              >
                I DO NOT ACCEPT
              </button>
              <button
                onClick={handleFinalAccept}
                className="flex-1 bg-gradient-to-r from-red-600 to-orange-600 text-white py-3 rounded-lg font-bold hover:scale-105 transition-transform"
              >
                I ACCEPT ALL TERMS
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}