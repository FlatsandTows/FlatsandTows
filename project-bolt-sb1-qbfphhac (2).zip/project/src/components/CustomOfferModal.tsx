import React, { useState } from 'react'
import { X, DollarSign, Clock, Package, Truck, Plus, Minus, AlertCircle, CheckCircle } from 'lucide-react'

interface CustomOfferModalProps {
  isOpen: boolean
  onClose: () => void
  installer: any
  requestData: any
  onSubmit: (offerData: any) => void
}

export const CustomOfferModal: React.FC<CustomOfferModalProps> = ({
  isOpen,
  onClose,
  installer,
  requestData,
  onSubmit
}) => {
  const [loading, setLoading] = useState(false)
  const [step, setStep] = useState(1)
  const [offerData, setOfferData] = useState({
    base_price: installer?.base_rates?.pickup_delivery || 35,
    custom_pricing: {
      pickup_fee: requestData?.delivery_type !== 'delivery_only' ? 15 : 0,
      delivery_fee: requestData?.delivery_type !== 'pickup_only' ? 20 : 0,
      handling_fee: 5,
      rush_fee: 0,
      distance_fee: 0,
      item_specific_fee: 0
    },
    estimated_pickup_time: '2-3 hours',
    estimated_delivery_time: '4-6 hours',
    message: '',
    terms_and_conditions: '',
    valid_until: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().slice(0, 16) // 24 hours from now
  })

  if (!isOpen) return null

  const updateCustomPricing = (field: string, value: number) => {
    setOfferData(prev => ({
      ...prev,
      custom_pricing: { ...prev.custom_pricing, [field]: value }
    }))
  }

  const updateOfferData = (field: string, value: any) => {
    setOfferData(prev => ({ ...prev, [field]: value }))
  }

  const calculateTotal = () => {
    const { base_price, custom_pricing } = offerData
    return base_price + Object.values(custom_pricing).reduce((sum, fee) => sum + fee, 0)
  }

  const handleSubmit = async () => {
    setLoading(true)
    
    try {
      const customOffer = {
        ...offerData,
        total_price: calculateTotal(),
        offer_type: 'custom_offer',
        status: 'pending'
      }
      
      await onSubmit(customOffer)
      onClose()
    } catch (error) {
      console.error('Error submitting custom offer:', error)
    } finally {
      setLoading(false)
    }
  }

  const feeTypes = [
    {
      key: 'pickup_fee',
      name: 'Pickup Fee',
      description: 'Fee for picking up items',
      icon: Package,
      min: 0,
      max: 50,
      step: 5
    },
    {
      key: 'delivery_fee',
      name: 'Delivery Fee',
      description: 'Fee for delivering items',
      icon: Truck,
      min: 0,
      max: 50,
      step: 5
    },
    {
      key: 'handling_fee',
      name: 'Handling Fee',
      description: 'Special handling or care',
      icon: Package,
      min: 0,
      max: 25,
      step: 2.5
    },
    {
      key: 'rush_fee',
      name: 'Rush Fee',
      description: 'Expedited service',
      icon: Clock,
      min: 0,
      max: 30,
      step: 5
    },
    {
      key: 'distance_fee',
      name: 'Distance Fee',
      description: 'Long distance surcharge',
      icon: Truck,
      min: 0,
      max: 40,
      step: 5
    },
    {
      key: 'item_specific_fee',
      name: 'Item-Specific Fee',
      description: 'Special equipment or expertise',
      icon: Package,
      min: 0,
      max: 35,
      step: 5
    }
  ]

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-br from-slate-900/95 to-purple-900/95 backdrop-blur-xl border border-purple-500/30 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-6 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-white">Custom Offer</h3>
              <p className="text-white/80 text-sm">Create a personalized quote for {installer?.business_name}</p>
            </div>
          </div>
          
          <button onClick={onClose} className="text-white/70 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto max-h-[70vh]">
          {step === 1 && (
            <div className="space-y-6">
              <h4 className="text-xl font-bold text-white mb-4">Pricing Structure</h4>
              
              {/* Base Price */}
              <div className="bg-white/10 rounded-xl p-4">
                <label className="block text-white/80 text-sm font-medium mb-2">Base Service Price</label>
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => updateOfferData('base_price', Math.max(10, offerData.base_price - 5))}
                    className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center text-white hover:bg-white/30"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <div className="flex-1 text-center">
                    <span className="text-2xl font-bold text-white">${offerData.base_price}</span>
                  </div>
                  <button
                    onClick={() => updateOfferData('base_price', offerData.base_price + 5)}
                    className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center text-white hover:bg-white/30"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Custom Fees */}
              <div className="space-y-4">
                <h5 className="text-white font-semibold">Additional Fees</h5>
                {feeTypes.map((feeType) => {
                  const IconComponent = feeType.icon
                  const currentValue = offerData.custom_pricing[feeType.key]
                  
                  return (
                    <div key={feeType.key} className="bg-white/5 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <IconComponent className="w-4 h-4 text-purple-400" />
                          <span className="text-white font-medium">{feeType.name}</span>
                        </div>
                        <span className="text-white font-bold">${currentValue}</span>
                      </div>
                      <p className="text-white/60 text-xs mb-3">{feeType.description}</p>
                      
                      <div className="flex items-center space-x-3">
                        <button
                          onClick={() => updateCustomPricing(feeType.key, Math.max(feeType.min, currentValue - feeType.step))}
                          className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center text-white hover:bg-white/30"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <div className="flex-1">
                          <input
                            type="range"
                            min={feeType.min}
                            max={feeType.max}
                            step={feeType.step}
                            value={currentValue}
                            onChange={(e) => updateCustomPricing(feeType.key, parseFloat(e.target.value))}
                            className="w-full"
                          />
                        </div>
                        <button
                          onClick={() => updateCustomPricing(feeType.key, Math.min(feeType.max, currentValue + feeType.step))}
                          className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center text-white hover:bg-white/30"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>

              {/* Total Price Display */}
              <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-xl p-4">
                <div className="flex items-center justify-between">
                  <span className="text-green-300 font-semibold">Total Price</span>
                  <span className="text-3xl font-bold text-green-300">${calculateTotal()}</span>
                </div>
              </div>

              <button
                onClick={() => setStep(2)}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-600 text-white py-3 rounded-xl font-bold text-lg hover:scale-105 transition-transform"
              >
                Continue to Details
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <h4 className="text-xl font-bold text-white mb-4">Service Details</h4>
              
              {/* Timing */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Estimated Pickup Time</label>
                  <input
                    type="text"
                    value={offerData.estimated_pickup_time}
                    onChange={(e) => updateOfferData('estimated_pickup_time', e.target.value)}
                    placeholder="e.g., 2-3 hours"
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-white/50 text-sm focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Estimated Delivery Time</label>
                  <input
                    type="text"
                    value={offerData.estimated_delivery_time}
                    onChange={(e) => updateOfferData('estimated_delivery_time', e.target.value)}
                    placeholder="e.g., 4-6 hours"
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-white/50 text-sm focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              {/* Message */}
              <div>
                <label className="block text-white/80 text-sm font-medium mb-2">Message to Customer</label>
                <textarea
                  value={offerData.message}
                  onChange={(e) => updateOfferData('message', e.target.value)}
                  placeholder="Explain your service, experience, or any special considerations..."
                  className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-white/50 text-sm focus:outline-none focus:border-purple-500"
                  rows={4}
                />
              </div>

              {/* Terms and Conditions */}
              <div>
                <label className="block text-white/80 text-sm font-medium mb-2">Terms & Conditions (Optional)</label>
                <textarea
                  value={offerData.terms_and_conditions}
                  onChange={(e) => updateOfferData('terms_and_conditions', e.target.value)}
                  placeholder="Any specific terms, conditions, or requirements..."
                  className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-white/50 text-sm focus:outline-none focus:border-purple-500"
                  rows={3}
                />
              </div>

              {/* Valid Until */}
              <div>
                <label className="block text-white/80 text-sm font-medium mb-2">Offer Valid Until</label>
                <input
                  type="datetime-local"
                  value={offerData.valid_until}
                  onChange={(e) => updateOfferData('valid_until', e.target.value)}
                  className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              {/* Final Summary */}
              <div className="bg-white/10 rounded-xl p-4">
                <h5 className="text-white font-semibold mb-3">Offer Summary</h5>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white/70">Base Service</span>
                    <span className="text-white">${offerData.base_price}</span>
                  </div>
                  {Object.entries(offerData.custom_pricing).map(([key, value]) => {
                    if (value > 0) {
                      const feeType = feeTypes.find(f => f.key === key)
                      return (
                        <div key={key} className="flex justify-between">
                          <span className="text-white/70">{feeType?.name}</span>
                          <span className="text-white">${value}</span>
                        </div>
                      )
                    }
                    return null
                  })}
                  <div className="border-t border-white/20 pt-2 mt-2">
                    <div className="flex justify-between font-semibold">
                      <span className="text-white">Total</span>
                      <span className="text-green-400 text-lg">${calculateTotal()}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={() => setStep(1)}
                  className="flex-1 bg-white/20 text-white py-3 rounded-lg font-semibold"
                >
                  Back
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={loading}
                  className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white py-3 rounded-lg font-bold hover:scale-105 transition-transform disabled:opacity-50"
                >
                  {loading ? 'Submitting...' : `Submit Offer - $${calculateTotal()}`}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}