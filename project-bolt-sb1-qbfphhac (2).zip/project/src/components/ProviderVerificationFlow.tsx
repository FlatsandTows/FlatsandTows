import React, { useState, useRef } from 'react'
import { Camera, Upload, FileText, Shield, CheckCircle, AlertCircle, User, CreditCard, MapPin, Phone, Mail, Building, Hash, Calendar, Eye, X, Zap, Crown, Star } from 'lucide-react'
import { supabase } from '../lib/supabase'

interface ProviderVerificationFlowProps {
  isOpen: boolean
  onClose: () => void
  onComplete: (verificationData: any) => void
  installerId: string
}

interface TaxInfo {
  ssn: string
  ein: string
  businessType: 'individual' | 'business'
  legalName: string
  businessName: string
  address: string
  city: string
  state: string
  zipCode: string
  phoneNumber: string
  email: string
}

interface DriverLicense {
  licenseNumber: string
  state: string
  expirationDate: string
  frontImage: File | null
  backImage: File | null
}

interface VerificationStatus {
  taxForm: boolean
  driverLicense: boolean
  photo: boolean
  backgroundCheck: boolean
}

export const ProviderVerificationFlow: React.FC<ProviderVerificationFlowProps> = ({
  isOpen,
  onClose,
  onComplete,
  installerId
}) => {
  const [currentStep, setCurrentStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  
  // Form data states
  const [taxInfo, setTaxInfo] = useState<TaxInfo>({
    ssn: '',
    ein: '',
    businessType: 'individual',
    legalName: '',
    businessName: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    phoneNumber: '',
    email: ''
  })
  
  const [driverLicense, setDriverLicense] = useState<DriverLicense>({
    licenseNumber: '',
    state: '',
    expirationDate: '',
    frontImage: null,
    backImage: null
  })
  
  const [profilePhoto, setProfilePhoto] = useState<File | null>(null)
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus>({
    taxForm: false,
    driverLicense: false,
    photo: false,
    backgroundCheck: false
  })

  const frontLicenseRef = useRef<HTMLInputElement>(null)
  const backLicenseRef = useRef<HTMLInputElement>(null)
  const photoRef = useRef<HTMLInputElement>(null)

  if (!isOpen) return null

  const handleFileUpload = (file: File, type: 'front' | 'back' | 'photo') => {
    if (type === 'front') {
      setDriverLicense(prev => ({ ...prev, frontImage: file }))
    } else if (type === 'back') {
      setDriverLicense(prev => ({ ...prev, backImage: file }))
    } else if (type === 'photo') {
      setProfilePhoto(file)
    }
  }

  const uploadToSupabase = async (file: File, path: string): Promise<string> => {
    const fileExt = file.name.split('.').pop()
    const fileName = `${Date.now()}.${fileExt}`
    const filePath = `${path}/${fileName}`

    const { data, error } = await supabase.storage
      .from('verification-documents')
      .upload(filePath, file)

    if (error) throw error
    return filePath
  }

  const submitTaxInformation = async () => {
    setLoading(true)
    setError('')

    try {
      // Validate required fields
      if (!taxInfo.ssn && !taxInfo.ein) {
        throw new Error('Either SSN or EIN is required')
      }

      // Save tax information
      const { error } = await supabase
        .from('installer_tax_info')
        .insert({
          installer_id: installerId,
          ssn: taxInfo.ssn ? btoa(taxInfo.ssn) : null, // Base64 encode for basic security
          ein: taxInfo.ein || null,
          business_type: taxInfo.businessType,
          legal_name: taxInfo.legalName,
          business_name: taxInfo.businessName,
          address: taxInfo.address,
          city: taxInfo.city,
          state: taxInfo.state,
          zip_code: taxInfo.zipCode,
          phone_number: taxInfo.phoneNumber,
          email: taxInfo.email,
          status: 'pending_verification'
        })

      if (error) throw error

      setVerificationStatus(prev => ({ ...prev, taxForm: true }))
      setCurrentStep(2)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const submitDriverLicense = async () => {
    setLoading(true)
    setError('')

    try {
      if (!driverLicense.frontImage || !driverLicense.backImage) {
        throw new Error('Both front and back images of driver license are required')
      }

      // Upload images
      const frontImagePath = await uploadToSupabase(driverLicense.frontImage, 'driver-licenses/front')
      const backImagePath = await uploadToSupabase(driverLicense.backImage, 'driver-licenses/back')

      // Save driver license information
      const { error } = await supabase
        .from('installer_driver_licenses')
        .insert({
          installer_id: installerId,
          license_number: driverLicense.licenseNumber,
          state: driverLicense.state,
          expiration_date: driverLicense.expirationDate,
          front_image_url: frontImagePath,
          back_image_url: backImagePath,
          status: 'pending_verification'
        })

      if (error) throw error

      setVerificationStatus(prev => ({ ...prev, driverLicense: true }))
      setCurrentStep(3)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const submitProfilePhoto = async () => {
    setLoading(true)
    setError('')

    try {
      if (!profilePhoto) {
        throw new Error('Profile photo is required')
      }

      // Upload profile photo
      const photoPath = await uploadToSupabase(profilePhoto, 'profile-photos')

      // Save profile photo
      const { error } = await supabase
        .from('installer_profile_photos')
        .insert({
          installer_id: installerId,
          photo_url: photoPath,
          status: 'pending_verification'
        })

      if (error) throw error

      setVerificationStatus(prev => ({ ...prev, photo: true }))
      setCurrentStep(4)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const completeVerification = async () => {
    setLoading(true)

    try {
      // Update installer profile with verification status
      const { error } = await supabase
        .from('installer_profiles')
        .update({
          verification_status: 'pending_review',
          tax_info_submitted: true,
          license_verified: true,
          photo_verified: true,
          updated_at: new Date().toISOString()
        })
        .eq('id', installerId)

      if (error) throw error

      // Trigger background check process
      await supabase
        .from('background_checks')
        .insert({
          installer_id: installerId,
          status: 'initiated',
          check_type: 'comprehensive'
        })

      setVerificationStatus(prev => ({ ...prev, backgroundCheck: true }))
      
      onComplete({
        taxInfo: verificationStatus.taxForm,
        driverLicense: verificationStatus.driverLicense,
        photo: verificationStatus.photo,
        backgroundCheck: true
      })
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const updateTaxInfo = (field: keyof TaxInfo, value: string) => {
    setTaxInfo(prev => ({ ...prev, [field]: value }))
  }

  const updateDriverLicense = (field: keyof Omit<DriverLicense, 'frontImage' | 'backImage'>, value: string) => {
    setDriverLicense(prev => ({ ...prev, [field]: value }))
  }

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-br from-slate-900/95 to-green-900/95 backdrop-blur-xl border border-green-500/30 rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-green-600 to-emerald-600 p-6 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-white">Provider Verification</h3>
              <p className="text-white/80 text-sm">Fast-track your approval with instant verification</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-white text-sm">Step {currentStep} of 4</div>
            <button onClick={onClose} className="text-white/70 hover:text-white">
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="bg-green-900/50 p-2">
          <div className="w-full bg-green-900/30 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-green-500 to-emerald-500 h-3 rounded-full transition-all duration-500"
              style={{ width: `${(currentStep / 4) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Benefits Banner */}
        <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border-b border-yellow-500/30 p-4">
          <div className="flex items-center justify-center space-x-6 text-sm">
            <div className="flex items-center space-x-2">
              <Zap className="w-4 h-4 text-yellow-400" />
              <span className="text-yellow-300 font-semibold">Instant Approval</span>
            </div>
            <div className="flex items-center space-x-2">
              <Crown className="w-4 h-4 text-yellow-400" />
              <span className="text-yellow-300 font-semibold">Premium Status</span>
            </div>
            <div className="flex items-center space-x-2">
              <Star className="w-4 h-4 text-yellow-400" />
              <span className="text-yellow-300 font-semibold">Higher Job Priority</span>
            </div>
          </div>
        </div>

        <div className="p-8 overflow-y-auto max-h-[60vh]">
          {error && (
            <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3 mb-6">
              <div className="flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-red-400" />
                <p className="text-red-300 text-sm">{error}</p>
              </div>
            </div>
          )}

          {/* Step 1: Tax Information (1099) */}
          {currentStep === 1 && (
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <FileText className="w-8 h-8 text-green-400" />
                <div>
                  <h4 className="text-2xl font-bold text-white">Tax Information (1099)</h4>
                  <p className="text-white/70">Required for tax reporting and payments</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Business Type */}
                <div className="md:col-span-2">
                  <label className="block text-white/80 text-sm font-medium mb-2">Business Type</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => updateTaxInfo('businessType', 'individual')}
                      className={`p-3 rounded-lg border text-center transition-all ${
                        taxInfo.businessType === 'individual'
                          ? 'bg-green-500/20 border-green-500/50 text-green-300'
                          : 'bg-white/10 border-white/20 text-white/70'
                      }`}
                    >
                      <User className="w-5 h-5 mx-auto mb-1" />
                      <div className="text-sm font-semibold">Individual</div>
                      <div className="text-xs">Use SSN</div>
                    </button>
                    <button
                      onClick={() => updateTaxInfo('businessType', 'business')}
                      className={`p-3 rounded-lg border text-center transition-all ${
                        taxInfo.businessType === 'business'
                          ? 'bg-green-500/20 border-green-500/50 text-green-300'
                          : 'bg-white/10 border-white/20 text-white/70'
                      }`}
                    >
                      <Building className="w-5 h-5 mx-auto mb-1" />
                      <div className="text-sm font-semibold">Business</div>
                      <div className="text-xs">Use EIN</div>
                    </button>
                  </div>
                </div>

                {/* Tax ID */}
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">
                    {taxInfo.businessType === 'individual' ? 'Social Security Number' : 'Employer Identification Number'}
                  </label>
                  <div className="relative">
                    <Hash className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/50" />
                    <input
                      type="text"
                      required
                      value={taxInfo.businessType === 'individual' ? taxInfo.ssn : taxInfo.ein}
                      onChange={(e) => updateTaxInfo(taxInfo.businessType === 'individual' ? 'ssn' : 'ein', e.target.value)}
                      placeholder={taxInfo.businessType === 'individual' ? 'XXX-XX-XXXX' : 'XX-XXXXXXX'}
                      className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-green-500"
                    />
                  </div>
                </div>

                {/* Legal Name */}
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Legal Name</label>
                  <input
                    type="text"
                    required
                    value={taxInfo.legalName}
                    onChange={(e) => updateTaxInfo('legalName', e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-green-500"
                    placeholder="Full legal name"
                  />
                </div>

                {/* Business Name (if business) */}
                {taxInfo.businessType === 'business' && (
                  <div className="md:col-span-2">
                    <label className="block text-white/80 text-sm font-medium mb-2">Business Name</label>
                    <input
                      type="text"
                      required
                      value={taxInfo.businessName}
                      onChange={(e) => updateTaxInfo('businessName', e.target.value)}
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-green-500"
                      placeholder="Business name"
                    />
                  </div>
                )}

                {/* Address */}
                <div className="md:col-span-2">
                  <label className="block text-white/80 text-sm font-medium mb-2">Address</label>
                  <input
                    type="text"
                    required
                    value={taxInfo.address}
                    onChange={(e) => updateTaxInfo('address', e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-green-500"
                    placeholder="Street address"
                  />
                </div>

                {/* City, State, ZIP */}
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">City</label>
                  <input
                    type="text"
                    required
                    value={taxInfo.city}
                    onChange={(e) => updateTaxInfo('city', e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-green-500"
                    placeholder="City"
                  />
                </div>

                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">State</label>
                  <input
                    type="text"
                    required
                    value={taxInfo.state}
                    onChange={(e) => updateTaxInfo('state', e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-green-500"
                    placeholder="State"
                  />
                </div>

                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">ZIP Code</label>
                  <input
                    type="text"
                    required
                    value={taxInfo.zipCode}
                    onChange={(e) => updateTaxInfo('zipCode', e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-green-500"
                    placeholder="ZIP Code"
                  />
                </div>

                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Phone Number</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/50" />
                    <input
                      type="tel"
                      required
                      value={taxInfo.phoneNumber}
                      onChange={(e) => updateTaxInfo('phoneNumber', e.target.value)}
                      className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-green-500"
                      placeholder="(555) 123-4567"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/50" />
                    <input
                      type="email"
                      required
                      value={taxInfo.email}
                      onChange={(e) => updateTaxInfo('email', e.target.value)}
                      className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-green-500"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-4 mt-6">
                <div className="flex items-start space-x-3">
                  <Shield className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-blue-300 font-semibold mb-1">Secure & Encrypted</h5>
                    <p className="text-blue-200 text-sm">
                      All tax information is encrypted and stored securely. We use this information solely for 
                      1099 tax reporting and payment processing as required by law.
                    </p>
                  </div>
                </div>
              </div>

              <button
                onClick={submitTaxInformation}
                disabled={loading}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-4 rounded-xl font-bold text-lg hover:scale-105 transition-transform mt-6 flex items-center justify-center"
              >
                {loading ? (
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    <FileText className="w-5 h-5 mr-2" />
                    Submit Tax Information
                  </>
                )}
              </button>
            </div>
          )}

          {/* Step 2: Driver's License */}
          {currentStep === 2 && (
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <CreditCard className="w-8 h-8 text-green-400" />
                <div>
                  <h4 className="text-2xl font-bold text-white">Driver's License Verification</h4>
                  <p className="text-white/70">Upload clear photos of your driver's license</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">License Number</label>
                  <input
                    type="text"
                    required
                    value={driverLicense.licenseNumber}
                    onChange={(e) => updateDriverLicense('licenseNumber', e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-green-500"
                    placeholder="License number"
                  />
                </div>

                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">State</label>
                  <input
                    type="text"
                    required
                    value={driverLicense.state}
                    onChange={(e) => updateDriverLicense('state', e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:border-green-500"
                    placeholder="State"
                  />
                </div>

                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Expiration Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/50" />
                    <input
                      type="date"
                      required
                      value={driverLicense.expirationDate}
                      onChange={(e) => updateDriverLicense('expirationDate', e.target.value)}
                      className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-3 text-white focus:outline-none focus:border-green-500"
                    />
                  </div>
                </div>
              </div>

              {/* Photo Upload */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Front of License */}
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Front of License</label>
                  <div 
                    onClick={() => frontLicenseRef.current?.click()}
                    className="border-2 border-dashed border-white/30 rounded-lg p-8 text-center cursor-pointer hover:border-green-500/50 transition-colors"
                  >
                    {driverLicense.frontImage ? (
                      <div className="flex items-center justify-center space-x-2">
                        <CheckCircle className="w-6 h-6 text-green-400" />
                        <span className="text-green-300">Front image uploaded</span>
                      </div>
                    ) : (
                      <div>
                        <Camera className="w-8 h-8 text-white/50 mx-auto mb-2" />
                        <p className="text-white/70 text-sm">Click to upload front</p>
                      </div>
                    )}
                  </div>
                  <input
                    ref={frontLicenseRef}
                    type="file"
                    accept="image/*"
                    onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'front')}
                    className="hidden"
                  />
                </div>

                {/* Back of License */}
                <div>
                  <label className="block text-white/80 text-sm font-medium mb-2">Back of License</label>
                  <div 
                    onClick={() => backLicenseRef.current?.click()}
                    className="border-2 border-dashed border-white/30 rounded-lg p-8 text-center cursor-pointer hover:border-green-500/50 transition-colors"
                  >
                    {driverLicense.backImage ? (
                      <div className="flex items-center justify-center space-x-2">
                        <CheckCircle className="w-6 h-6 text-green-400" />
                        <span className="text-green-300">Back image uploaded</span>
                      </div>
                    ) : (
                      <div>
                        <Camera className="w-8 h-8 text-white/50 mx-auto mb-2" />
                        <p className="text-white/70 text-sm">Click to upload back</p>
                      </div>
                    )}
                  </div>
                  <input
                    ref={backLicenseRef}
                    type="file"
                    accept="image/*"
                    onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'back')}
                    className="hidden"
                  />
                </div>
              </div>

              <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-lg p-4 mt-6">
                <div className="flex items-start space-x-3">
                  <Eye className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-yellow-300 font-semibold mb-1">Photo Guidelines</h5>
                    <ul className="text-yellow-200 text-sm space-y-1">
                      <li>• Ensure all text is clearly readable</li>
                      <li>• Take photos in good lighting</li>
                      <li>• Avoid glare and shadows</li>
                      <li>• Include all four corners of the license</li>
                    </ul>
                  </div>
                </div>
              </div>

              <button
                onClick={submitDriverLicense}
                disabled={loading || !driverLicense.frontImage || !driverLicense.backImage}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-4 rounded-xl font-bold text-lg hover:scale-105 transition-transform mt-6 flex items-center justify-center disabled:opacity-50"
              >
                {loading ? (
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    <CreditCard className="w-5 h-5 mr-2" />
                    Submit Driver's License
                  </>
                )}
              </button>
            </div>
          )}

          {/* Step 3: Profile Photo */}
          {currentStep === 3 && (
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <User className="w-8 h-8 text-green-400" />
                <div>
                  <h4 className="text-2xl font-bold text-white">Profile Photo</h4>
                  <p className="text-white/70">Upload a clear photo of yourself for customer trust</p>
                </div>
              </div>

              <div className="max-w-md mx-auto">
                <div 
                  onClick={() => photoRef.current?.click()}
                  className="border-2 border-dashed border-white/30 rounded-lg p-12 text-center cursor-pointer hover:border-green-500/50 transition-colors"
                >
                  {profilePhoto ? (
                    <div className="flex flex-col items-center space-y-3">
                      <CheckCircle className="w-12 h-12 text-green-400" />
                      <span className="text-green-300 font-semibold">Profile photo uploaded</span>
                      <span className="text-white/60 text-sm">{profilePhoto.name}</span>
                    </div>
                  ) : (
                    <div>
                      <Camera className="w-16 h-16 text-white/50 mx-auto mb-4" />
                      <p className="text-white/70 text-lg font-semibold mb-2">Upload Profile Photo</p>
                      <p className="text-white/50 text-sm">Click to select or take a photo</p>
                    </div>
                  )}
                </div>
                <input
                  ref={photoRef}
                  type="file"
                  accept="image/*"
                  onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'photo')}
                  className="hidden"
                />
              </div>

              <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-4 mt-6">
                <div className="flex items-start space-x-3">
                  <Shield className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-blue-300 font-semibold mb-1">Why We Need This</h5>
                    <ul className="text-blue-200 text-sm space-y-1">
                      <li>• Builds customer trust and confidence</li>
                      <li>• Helps customers identify you on arrival</li>
                      <li>• Required for premium installer status</li>
                      <li>• Increases job acceptance rates by 40%</li>
                    </ul>
                  </div>
                </div>
              </div>

              <button
                onClick={submitProfilePhoto}
                disabled={loading || !profilePhoto}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-4 rounded-xl font-bold text-lg hover:scale-105 transition-transform mt-6 flex items-center justify-center disabled:opacity-50"
              >
                {loading ? (
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    <User className="w-5 h-5 mr-2" />
                    Submit Profile Photo
                  </>
                )}
              </button>
            </div>
          )}

          {/* Step 4: Completion */}
          {currentStep === 4 && (
            <div className="text-center">
              <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-12 h-12 text-white" />
              </div>
              
              <h4 className="text-3xl font-bold text-white mb-4">Verification Complete!</h4>
              <p className="text-white/80 text-lg mb-6">
                Your documents have been submitted for review. You'll be approved within 24 hours.
              </p>

              {/* Verification Status */}
              <div className="bg-white/10 rounded-xl p-6 mb-6">
                <h5 className="text-white font-semibold mb-4">Verification Status</h5>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-white/70">Tax Information (1099)</span>
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/70">Driver's License</span>
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/70">Profile Photo</span>
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/70">Background Check</span>
                    <div className="w-4 h-4 border-2 border-yellow-400/30 border-t-yellow-400 rounded-full animate-spin"></div>
                  </div>
                </div>
              </div>

              {/* Benefits */}
              <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 rounded-xl p-6 mb-6">
                <h5 className="text-yellow-300 font-semibold mb-3">🎉 Verification Benefits Unlocked</h5>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center space-x-2">
                    <Crown className="w-4 h-4 text-yellow-400" />
                    <span className="text-yellow-200">Premium installer badge</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-blue-400" />
                    <span className="text-yellow-200">Priority job matching</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Star className="w-4 h-4 text-purple-400" />
                    <span className="text-yellow-200">Higher customer trust</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Shield className="w-4 h-4 text-green-400" />
                    <span className="text-yellow-200">Instant payouts enabled</span>
                  </div>
                </div>
              </div>

              <button
                onClick={completeVerification}
                disabled={loading}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-4 rounded-xl font-bold text-lg hover:scale-105 transition-transform flex items-center justify-center"
              >
                {loading ? (
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    <Shield className="w-5 h-5 mr-2" />
                    Complete Verification Process
                  </>
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}