import React, { useState } from 'react'
import { X, CreditCard, Lock, AlertCircle, CheckCircle, Shield } from 'lucide-react'
import { LegalDisclaimers } from './LegalDisclaimers'

interface PaymentModalProps {
  isOpen: boolean
  onClose: () => void
  job: any
  onPaymentSuccess: () => void
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  job,
  onPaymentSuccess
}) => {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [paymentStep, setPaymentStep] = useState<'legal' | 'details' | 'processing' | 'success'>('legal')
  const [legalAccepted, setLegalAccepted] = useState(false)

  if (!isOpen) return null

  const handleLegalAcceptance = (accepted: boolean) => {
    setLegalAccepted(accepted)
    if (accepted) {
      setPaymentStep('details')
    } else {
      onClose()
    }
  }

  const handlePayment = async () => {
    setLoading(true)
    setError('')
    setPaymentStep('processing')

    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 3000))
      
      setPaymentStep('success')
      setTimeout(() => {
        onPaymentSuccess()
        onClose()
      }, 3000)

    } catch (err: any) {
      setError(err.message || 'Payment failed. Please try again.')
      setPaymentStep('details')
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      {paymentStep === 'legal' && (
        <LegalDisclaimers
          userType="customer"
          onAccept={handleLegalAcceptance}
          isOpen={true}
          onClose={() => onClose()}
          context="checkout"
        />
      )}

      {paymentStep !== 'legal' && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gradient-to-br from-slate-900/95 to-purple-900/95 backdrop-blur-xl border border-purple-500/30 rounded-3xl max-w-md w-full">
            
            {paymentStep === 'details' && (
              <>
                <div className="p-6 border-b border-purple-500/20">
                  <div className="flex items-center justify-between">
                    <h3 className="text-2xl font-bold text-white">Secure Payment</h3>
                    <button onClick={onClose} className="text-white/70 hover:text-white">
                      <X className="w-6 h-6" />
                    </button>
                  </div>
                  <div className="flex items-center space-x-2 mt-2">
                    <Lock className="w-4 h-4 text-green-400" />
                    <span className="text-green-400 text-sm">256-bit SSL encryption</span>
                  </div>
                </div>

                <div className="p-6">
                  {/* Legal Confirmation */}
                  <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-3 mb-4">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-400" />
                      <span className="text-green-300 text-sm font-semibold">Legal disclaimers accepted</span>
                    </div>
                  </div>

                  {/* Job Summary */}
                  <div className="bg-white/10 rounded-xl p-4 mb-6">
                    <h4 className="text-white font-semibold mb-3">Service Summary</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-white/70">Service</span>
                        <span className="text-white">{job.service_type}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70">Installer</span>
                        <span className="text-white">{job.installer?.business_name || 'Professional Installer'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70">Service Fee</span>
                        <span className="text-white">${(job.agreed_price - job.platform_fee - job.processing_fee).toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70">Platform Fee</span>
                        <span className="text-white">${job.platform_fee.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70">Processing Fee</span>
                        <span className="text-white">${job.processing_fee.toFixed(2)}</span>
                      </div>
                      <div className="border-t border-white/20 pt-2 mt-2">
                        <div className="flex justify-between font-semibold">
                          <span className="text-white">Total</span>
                          <span className="text-white">${job.agreed_price.toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {error && (
                    <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3 mb-4">
                      <div className="flex items-center space-x-2">
                        <AlertCircle className="w-4 h-4 text-red-400" />
                        <p className="text-red-300 text-sm">{error}</p>
                      </div>
                    </div>
                  )}

                  {/* Demo Payment Notice */}
                  <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-4 mb-6">
                    <div className="flex items-start space-x-2">
                      <Shield className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-blue-300 text-xs font-semibold mb-1">DEMO MODE</p>
                        <p className="text-blue-200 text-xs">
                          This is a demonstration. No actual payment will be processed. 
                          In production, this would integrate with Stripe for secure payments.
                        </p>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={handlePayment}
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-400 hover:to-emerald-500 text-white py-3 rounded-lg font-semibold transition-all duration-300 disabled:opacity-50 flex items-center justify-center"
                  >
                    {loading ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : (
                      <>
                        <CreditCard className="w-5 h-5 mr-2" />
                        Process Demo Payment ${job.agreed_price.toFixed(2)}
                      </>
                    )}
                  </button>

                  <p className="text-white/60 text-xs text-center mt-3">
                    Demo mode - No actual payment will be processed
                  </p>
                </div>
              </>
            )}

            {paymentStep === 'processing' && (
              <div className="p-8 text-center">
                <div className="w-16 h-16 border-4 border-blue-500/30 border-t-blue-500 rounded-full animate-spin mx-auto mb-4"></div>
                <h3 className="text-xl font-bold text-white mb-2">Processing Payment</h3>
                <p className="text-white/70">Please wait while we process your payment...</p>
              </div>
            )}

            {paymentStep === 'success' && (
              <div className="p-8 text-center">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Payment Successful!</h3>
                <p className="text-white/70 mb-4">Your installer has been notified and is on the way.</p>
                <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-3">
                  <p className="text-green-300 text-sm">
                    Installer will be paid automatically within 60 seconds of job completion.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  )
}