import React, { useState, useEffect } from 'react'
import { Clock, Star, Crown, DollarSign, Zap, CreditCard } from 'lucide-react'
import { createServiceRequestWithMatching, subscribeToBids, acceptBidAndCreateJob } from '../lib/database'
import { useAuth } from '../hooks/useAuth'
import { PaymentModal } from './PaymentModal'

interface LiveBiddingProps {
  serviceType: string
  location: { lat: number; lng: number }
  address: string
  description?: string
  onJobCreated: (job: any) => void
}

export const LiveBidding: React.FC<LiveBiddingProps> = ({
  serviceType,
  location,
  address,
  description,
  onJobCreated
}) => {
  const { user } = useAuth()
  const [requestId, setRequestId] = useState<string | null>(null)
  const [bids, setBids] = useState([])
  const [countdown, setCountdown] = useState(600) // 10 minutes
  const [isLoading, setIsLoading] = useState(true)
  const [selectedBid, setSelectedBid] = useState(null)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [createdJob, setCreatedJob] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    createRequest()
  }, [])

  useEffect(() => {
    if (!requestId) return

    // Subscribe to new bids
    const channel = subscribeToBids(requestId, (payload) => {
      if (payload.eventType === 'INSERT') {
        setBids(prev => [...prev, payload.new])
      }
    })

    // Countdown timer
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => {
      if (channel && typeof channel.unsubscribe === 'function') {
        channel.unsubscribe()
      }
      clearInterval(timer)
    }
  }, [requestId])

  const createRequest = async () => {
    try {
      setError('')
      const request = await createServiceRequestWithMatching({
        service_type: serviceType,
        location,
        address,
        description,
        urgency_level: 3
      })
      
      setRequestId(request.id)
      setIsLoading(false)
    } catch (error) {
      console.error('Error creating request:', error)
      setError('Failed to create service request. Please try again.')
      setIsLoading(false)
    }
  }

  const acceptBid = async (bid: any) => {
    try {
      setError('')
      const { job } = await acceptBidAndCreateJob(bid.id)
      setSelectedBid(bid)
      setCreatedJob(job)
      setShowPaymentModal(true)
    } catch (error) {
      console.error('Error accepting bid:', error)
      setError('Failed to accept bid. Please try again.')
    }
  }

  const handlePaymentSuccess = () => {
    setShowPaymentModal(false)
    onJobCreated(createdJob)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-800 to-blue-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-white text-lg">Finding nearby installers...</p>
          <p className="text-white/60 text-sm">Sending alerts to qualified providers</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-900 via-red-800 to-orange-900 flex items-center justify-center p-4">
        <div className="max-w-md mx-auto text-center">
          <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Zap className="w-8 h-8 text-red-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">Service Unavailable</h2>
          <p className="text-white/80 mb-6">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    )
  }

  const sortedBids = bids.sort((a, b) => a.price - b.price)
  const minutes = Math.floor(countdown / 60)
  const seconds = countdown % 60

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-800 to-blue-900 p-4">
      <div className="max-w-md mx-auto">
        <div className="text-center mb-6 mt-8">
          <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
            <DollarSign className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Live Bidding Active</h2>
          <p className="text-white/80">Installers are competing for your job</p>
          
          <div className="bg-white/10 rounded-lg p-3 mt-4 backdrop-blur-sm">
            <div className="flex items-center justify-center space-x-4">
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-orange-400 animate-pulse" />
                <span className="text-white font-mono text-lg">
                  {minutes}:{seconds.toString().padStart(2, '0')}
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <Zap className="w-4 h-4 text-green-400 animate-bounce" />
                <span className="text-green-400 font-semibold">{bids.length} bids</span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-3 mb-6">
          {sortedBids.map((bid, index) => (
            <div 
              key={bid.id}
              className={`border rounded-xl p-4 transition-all duration-300 ${
                index === 0 
                  ? 'bg-green-500/20 border-green-500/50 animate-pulse' 
                  : 'bg-white/10 border-white/20'
              } backdrop-blur-sm relative`}
            >
              {bid.installer?.is_premium && (
                <div className="absolute top-2 right-2 bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                  <Crown className="w-3 h-3 inline mr-1" />
                  PREMIUM
                </div>
              )}

              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    bid.installer?.is_premium 
                      ? 'bg-gradient-to-r from-yellow-500 to-orange-500' 
                      : 'bg-gradient-to-r from-blue-500 to-purple-500'
                  }`}>
                    <span className="text-white font-bold text-sm">
                      {bid.installer?.business_name?.charAt(0) || 'I'}
                    </span>
                  </div>
                  <div>
                    <div className="text-white font-semibold text-sm">
                      {bid.installer?.business_name || 'Professional Installer'}
                    </div>
                    <div className="flex items-center space-x-2 text-xs">
                      <Star className="w-3 h-3 text-yellow-400 fill-current" />
                      <span className="text-white/70">4.9</span>
                      <span className="text-white/50">• {bid.installer?.total_jobs || 0} jobs</span>
                      <span className="text-blue-400">• {bid.match_score || 95}% match</span>
                    </div>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className={`text-xl font-bold ${index === 0 ? 'text-green-400' : 'text-white'}`}>
                    ${bid.price}
                    {index === 0 && <span className="text-green-400 text-sm ml-1">BEST</span>}
                  </div>
                  <div className="text-white/60 text-xs">{bid.estimated_arrival} min ETA</div>
                </div>
              </div>
              
              {bid.message && (
                <p className="text-white/80 text-xs italic mb-3">"{bid.message}"</p>
              )}
              
              <button
                onClick={() => acceptBid(bid)}
                className={`w-full py-2 rounded-lg font-semibold text-sm transition-all flex items-center justify-center ${
                  index === 0
                    ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:scale-105'
                    : 'bg-white/20 text-white hover:bg-white/30'
                }`}
              >
                <CreditCard className="w-4 h-4 mr-2" />
                Pay ${bid.price} - {bid.estimated_arrival} min ETA
              </button>
            </div>
          ))}
        </div>

        {bids.length === 0 && (
          <div className="text-center text-white/60 py-8">
            <div className="animate-spin w-8 h-8 border-2 border-white/20 border-t-white rounded-full mx-auto mb-4"></div>
            <p>Waiting for installers to bid...</p>
            <p className="text-sm mt-2">We've notified nearby professionals</p>
          </div>
        )}
      </div>

      {showPaymentModal && selectedBid && createdJob && (
        <PaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          job={createdJob}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  )
}