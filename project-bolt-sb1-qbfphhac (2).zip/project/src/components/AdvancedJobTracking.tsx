import React, { useState, useEffect } from 'react'
import { MapPin, Phone, MessageCircle, Clock, CheckCircle, Star, Navigation, Car, Camera, AlertTriangle, Shield, Zap, Eye, Timer, Route, Battery, Signal } from 'lucide-react'
import { useJobUpdates, useInstallerLocation } from '../hooks/useRealtime'
import { supabase } from '../lib/supabase'
import { startLocationSharing, calculateETA, reverseGeocode, createGeofence } from '../lib/maps'
import { sendJobNotifications } from '../lib/notifications'

interface AdvancedJobTrackingProps {
  jobId: string
  onComplete: () => void
}

export const AdvancedJobTracking: React.FC<AdvancedJobTrackingProps> = ({ jobId, onComplete }) => {
  const job = useJobUpdates(jobId)
  const installerLocation = useInstallerLocation(job?.installer_id)
  const [rating, setRating] = useState(5)
  const [review, setReview] = useState('')
  const [eta, setEta] = useState<number | null>(null)
  const [installerAddress, setInstallerAddress] = useState('')
  const [showLiveMap, setShowLiveMap] = useState(false)
  const [jobPhotos, setJobPhotos] = useState<string[]>([])
  const [isInstallerNearby, setIsInstallerNearby] = useState(false)
  const [serviceProgress, setServiceProgress] = useState(0)
  const [liveUpdates, setLiveUpdates] = useState<any[]>([])
  const [showSafetyFeatures, setShowSafetyFeatures] = useState(false)

  useEffect(() => {
    if (job && installerLocation) {
      updateETA()
      updateInstallerAddress()
      checkProximity()
    }
  }, [job, installerLocation])

  useEffect(() => {
    // Set up geofencing
    if (job && installerLocation) {
      const cleanup = createGeofence(
        { lat: job.location.coordinates[1], lng: job.location.coordinates[0] },
        100, // 100 meters
        () => {
          setIsInstallerNearby(true)
          addLiveUpdate('🎯 Installer has arrived at your location')
        },
        () => {
          setIsInstallerNearby(false)
          addLiveUpdate('🚗 Installer has left the area')
        }
      )

      return cleanup
    }
  }, [job, installerLocation])

  const updateETA = async () => {
    if (!job || !installerLocation) return
    
    try {
      const jobLocation = {
        lat: job.location.coordinates[1],
        lng: job.location.coordinates[0]
      }
      
      const currentLocation = {
        lat: installerLocation.coordinates[1],
        lng: installerLocation.coordinates[0]
      }
      
      const estimatedTime = await calculateETA(currentLocation, jobLocation)
      setEta(estimatedTime)
    } catch (error) {
      console.error('ETA calculation error:', error)
    }
  }

  const updateInstallerAddress = async () => {
    if (!installerLocation) return
    
    try {
      const location = {
        lat: installerLocation.coordinates[1],
        lng: installerLocation.coordinates[0]
      }
      
      const address = await reverseGeocode(location)
      setInstallerAddress(address)
    } catch (error) {
      console.error('Address lookup error:', error)
    }
  }

  const checkProximity = () => {
    if (!job || !installerLocation) return
    
    const distance = calculateDistance(
      job.location.coordinates[1],
      job.location.coordinates[0],
      installerLocation.coordinates[1],
      installerLocation.coordinates[0]
    )
    
    setIsInstallerNearby(distance <= 0.1) // Within 100 meters
  }

  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number) => {
    const R = 6371 // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180
    const dLng = (lng2 - lng1) * Math.PI / 180
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLng/2) * Math.sin(dLng/2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
    return R * c
  }

  const addLiveUpdate = (message: string) => {
    setLiveUpdates(prev => [{
      id: Date.now(),
      message,
      timestamp: new Date(),
      type: 'info'
    }, ...prev.slice(0, 9)]) // Keep last 10 updates
  }

  const completeJob = async () => {
    try {
      await supabase
        .from('jobs')
        .update({ 
          status: 'completed',
          completed_at: new Date().toISOString(),
          customer_rating: rating,
          customer_review: review,
          photos_after: jobPhotos
        })
        .eq('id', jobId)

      await supabase
        .from('payments')
        .update({
          status: 'completed',
          paid_at: new Date().toISOString(),
          payout_at: new Date().toISOString()
        })
        .eq('job_id', jobId)

      await sendJobNotifications(jobId, 'completed')
      onComplete()
    } catch (error) {
      console.error('Error completing job:', error)
    }
  }

  const callInstaller = () => {
    if (job?.installer?.phone) {
      window.location.href = `tel:${job.installer.phone}`
    }
  }

  const openMaps = () => {
    if (installerLocation) {
      const lat = installerLocation.coordinates[1]
      const lng = installerLocation.coordinates[0]
      const url = `https://www.google.com/maps?q=${lat},${lng}`
      window.open(url, '_blank')
    }
  }

  const shareLocation = async () => {
    if (navigator.share && job) {
      try {
        await navigator.share({
          title: 'My Service Location',
          text: `I'm getting roadside assistance at this location`,
          url: `https://maps.google.com/?q=${job.location.coordinates[1]},${job.location.coordinates[0]}`
        })
      } catch (error) {
        console.log('Share failed:', error)
      }
    }
  }

  if (!job) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-900 via-emerald-800 to-green-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-green-500/30 border-t-green-500 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-white">Loading job details...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-emerald-800 to-green-900 p-4">
      <div className="max-w-md mx-auto">
        {/* Enhanced Header */}
        <div className="text-center mb-6 mt-8">
          <div className="relative w-24 h-24 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4">
            {job.status === 'completed' ? (
              <CheckCircle className="w-12 h-12 text-white" />
            ) : (
              <Car className="w-12 h-12 text-white animate-pulse" />
            )}
            {isInstallerNearby && (
              <div className="absolute -top-2 -right-2 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center animate-bounce">
                <MapPin className="w-4 h-4 text-white" />
              </div>
            )}
          </div>
          
          <h2 className="text-2xl font-bold text-white mb-2">
            {job.status === 'completed' ? 'Service Complete!' : 
             isInstallerNearby ? 'Installer On-Site' : 'Installer En Route'}
          </h2>
          
          <p className="text-white/80">
            {job.status === 'completed' ? 'Thank you for using our service' : 
             isInstallerNearby ? 'Your installer has arrived' : 'Real-time tracking active'}
          </p>
          
          {eta && job.status !== 'completed' && !isInstallerNearby && (
            <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-3 mt-4">
              <div className="flex items-center justify-center space-x-2">
                <Timer className="w-4 h-4 text-green-400 animate-pulse" />
                <span className="text-green-300 font-semibold">ETA: {eta} minutes</span>
              </div>
            </div>
          )}
        </div>

        {/* Live Updates Feed */}
        {liveUpdates.length > 0 && (
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 mb-6">
            <h4 className="text-white font-semibold mb-3 flex items-center">
              <Signal className="w-4 h-4 mr-2 text-green-400" />
              Live Updates
            </h4>
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {liveUpdates.slice(0, 3).map((update) => (
                <div key={update.id} className="text-sm">
                  <div className="text-white/90">{update.message}</div>
                  <div className="text-white/50 text-xs">
                    {update.timestamp.toLocaleTimeString()}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Enhanced Installer Info */}
        <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 mb-6">
          <div className="flex items-center space-x-4 mb-4">
            <div className="relative">
              <div className="w-14 h-14 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">
                  {job.installer?.business_name?.charAt(0) || 'I'}
                </span>
              </div>
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-400 rounded-full flex items-center justify-center">
                <Shield className="w-3 h-3 text-white" />
              </div>
            </div>
            
            <div className="flex-1">
              <h3 className="text-white font-semibold flex items-center">
                {job.installer?.business_name || 'Professional Installer'}
                {job.installer?.is_premium && (
                  <span className="ml-2 bg-yellow-500 text-black text-xs px-2 py-1 rounded-full font-bold">
                    PREMIUM
                  </span>
                )}
              </h3>
              <div className="flex items-center space-x-2 text-sm">
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <span className="text-white/70">4.9 • 247 jobs • Verified</span>
              </div>
              {installerAddress && (
                <div className="flex items-center space-x-1 text-xs text-white/60 mt-1">
                  <MapPin className="w-3 h-3" />
                  <span className="truncate">{installerAddress}</span>
                </div>
              )}
            </div>
            
            <div className="text-right">
              <div className="text-white font-bold text-xl">${job.agreed_price}</div>
              <div className="text-white/60 text-sm">Total</div>
              {isInstallerNearby && (
                <div className="text-green-400 text-xs font-semibold animate-pulse">
                  ON-SITE
                </div>
              )}
            </div>
          </div>

          {/* Enhanced Action Buttons */}
          <div className="grid grid-cols-4 gap-2">
            <button 
              onClick={callInstaller}
              className="bg-green-600 hover:bg-green-500 text-white py-2 rounded-lg font-semibold flex flex-col items-center justify-center transition-colors"
            >
              <Phone className="w-4 h-4 mb-1" />
              <span className="text-xs">Call</span>
            </button>
            <button 
              onClick={openMaps}
              className="bg-blue-600 hover:bg-blue-500 text-white py-2 rounded-lg font-semibold flex flex-col items-center justify-center transition-colors"
            >
              <Navigation className="w-4 h-4 mb-1" />
              <span className="text-xs">Track</span>
            </button>
            <button 
              onClick={() => setShowLiveMap(!showLiveMap)}
              className="bg-purple-600 hover:bg-purple-500 text-white py-2 rounded-lg font-semibold flex flex-col items-center justify-center transition-colors"
            >
              <Eye className="w-4 h-4 mb-1" />
              <span className="text-xs">Live</span>
            </button>
            <button 
              onClick={shareLocation}
              className="bg-orange-600 hover:bg-orange-500 text-white py-2 rounded-lg font-semibold flex flex-col items-center justify-center transition-colors"
            >
              <MessageCircle className="w-4 h-4 mb-1" />
              <span className="text-xs">Share</span>
            </button>
          </div>
        </div>

        {/* Live Map View */}
        {showLiveMap && (
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 mb-6">
            <div className="h-48 bg-gray-800 rounded-lg flex items-center justify-center">
              <div className="text-center text-white/70">
                <MapPin className="w-8 h-8 mx-auto mb-2" />
                <p className="text-sm">Live Map Integration</p>
                <p className="text-xs">Real-time installer tracking</p>
              </div>
            </div>
          </div>
        )}

        {/* Enhanced Service Progress */}
        <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 mb-6">
          <h4 className="text-white font-semibold mb-3 flex items-center justify-between">
            <span>Service Progress</span>
            <span className="text-green-400 text-sm">{serviceProgress}% Complete</span>
          </h4>
          
          {/* Progress Bar */}
          <div className="w-full bg-white/20 rounded-full h-2 mb-4">
            <div 
              className="bg-gradient-to-r from-green-500 to-emerald-500 h-2 rounded-full transition-all duration-500"
              style={{ width: `${serviceProgress}%` }}
            ></div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1">
                <span className="text-white">Payment processed</span>
                <div className="text-white/60 text-xs">Installer dispatched • Verified</div>
              </div>
              <span className="text-green-400 text-xs">✓</span>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                job.status === 'in_progress' || job.status === 'completed' 
                  ? 'bg-green-500' 
                  : isInstallerNearby ? 'bg-blue-500' : 'bg-blue-500 animate-pulse'
              }`}>
                <Car className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1">
                <span className="text-white">
                  {isInstallerNearby ? 'Installer arrived' : 'En route to location'}
                </span>
                <div className="text-white/60 text-xs">
                  {isInstallerNearby ? 'On-site and ready' : eta ? `${eta} minutes away` : 'Calculating ETA...'}
                </div>
              </div>
              {isInstallerNearby ? (
                <span className="text-green-400 text-xs">✓</span>
              ) : (
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
              )}
            </div>
            
            <div className="flex items-center space-x-3">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                job.status === 'in_progress' || job.status === 'completed' 
                  ? 'bg-green-500' 
                  : 'bg-white/20'
              }`}>
                <Zap className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1">
                <span className={job.status === 'in_progress' || job.status === 'completed' ? 'text-white' : 'text-white/50'}>
                  Service in progress
                </span>
                <div className="text-white/60 text-xs">
                  {job.status === 'in_progress' ? 'Work in progress' : 'Waiting for start'}
                </div>
              </div>
              {job.status === 'in_progress' || job.status === 'completed' ? (
                <span className="text-green-400 text-xs">✓</span>
              ) : null}
            </div>
            
            <div className="flex items-center space-x-3">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                job.status === 'completed' ? 'bg-green-500' : 'bg-white/20'
              }`}>
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1">
                <span className={job.status === 'completed' ? 'text-white' : 'text-white/50'}>
                  Service completed
                </span>
                <div className="text-white/60 text-xs">
                  {job.status === 'completed' ? 'Ready for review' : 'Pending completion'}
                </div>
              </div>
              {job.status === 'completed' && (
                <span className="text-green-400 text-xs">✓</span>
              )}
            </div>
          </div>
        </div>

        {/* Safety Features */}
        <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 mb-6">
          <button
            onClick={() => setShowSafetyFeatures(!showSafetyFeatures)}
            className="w-full flex items-center justify-between text-white font-semibold"
          >
            <div className="flex items-center">
              <Shield className="w-4 h-4 mr-2 text-green-400" />
              Safety & Security
            </div>
            <div className="text-green-400">
              {showSafetyFeatures ? '−' : '+'}
            </div>
          </button>
          
          {showSafetyFeatures && (
            <div className="mt-4 space-y-3">
              <div className="flex items-center space-x-3 text-sm">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span className="text-white/80">Background verified installer</span>
              </div>
              <div className="flex items-center space-x-3 text-sm">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span className="text-white/80">Real-time GPS tracking</span>
              </div>
              <div className="flex items-center space-x-3 text-sm">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span className="text-white/80">Secure payment processing</span>
              </div>
              <div className="flex items-center space-x-3 text-sm">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span className="text-white/80">24/7 support available</span>
              </div>
              <button className="w-full bg-red-600 hover:bg-red-500 text-white py-2 rounded-lg text-sm font-semibold transition-colors">
                🚨 Emergency Contact
              </button>
            </div>
          )}
        </div>

        {/* Rating & Review (Enhanced) */}
        {job.status === 'completed' && !job.customer_rating && (
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 mb-6">
            <h4 className="text-white font-semibold mb-3">Rate Your Experience</h4>
            
            <div className="flex justify-center space-x-2 mb-4">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  className={`w-10 h-10 transition-all duration-200 ${
                    star <= rating ? 'text-yellow-400 scale-110' : 'text-white/30'
                  }`}
                >
                  <Star className="w-full h-full fill-current" />
                </button>
              ))}
            </div>

            <textarea
              value={review}
              onChange={(e) => setReview(e.target.value)}
              placeholder="Share your experience (optional)"
              className="w-full bg-white/10 border border-white/20 rounded-lg p-3 text-white placeholder-white/50 text-sm mb-4"
              rows={3}
            />

            <div className="flex space-x-3">
              <button className="flex-1 bg-white/20 text-white py-2 rounded-lg font-semibold flex items-center justify-center">
                <Camera className="w-4 h-4 mr-2" />
                Add Photos
              </button>
              <button
                onClick={completeJob}
                className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white py-2 rounded-lg font-bold hover:scale-105 transition-transform"
              >
                Submit Review
              </button>
            </div>
          </div>
        )}

        {job.status === 'completed' && job.customer_rating && (
          <div className="text-center">
            <div className="bg-green-500/20 border border-green-500/30 rounded-xl p-4 mb-4">
              <h4 className="text-green-300 font-semibold mb-2">Service Complete!</h4>
              <p className="text-green-200 text-sm mb-3">
                Payment processed • Installer paid automatically
              </p>
              <div className="flex items-center justify-center space-x-2 text-yellow-400">
                {[...Array(job.customer_rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
            </div>
            
            <button
              onClick={onComplete}
              className="bg-white/20 text-white px-6 py-2 rounded-lg hover:bg-white/30 transition-colors"
            >
              Return to Home
            </button>
          </div>
        )}
      </div>
    </div>
  )
}