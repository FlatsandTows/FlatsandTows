import React, { useState, useEffect } from 'react'
import { 
  Zap, Crown, Star, Users, Clock, Shield, DollarSign, Truck, Wrench, 
  Battery, Navigation, Globe, Gift, Share2, CreditCard,
  CheckCircle, AlertCircle, MessageCircle, Camera, Settings,
  TrendingUp, Target, Award, Rocket, Heart, ThumbsUp, Send, Sparkles,
  Eye, Move3D, Menu, X, Bell, User, Wallet, Map, Timer, Megaphone,
  Brain, Headphones, BarChart3, Layers, Compass, Cpu, Activity,
  ArrowRight, Phone, MapPin, Fuel, Lock, Car
} from 'lucide-react'
import { FastSignupFlow } from './FastSignupFlow'
import { CosmicLogo } from './CosmicLogo'

interface EnhancedLandingPageProps {
  onSignupSuccess: () => void
}

export const EnhancedLandingPage: React.FC<EnhancedLandingPageProps> = ({ onSignupSuccess }) => {
  const [showSignup, setShowSignup] = useState(false)
  const [signupType, setSignupType] = useState<'customer' | 'installer'>('customer')
  const [animatedStats, setAnimatedStats] = useState({
    users: 0,
    installers: 0,
    jobs: 0,
    satisfaction: 0
  })

  // Animate stats on load
  useEffect(() => {
    const targets = { users: 50000, installers: 2000, jobs: 125000, satisfaction: 4.94 }
    const duration = 2000
    const steps = 60
    const stepTime = duration / steps

    let currentStep = 0
    const interval = setInterval(() => {
      currentStep++
      const progress = currentStep / steps
      
      setAnimatedStats({
        users: Math.floor(targets.users * progress),
        installers: Math.floor(targets.installers * progress),
        jobs: Math.floor(targets.jobs * progress),
        satisfaction: Number((targets.satisfaction * progress).toFixed(2))
      })

      if (currentStep >= steps) {
        clearInterval(interval)
        setAnimatedStats(targets)
      }
    }, stepTime)

    return () => clearInterval(interval)
  }, [])

  const openSignup = (type: 'customer' | 'installer') => {
    setSignupType(type)
    setShowSignup(true)
  }

  // Enhanced service offerings with pricing
  const services = [
    { 
      id: 'tire', 
      name: 'Tire Services', 
      icon: Wrench, 
      basePrice: 75, 
      maxPrice: 150,
      description: 'Flat repair, tire change, roadside assistance',
      demand: 'High',
      color: 'from-red-500 to-orange-600'
    },
    { 
      id: 'battery', 
      name: 'Battery Services', 
      icon: Battery, 
      basePrice: 65, 
      maxPrice: 120,
      description: 'Jump start, battery replacement, testing',
      demand: 'Very High',
      color: 'from-blue-500 to-cyan-600'
    },
    { 
      id: 'towing', 
      name: 'Towing Services', 
      icon: Truck, 
      basePrice: 150, 
      maxPrice: 300,
      description: 'Emergency towing, vehicle transport',
      demand: 'Medium',
      color: 'from-purple-500 to-pink-600'
    },
    { 
      id: 'lockout', 
      name: 'Lockout Services', 
      icon: Lock, 
      basePrice: 85, 
      maxPrice: 140,
      description: 'Vehicle unlock, key replacement',
      demand: 'High',
      color: 'from-green-500 to-emerald-600'
    },
    { 
      id: 'fuel', 
      name: 'Fuel Delivery', 
      icon: Fuel, 
      basePrice: 45, 
      maxPrice: 80,
      description: 'Emergency gas delivery, fuel assistance',
      demand: 'Medium',
      color: 'from-yellow-500 to-orange-600'
    },
    { 
      id: 'mechanic', 
      name: 'Mobile Mechanic', 
      icon: Car, 
      basePrice: 120, 
      maxPrice: 250,
      description: 'On-site repairs, diagnostics, maintenance',
      demand: 'Very High',
      color: 'from-indigo-500 to-purple-600'
    }
  ]

  const vipBenefits = [
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Average 6-minute response time vs 15 minutes for standard',
      color: 'text-yellow-400'
    },
    {
      icon: Shield,
      title: 'Premium Protection',
      description: 'Enhanced insurance coverage and priority dispute resolution',
      color: 'text-blue-400'
    },
    {
      icon: DollarSign,
      title: 'Massive Savings',
      description: 'Save 50% on platform fees - pays for itself in 2 services',
      color: 'text-green-400'
    },
    {
      icon: Users,
      title: 'Elite Network',
      description: 'Access to top-rated, verified premium installers only',
      color: 'text-purple-400'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-pink-500/10 rounded-full blur-3xl animate-pulse delay-2000"></div>
      </div>

      <div className="relative z-10">
        {/* Hero Section */}
        <div className="container mx-auto px-4 py-20">
          <div className="text-center mb-16">
            {/* Cosmic Logo */}
            <div className="flex items-center justify-center space-x-3 mb-8">
              <CosmicLogo size="lg" />
            </div>

            {/* Main Headline */}
            <h2 className="text-5xl md:text-7xl font-black leading-tight mb-6">
              <span className="bg-gradient-to-r from-white via-blue-200 to-white bg-clip-text text-transparent">
                ROADSIDE HELP
              </span>
              <br />
              <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
                IN 60 SECONDS
              </span>
            </h2>
            
            <p className="text-xl md:text-2xl text-white/80 max-w-3xl mx-auto leading-relaxed mb-8">
              World's first fully autonomous roadside assistance marketplace. 
              <span className="text-green-400 font-semibold"> AI-powered dispatch</span>, 
              <span className="text-blue-400 font-semibold"> instant payments</span>, 
              <span className="text-purple-400 font-semibold"> 24/7 availability</span>.
            </p>

            {/* Autonomy Badge */}
            <div className="bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 rounded-2xl p-6 inline-block mb-12">
              <div className="flex items-center space-x-4">
                <Cpu className="w-8 h-8 text-cyan-400 animate-pulse" />
                <div>
                  <div className="text-4xl font-black text-cyan-300">96.3%</div>
                  <div className="text-cyan-200 text-sm font-semibold">Fully Autonomous Operations</div>
                </div>
                <div className="flex flex-col space-y-1">
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-green-300 text-xs">AI Dispatch</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                    <span className="text-blue-300 text-xs">Auto Payments</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                    <span className="text-purple-300 text-xs">Smart Matching</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Enhanced CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-6 justify-center max-w-2xl mx-auto mb-12">
              <button
                onClick={() => openSignup('customer')}
                className="group bg-gradient-to-r from-red-600 via-red-500 to-orange-600 text-white px-10 py-5 rounded-2xl font-black text-xl hover:scale-105 transition-all duration-300 shadow-2xl relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-red-400 to-orange-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="relative flex items-center justify-center">
                  <span className="text-2xl mr-3 animate-bounce">🚨</span>
                  <div>
                    <div className="font-black">EMERGENCY HELP</div>
                    <div className="text-sm font-normal opacity-90">15-min response • 24/7</div>
                  </div>
                  <ArrowRight className="w-6 h-6 ml-3 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>
              
              <button
                onClick={() => openSignup('installer')}
                className="group bg-gradient-to-r from-green-500 to-emerald-600 text-white px-10 py-5 rounded-2xl font-black text-xl hover:scale-105 transition-all duration-300 shadow-2xl relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-green-400 to-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="relative flex items-center justify-center">
                  <span className="text-2xl mr-3">💰</span>
                  <div>
                    <div className="font-black">EARN $300+/DAY</div>
                    <div className="text-sm font-normal opacity-90">Join 2,000+ installers</div>
                  </div>
                  <ArrowRight className="w-6 h-6 ml-3 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center items-center gap-8 text-white/60 text-sm">
              <div className="flex items-center space-x-2">
                <Shield className="w-4 h-4 text-green-400" />
                <span>Fully Insured & Licensed</span>
              </div>
              <div className="flex items-center space-x-2">
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <span>4.94★ Average Rating</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-blue-400" />
                <span>Background Verified</span>
              </div>
            </div>
          </div>

          {/* Enhanced Services Section for Installers */}
          <div className="mb-20">
            <div className="text-center mb-12">
              <h3 className="text-4xl font-black text-white mb-4">
                <span className="bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
                  HIGH-DEMAND SERVICES
                </span>
              </h3>
              <p className="text-xl text-white/80 max-w-2xl mx-auto">
                Premium rates, instant payouts, and unlimited earning potential
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
              {services.map((service) => {
                const IconComponent = service.icon
                return (
                  <div key={service.id} className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 hover:scale-105 transition-all duration-300 group">
                    <div className={`w-16 h-16 bg-gradient-to-r ${service.color} rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                      <IconComponent className="w-8 h-8 text-white" />
                    </div>
                    
                    <h4 className="text-white font-bold text-lg mb-2 text-center">{service.name}</h4>
                    <p className="text-white/70 text-sm text-center mb-4">{service.description}</p>
                    
                    <div className="text-center">
                      <div className="text-2xl font-black text-green-400 mb-1">
                        ${service.basePrice} - ${service.maxPrice}
                      </div>
                      <div className="text-white/60 text-xs mb-2">Per Service</div>
                      
                      <div className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                        service.demand === 'Very High' ? 'bg-red-500/20 text-red-300 border border-red-500/30' :
                        service.demand === 'High' ? 'bg-orange-500/20 text-orange-300 border border-orange-500/30' :
                        'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                      }`}>
                        {service.demand} Demand
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>

            {/* Earnings Potential */}
            <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-2xl p-8 text-center">
              <h4 className="text-3xl font-black text-white mb-4">
                💰 UNLIMITED EARNING POTENTIAL
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div>
                  <div className="text-4xl font-black text-green-400">$300+</div>
                  <div className="text-green-200">Per Day Average</div>
                  <div className="text-green-300/70 text-sm">Top performers</div>
                </div>
                <div>
                  <div className="text-4xl font-black text-green-400">$2,100+</div>
                  <div className="text-green-200">Per Week Potential</div>
                  <div className="text-green-300/70 text-sm">Full-time installers</div>
                </div>
                <div>
                  <div className="text-4xl font-black text-green-400">$109K+</div>
                  <div className="text-green-200">Annual Income</div>
                  <div className="text-green-300/70 text-sm">Premium installers</div>
                </div>
              </div>
              
              <div className="flex flex-wrap justify-center gap-4 text-sm text-green-200">
                <div className="flex items-center space-x-2">
                  <Zap className="w-4 h-4 text-green-400" />
                  <span>Instant 60-second payouts</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Crown className="w-4 h-4 text-yellow-400" />
                  <span>Premium installer bonuses</span>
                </div>
                <div className="flex items-center space-x-2">
                  <TrendingUp className="w-4 h-4 text-blue-400" />
                  <span>Surge pricing up to 3x</span>
                </div>
              </div>
            </div>
          </div>

          {/* Animated Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-20">
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 text-center hover:scale-105 transition-transform">
              <Users className="w-8 h-8 text-blue-400 mx-auto mb-3" />
              <div className="text-3xl font-black text-white">{animatedStats.users.toLocaleString()}+</div>
              <div className="text-white/70 text-sm">Happy Customers</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 text-center hover:scale-105 transition-transform">
              <Crown className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
              <div className="text-3xl font-black text-white">{animatedStats.installers.toLocaleString()}+</div>
              <div className="text-white/70 text-sm">Pro Installers</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 text-center hover:scale-105 transition-transform">
              <Target className="w-8 h-8 text-green-400 mx-auto mb-3" />
              <div className="text-3xl font-black text-white">{animatedStats.jobs.toLocaleString()}+</div>
              <div className="text-white/70 text-sm">Jobs Completed</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 text-center hover:scale-105 transition-transform">
              <Star className="w-8 h-8 text-purple-400 mx-auto mb-3" />
              <div className="text-3xl font-black text-white">{animatedStats.satisfaction}★</div>
              <div className="text-white/70 text-sm">Satisfaction</div>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8 text-center hover:scale-105 transition-all duration-300 group">
              <div className="w-20 h-20 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                <Brain className="w-10 h-10 text-white animate-pulse" />
              </div>
              <h3 className="text-white font-black text-xl mb-4">AI-Powered Matching</h3>
              <p className="text-white/70 leading-relaxed">
                Advanced AI matches you with the perfect installer in under 5 seconds with 96.8% accuracy. 
                No more waiting or guessing.
              </p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8 text-center hover:scale-105 transition-all duration-300 group">
              <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                <Zap className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-white font-black text-xl mb-4">Lightning Fast</h3>
              <p className="text-white/70 leading-relaxed">
                Average 6-minute response time. Installers are paid automatically within 60 seconds 
                of job completion. Everything is instant.
              </p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8 text-center hover:scale-105 transition-all duration-300 group">
              <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                <Activity className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-white font-black text-xl mb-4">Self-Healing Platform</h3>
              <p className="text-white/70 leading-relaxed">
                94.7% of disputes resolved automatically in under 15 minutes. 
                The platform fixes itself and learns from every interaction.
              </p>
            </div>
          </div>

          {/* Social Proof */}
          <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-2xl p-8 mb-20">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-black text-white mb-4">Loved by Thousands</h3>
              <div className="flex justify-center space-x-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-6 h-6 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-green-200 text-lg font-semibold">4.94/5 from 50,000+ reviews</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white/10 rounded-xl p-6">
                <p className="text-white/90 italic mb-4">
                  "Got help in 8 minutes at 2 AM! The installer was professional and the app made everything so easy."
                </p>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-sm">SM</span>
                  </div>
                  <div>
                    <div className="text-white font-semibold">Sarah M.</div>
                    <div className="text-white/60 text-sm">Miami, FL</div>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/10 rounded-xl p-6">
                <p className="text-white/90 italic mb-4">
                  "Making $350+ per day as an installer. The AI matching is incredible - I get perfect jobs every time."
                </p>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-sm">MR</span>
                  </div>
                  <div>
                    <div className="text-white font-semibold">Mike R.</div>
                    <div className="text-white/60 text-sm">Dallas, TX</div>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/10 rounded-xl p-6">
                <p className="text-white/90 italic mb-4">
                  "This platform is the future. Everything is automated and works perfectly. Saved me $150 vs competitors."
                </p>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-sm">JL</span>
                  </div>
                  <div>
                    <div className="text-white font-semibold">Jessica L.</div>
                    <div className="text-white/60 text-sm">Phoenix, AZ</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Final CTA */}
          <div className="text-center">
            <h3 className="text-4xl font-black text-white mb-6">
              Ready to Experience the Future?
            </h3>
            <p className="text-xl text-white/80 mb-8 max-w-2xl mx-auto">
              Join the autonomous revolution. Get help in 60 seconds or start earning today.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-lg mx-auto">
              <button
                onClick={() => openSignup('customer')}
                className="bg-gradient-to-r from-red-600 to-orange-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:scale-105 transition-transform flex items-center justify-center"
              >
                <Phone className="w-5 h-5 mr-2" />
                Get Emergency Help
              </button>
              
              <button
                onClick={() => openSignup('installer')}
                className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:scale-105 transition-transform flex items-center justify-center"
              >
                <DollarSign className="w-5 h-5 mr-2" />
                Start Earning $300+/Day
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Fast Signup Flow */}
      <FastSignupFlow
        isOpen={showSignup}
        onClose={() => setShowSignup(false)}
        userType={signupType}
        onSuccess={onSignupSuccess}
      />
    </div>
  )
}