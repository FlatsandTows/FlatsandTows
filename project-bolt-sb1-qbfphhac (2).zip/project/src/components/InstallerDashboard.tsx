import React, { useState, useEffect } from 'react'
import { DollarSign, Clock, Star, TrendingUp, MapPin, Zap, Users, Award, Target, Calendar, Bell, Settings, Eye, Route, Battery } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import { supabase } from '../lib/supabase'

export const InstallerDashboard: React.FC = () => {
  const { user, profile } = useAuth()
  const [installerData, setInstallerData] = useState<any>(null)
  const [activeJobs, setActiveJobs] = useState([])
  const [earnings, setEarnings] = useState({
    today: 0,
    week: 0,
    month: 0,
    total: 0
  })
  const [metrics, setMetrics] = useState({
    completionRate: 0,
    avgRating: 0,
    totalJobs: 0,
    responseTime: 0
  })
  const [isOnline, setIsOnline] = useState(false)
  const [availableJobs, setAvailableJobs] = useState([])

  useEffect(() => {
    loadInstallerData()
    loadActiveJobs()
    loadEarnings()
    loadMetrics()
    loadAvailableJobs()
  }, [user])

  const loadInstallerData = async () => {
    if (!user) return
    
    try {
      const { data, error } = await supabase
        .from('installer_profiles')
        .select('*')
        .eq('id', user.id)
        .single()

      if (error) throw error
      setInstallerData(data)
      setIsOnline(data.is_online)
    } catch (error) {
      console.error('Error loading installer data:', error)
    }
  }

  const loadActiveJobs = async () => {
    if (!user) return
    
    try {
      const { data, error } = await supabase
        .from('jobs')
        .select(`
          *,
          customer:profiles(full_name, phone),
          service_request:service_requests(address, description)
        `)
        .eq('installer_id', user.id)
        .in('status', ['assigned', 'in_progress'])
        .order('created_at', { ascending: false })

      if (error) throw error
      setActiveJobs(data || [])
    } catch (error) {
      console.error('Error loading active jobs:', error)
    }
  }

  const loadEarnings = async () => {
    if (!user) return
    
    try {
      const { data, error } = await supabase
        .from('payments')
        .select('installer_payout, created_at')
        .eq('installer_id', user.id)
        .eq('status', 'completed')

      if (error) throw error

      const now = new Date()
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
      const weekStart = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000)
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1)

      const earnings = {
        today: 0,
        week: 0,
        month: 0,
        total: 0
      }

      data?.forEach(payment => {
        const paymentDate = new Date(payment.created_at)
        const amount = payment.installer_payout

        earnings.total += amount

        if (paymentDate >= today) {
          earnings.today += amount
        }
        if (paymentDate >= weekStart) {
          earnings.week += amount
        }
        if (paymentDate >= monthStart) {
          earnings.month += amount
        }
      })

      setEarnings(earnings)
    } catch (error) {
      console.error('Error loading earnings:', error)
    }
  }

  const loadMetrics = async () => {
    if (!user) return
    
    try {
      const { data, error } = await supabase
        .from('installer_analytics')
        .select('*')
        .eq('id', user.id)
        .single()

      if (error) throw error

      setMetrics({
        completionRate: data.completion_rate || 0,
        avgRating: data.avg_rating_30_days || 0,
        totalJobs: data.total_jobs || 0,
        responseTime: data.response_time_avg || 0
      })
    } catch (error) {
      console.error('Error loading metrics:', error)
    }
  }

  const loadAvailableJobs = async () => {
    if (!user) return
    
    try {
      const { data, error } = await supabase
        .from('service_requests')
        .select(`
          *,
          customer:profiles(full_name),
          bids!left(id)
        `)
        .eq('status', 'bidding')
        .is('assigned_installer_id', null)
        .order('created_at', { ascending: false })
        .limit(10)

      if (error) throw error
      setAvailableJobs(data || [])
    } catch (error) {
      console.error('Error loading available jobs:', error)
    }
  }

  const toggleOnlineStatus = async () => {
    try {
      const newStatus = !isOnline
      
      const { error } = await supabase
        .from('installer_profiles')
        .update({ is_online: newStatus })
        .eq('id', user?.id)

      if (error) throw error
      
      setIsOnline(newStatus)
    } catch (error) {
      console.error('Error updating online status:', error)
    }
  }

  const placeBid = async (requestId: string, price: number, eta: number) => {
    try {
      const { error } = await supabase
        .from('bids')
        .insert({
          request_id: requestId,
          installer_id: user?.id,
          price,
          estimated_arrival: eta,
          expires_at: new Date(Date.now() + 5 * 60 * 1000).toISOString() // 5 minutes
        })

      if (error) throw error
      
      // Refresh available jobs
      loadAvailableJobs()
    } catch (error) {
      console.error('Error placing bid:', error)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-900 via-green-800 to-teal-900 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8 mt-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Installer Dashboard</h1>
            <p className="text-white/80">Welcome back, {installerData?.business_name}</p>
          </div>
          
          <div className="flex items-center space-x-4">
            <button
              onClick={toggleOnlineStatus}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-semibold transition-all ${
                isOnline 
                  ? 'bg-green-600 text-white' 
                  : 'bg-gray-600 text-white'
              }`}
            >
              <div className={`w-3 h-3 rounded-full ${isOnline ? 'bg-green-300 animate-pulse' : 'bg-gray-300'}`}></div>
              <span>{isOnline ? 'Online' : 'Offline'}</span>
            </button>
            
            <button className="bg-white/20 text-white p-2 rounded-lg">
              <Bell className="w-5 h-5" />
            </button>
            
            <button className="bg-white/20 text-white p-2 rounded-lg">
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Earnings Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 text-center">
            <DollarSign className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">${earnings.today.toFixed(2)}</div>
            <div className="text-white/70 text-sm">Today</div>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 text-center">
            <Calendar className="w-6 h-6 text-blue-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">${earnings.week.toFixed(2)}</div>
            <div className="text-white/70 text-sm">This Week</div>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 text-center">
            <TrendingUp className="w-6 h-6 text-purple-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">${earnings.month.toFixed(2)}</div>
            <div className="text-white/70 text-sm">This Month</div>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 text-center">
            <Award className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">${earnings.total.toFixed(2)}</div>
            <div className="text-white/70 text-sm">Total Earned</div>
          </div>
        </div>

        {/* Performance Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 text-center">
            <Target className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{(metrics.completionRate * 100).toFixed(1)}%</div>
            <div className="text-white/70 text-sm">Completion Rate</div>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 text-center">
            <Star className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{metrics.avgRating.toFixed(1)}</div>
            <div className="text-white/70 text-sm">Avg Rating</div>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 text-center">
            <Users className="w-6 h-6 text-blue-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{metrics.totalJobs}</div>
            <div className="text-white/70 text-sm">Total Jobs</div>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 text-center">
            <Clock className="w-6 h-6 text-purple-400 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">{metrics.responseTime} min</div>
            <div className="text-white/70 text-sm">Response Time</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Active Jobs */}
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              <Zap className="w-5 h-5 mr-2 text-yellow-400" />
              Active Jobs ({activeJobs.length})
            </h3>
            
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {activeJobs.map((job) => (
                <div key={job.id} className="bg-white/5 rounded-lg p-4 border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                      <span className="text-white font-semibold">{job.service_type}</span>
                      <span className="bg-green-500 text-white text-xs px-2 py-1 rounded-full">
                        ${job.agreed_price}
                      </span>
                    </div>
                    <span className="text-white/60 text-sm">
                      {new Date(job.created_at).toLocaleTimeString()}
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-2 text-sm text-white/70 mb-3">
                    <MapPin className="w-4 h-4" />
                    <span className="truncate">{job.service_request?.address}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="text-sm">
                      <span className="text-white/60">Customer: </span>
                      <span className="text-white">{job.customer?.full_name}</span>
                    </div>
                    
                    <div className="flex space-x-2">
                      <button className="bg-blue-600 text-white px-3 py-1 rounded-lg text-sm">
                        <Route className="w-3 h-3 inline mr-1" />
                        Navigate
                      </button>
                      <button className="bg-green-600 text-white px-3 py-1 rounded-lg text-sm">
                        <Eye className="w-3 h-3 inline mr-1" />
                        View
                      </button>
                    </div>
                  </div>
                </div>
              ))}
              
              {activeJobs.length === 0 && (
                <div className="text-center text-white/60 py-8">
                  <Battery className="w-8 h-8 mx-auto mb-2" />
                  <p>No active jobs</p>
                  <p className="text-sm">Ready for new assignments</p>
                </div>
              )}
            </div>
          </div>

          {/* Available Jobs */}
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              <Target className="w-5 h-5 mr-2 text-blue-400" />
              Available Jobs ({availableJobs.length})
            </h3>
            
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {availableJobs.map((job) => (
                <div key={job.id} className="bg-white/5 rounded-lg p-4 border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-blue-400 rounded-full animate-pulse"></div>
                      <span className="text-white font-semibold">{job.service_type}</span>
                      <span className="bg-blue-500 text-white text-xs px-2 py-1 rounded-full">
                        Urgency: {job.urgency_level}/5
                      </span>
                    </div>
                    <span className="text-white/60 text-sm">
                      {new Date(job.created_at).toLocaleTimeString()}
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-2 text-sm text-white/70 mb-3">
                    <MapPin className="w-4 h-4" />
                    <span className="truncate">{job.address}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="text-sm">
                      <span className="text-white/60">Bids: </span>
                      <span className="text-white">{job.bids?.length || 0}</span>
                    </div>
                    
                    <button
                      onClick={() => placeBid(job.id, 65, 15)}
                      className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-4 py-1 rounded-lg text-sm font-semibold hover:scale-105 transition-transform"
                    >
                      Quick Bid $65
                    </button>
                  </div>
                </div>
              ))}
              
              {availableJobs.length === 0 && (
                <div className="text-center text-white/60 py-8">
                  <Target className="w-8 h-8 mx-auto mb-2" />
                  <p>No available jobs</p>
                  <p className="text-sm">Check back soon</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}