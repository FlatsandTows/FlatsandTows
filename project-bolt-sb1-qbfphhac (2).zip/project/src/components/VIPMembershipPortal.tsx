import React, { useState } from 'react'
import { Crown, Star, Zap, Shield, Clock, DollarSign, Gift, Users, TrendingUp, Sparkles, CheckCircle, CreditCard } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import { supabase } from '../lib/supabase'

export const VIPMembershipPortal: React.FC = () => {
  const { user, profile, isVIP } = useAuth()
  const [selectedPlan, setSelectedPlan] = useState<'vip' | 'premium'>('vip')
  const [showUpgrade, setShowUpgrade] = useState(false)
  const [loading, setLoading] = useState(false)

  const membershipPlans = {
    vip: {
      name: 'VIP Elite',
      price: 29.99,
      color: 'from-yellow-500 to-orange-600',
      icon: Crown,
      features: [
        'Priority service dispatch',
        '50% reduced platform fees',
        'Premium installer access',
        '24/7 priority support',
        'Guaranteed 15-min response',
        'Free service upgrades',
        'Exclusive member pricing',
        'Concierge service'
      ],
      savings: '$50+ per service'
    },
    premium: {
      name: 'Premium Pro',
      price: 49.99,
      color: 'from-purple-500 to-pink-600',
      icon: Sparkles,
      features: [
        'Everything in VIP Elite',
        'Unlimited priority services',
        'Personal account manager',
        'White-glove service',
        'Custom service packages',
        'Fleet management tools',
        'Advanced analytics',
        'API access'
      ],
      savings: '$100+ per service'
    }
  }

  const vipBenefits = [
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Average 6-minute response time vs 15 minutes for standard',
      color: 'text-yellow-400'
    },
    {
      icon: Shield,
      title: 'Premium Protection',
      description: 'Enhanced insurance coverage and priority dispute resolution',
      color: 'text-blue-400'
    },
    {
      icon: DollarSign,
      title: 'Massive Savings',
      description: 'Save 50% on platform fees - pays for itself in 2 services',
      color: 'text-green-400'
    },
    {
      icon: Users,
      title: 'Elite Network',
      description: 'Access to top-rated, verified premium installers only',
      color: 'text-purple-400'
    }
  ]

  const upgradeToVIP = async () => {
    setLoading(true)
    try {
      // Create Stripe checkout session for VIP membership
      const response = await fetch('/api/create-vip-subscription', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user?.access_token}`
        },
        body: JSON.stringify({
          plan: selectedPlan,
          userId: user?.id
        })
      })

      const { checkout_url } = await response.json()
      window.location.href = checkout_url
    } catch (error) {
      console.error('VIP upgrade error:', error)
    } finally {
      setLoading(false)
    }
  }

  if (isVIP) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-900 via-orange-900 to-red-900 p-4">
        <div className="max-w-4xl mx-auto">
          {/* VIP Dashboard Header */}
          <div className="text-center mb-8 mt-8">
            <div className="w-24 h-24 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Crown className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-2">VIP Elite Dashboard</h2>
            <p className="text-white/80">Welcome back, {profile?.full_name}!</p>
            <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-lg p-3 mt-4 inline-block">
              <span className="text-yellow-300 font-semibold">Active VIP Member</span>
            </div>
          </div>

          {/* VIP Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 text-center">
              <Clock className="w-6 h-6 text-green-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">6 min</div>
              <div className="text-white/70 text-sm">Avg Response</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 text-center">
              <DollarSign className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">$247</div>
              <div className="text-white/70 text-sm">Total Saved</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 text-center">
              <Star className="w-6 h-6 text-purple-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">12</div>
              <div className="text-white/70 text-sm">VIP Services</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 text-center">
              <TrendingUp className="w-6 h-6 text-blue-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">98%</div>
              <div className="text-white/70 text-sm">Satisfaction</div>
            </div>
          </div>

          {/* VIP Perks */}
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6 mb-8">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              <Gift className="w-5 h-5 mr-2 text-yellow-400" />
              Your VIP Perks
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {vipBenefits.map((benefit, index) => (
                <div key={index} className="flex items-start space-x-3 p-3 bg-white/5 rounded-lg">
                  <benefit.icon className={`w-6 h-6 ${benefit.color} flex-shrink-0 mt-1`} />
                  <div>
                    <h4 className="text-white font-semibold">{benefit.title}</h4>
                    <p className="text-white/70 text-sm">{benefit.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Exclusive Offers */}
          <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/30 rounded-xl p-6">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              <Sparkles className="w-5 h-5 mr-2 text-purple-400" />
              Exclusive VIP Offers
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white/10 rounded-lg p-4">
                <h4 className="text-white font-semibold mb-2">Free Premium Upgrade</h4>
                <p className="text-white/70 text-sm mb-3">
                  Get a free tire upgrade to premium brand on your next service.
                </p>
                <button className="bg-purple-600 text-white px-4 py-2 rounded-lg text-sm font-semibold">
                  Claim Offer
                </button>
              </div>
              
              <div className="bg-white/10 rounded-lg p-4">
                <h4 className="text-white font-semibold mb-2">Refer & Earn</h4>
                <p className="text-white/70 text-sm mb-3">
                  Refer friends and earn $25 credit for each successful referral.
                </p>
                <button className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-semibold">
                  Share Code
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12 mt-8">
          <div className="w-20 h-20 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Crown className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-4xl font-bold text-white mb-4">Upgrade to VIP</h2>
          <p className="text-xl text-white/80 mb-6">
            Get priority service, massive savings, and exclusive perks
          </p>
          <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-3 inline-block">
            <span className="text-green-300 font-semibold">
              ⚡ Limited Time: 50% off first month
            </span>
          </div>
        </div>

        {/* Plan Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {Object.entries(membershipPlans).map(([key, plan]) => (
            <div
              key={key}
              onClick={() => setSelectedPlan(key as 'vip' | 'premium')}
              className={`relative cursor-pointer transition-all duration-300 ${
                selectedPlan === key 
                  ? 'scale-105 ring-2 ring-yellow-400' 
                  : 'hover:scale-102'
              }`}
            >
              <div className={`bg-gradient-to-br ${plan.color} rounded-xl p-6 text-white`}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <plan.icon className="w-8 h-8" />
                    <h3 className="text-2xl font-bold">{plan.name}</h3>
                  </div>
                  {selectedPlan === key && (
                    <CheckCircle className="w-6 h-6 text-white" />
                  )}
                </div>
                
                <div className="mb-6">
                  <div className="text-3xl font-bold">${plan.price}</div>
                  <div className="text-white/80">per month</div>
                  <div className="text-sm text-white/70 mt-1">{plan.savings}</div>
                </div>
                
                <div className="space-y-2">
                  {plan.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-white/80" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {vipBenefits.map((benefit, index) => (
            <div key={index} className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6">
              <div className="flex items-center space-x-4 mb-4">
                <div className={`w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center`}>
                  <benefit.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-bold text-lg">{benefit.title}</h3>
              </div>
              <p className="text-white/70">{benefit.description}</p>
            </div>
          ))}
        </div>

        {/* Upgrade Button */}
        <div className="text-center">
          <button
            onClick={() => setShowUpgrade(true)}
            className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white px-12 py-4 rounded-xl font-bold text-xl hover:scale-105 transition-transform shadow-2xl"
          >
            <Crown className="w-6 h-6 inline mr-2" />
            Upgrade to {membershipPlans[selectedPlan].name}
          </button>
          <p className="text-white/60 text-sm mt-4">
            Cancel anytime • 30-day money-back guarantee
          </p>
        </div>

        {/* Upgrade Modal */}
        {showUpgrade && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-gradient-to-br from-slate-900/95 to-purple-900/95 backdrop-blur-xl border border-purple-500/30 rounded-3xl max-w-md w-full p-6">
              <h3 className="text-2xl font-bold text-white mb-4">Confirm Upgrade</h3>
              
              <div className="bg-white/10 rounded-xl p-4 mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white">{membershipPlans[selectedPlan].name}</span>
                  <span className="text-white font-bold">${membershipPlans[selectedPlan].price}/mo</span>
                </div>
                <div className="text-green-400 text-sm">50% off first month: $14.99</div>
              </div>
              
              <div className="flex space-x-3">
                <button
                  onClick={() => setShowUpgrade(false)}
                  className="flex-1 bg-white/20 text-white py-3 rounded-lg font-semibold"
                >
                  Cancel
                </button>
                <button
                  onClick={upgradeToVIP}
                  disabled={loading}
                  className="flex-1 bg-gradient-to-r from-yellow-500 to-orange-600 text-white py-3 rounded-lg font-semibold flex items-center justify-center"
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <CreditCard className="w-4 h-4 mr-2" />
                      Upgrade Now
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}