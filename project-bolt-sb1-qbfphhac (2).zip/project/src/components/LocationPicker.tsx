import React, { useState, useEffect } from 'react'
import { MapPin, Navigation, AlertCircle, CheckCircle, Crosshair } from 'lucide-react'
import { getCurrentLocation, reverseGeocode, isLocationAvailable, requestLocationPermission } from '../lib/maps'

interface LocationPickerProps {
  onLocationSelect: (location: { lat: number; lng: number; address: string }) => void
  initialLocation?: { lat: number; lng: number }
  className?: string
}

export const LocationPicker: React.FC<LocationPickerProps> = ({
  onLocationSelect,
  initialLocation,
  className = ''
}) => {
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(initialLocation || null)
  const [address, setAddress] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [hasPermission, setHasPermission] = useState(false)

  useEffect(() => {
    checkLocationPermission()
  }, [])

  useEffect(() => {
    if (currentLocation) {
      updateAddress(currentLocation)
    }
  }, [currentLocation])

  const checkLocationPermission = async () => {
    if (!isLocationAvailable()) {
      setError('Location services not available on this device')
      return
    }

    try {
      const permission = await requestLocationPermission()
      setHasPermission(permission)
      
      if (permission && !currentLocation) {
        getCurrentUserLocation()
      }
    } catch (err) {
      console.log('Location permission check failed:', err)
    }
  }

  const getCurrentUserLocation = async () => {
    setLoading(true)
    setError('')

    try {
      const location = await getCurrentLocation()
      setCurrentLocation({ lat: location.lat, lng: location.lng })
      setHasPermission(true)
    } catch (err: any) {
      setError(err.message || 'Failed to get location')
    } finally {
      setLoading(false)
    }
  }

  const updateAddress = async (location: { lat: number; lng: number }) => {
    try {
      const addressText = await reverseGeocode(location)
      setAddress(addressText)
      onLocationSelect({
        ...location,
        address: addressText
      })
    } catch (error) {
      console.error('Address lookup failed:', error)
      const fallbackAddress = `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`
      setAddress(fallbackAddress)
      onLocationSelect({
        ...location,
        address: fallbackAddress
      })
    }
  }

  const handleManualLocationInput = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    const manualAddress = formData.get('address') as string
    
    if (manualAddress.trim()) {
      // For manual input, we'll use a default location and the provided address
      const defaultLocation = { lat: 26.1224, lng: -80.1373 } // Coral Springs, FL
      setCurrentLocation(defaultLocation)
      setAddress(manualAddress)
      onLocationSelect({
        ...defaultLocation,
        address: manualAddress
      })
    }
  }

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Current Location Button */}
      <div className="flex space-x-3">
        <button
          onClick={getCurrentUserLocation}
          disabled={loading || !isLocationAvailable()}
          className="flex-1 bg-blue-600 hover:bg-blue-500 disabled:bg-gray-600 disabled:opacity-50 text-white py-3 px-4 rounded-lg font-semibold transition-colors flex items-center justify-center"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
          ) : (
            <>
              <Crosshair className="w-5 h-5 mr-2" />
              Use Current Location
            </>
          )}
        </button>
      </div>

      {/* Location Status */}
      {error && (
        <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 text-red-400" />
            <p className="text-red-300 text-sm">{error}</p>
          </div>
        </div>
      )}

      {currentLocation && address && (
        <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-3">
          <div className="flex items-start space-x-2">
            <CheckCircle className="w-4 h-4 text-green-400 mt-0.5" />
            <div>
              <p className="text-green-300 text-sm font-semibold">Location Selected</p>
              <p className="text-green-200 text-sm">{address}</p>
              <p className="text-green-300/70 text-xs">
                {currentLocation.lat.toFixed(4)}, {currentLocation.lng.toFixed(4)}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Manual Address Input */}
      <div className="border-t border-white/20 pt-4">
        <h4 className="text-white/80 text-sm font-medium mb-2">Or enter address manually:</h4>
        <form onSubmit={handleManualLocationInput} className="flex space-x-2">
          <input
            name="address"
            type="text"
            placeholder="Enter your address..."
            className="flex-1 bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-white/50 text-sm focus:outline-none focus:border-blue-500"
          />
          <button
            type="submit"
            className="bg-purple-600 hover:bg-purple-500 text-white px-4 py-2 rounded-lg font-semibold transition-colors flex items-center"
          >
            <MapPin className="w-4 h-4" />
          </button>
        </form>
      </div>

      {/* Location Permission Info */}
      {!hasPermission && isLocationAvailable() && (
        <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-3">
          <div className="flex items-start space-x-2">
            <Navigation className="w-4 h-4 text-blue-400 mt-0.5" />
            <div>
              <p className="text-blue-300 text-sm font-semibold">Location Permission Needed</p>
              <p className="text-blue-200 text-xs">
                Allow location access for faster service matching and accurate installer dispatch.
              </p>
            </div>
          </div>
        </div>
      )}

      {!isLocationAvailable() && (
        <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-lg p-3">
          <div className="flex items-start space-x-2">
            <AlertCircle className="w-4 h-4 text-yellow-400 mt-0.5" />
            <div>
              <p className="text-yellow-300 text-sm font-semibold">Location Services Unavailable</p>
              <p className="text-yellow-200 text-xs">
                Please enter your address manually. Location services are not supported on this device.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}