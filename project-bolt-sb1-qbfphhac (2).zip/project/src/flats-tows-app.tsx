import React, { useState, useEffect } from 'react';
import { 
  MapPin, Phone, Clock, Star, Users, DollarSign, Truck, Wrench, 
  Battery, Shield, Zap, Navigation, Globe, Gift, Share2, CreditCard,
  CheckCircle, AlertCircle, MessageCircle, Camera, Settings, Crown,
  TrendingUp, Target, Award, Rocket, Heart, ThumbsUp, Send, Sparkles,
  Eye, Move3D, Menu, X, Bell, User, Wallet, Map, Timer, Megaphone,
  Brain, Headphones, BarChart3, Layers, Compass, Cpu, Activity, Package
} from 'lucide-react';
import { useAuth } from './hooks/useAuth';
import { LiveBidding } from './components/LiveBidding';
import { AdvancedJobTracking } from './components/AdvancedJobTracking';
import { AutonomousDispatchEngine } from './components/AutonomousDispatchEngine';
import { VIPMembershipPortal } from './components/VIPMembershipPortal';
import { InstallerDashboard } from './components/InstallerDashboard';
import { PickupDeliveryFlow } from './components/PickupDeliveryFlow';
import { CosmicLogo } from './components/CosmicLogo';
import { LocationPicker } from './components/LocationPicker';
import { findNearbyInstallers } from './lib/database';
import { getCurrentLocation, isLocationAvailable } from './lib/maps';
import { isDemo } from './lib/supabase';

const FlatsAndTowsApp = () => {
  const { user, profile, isInstaller, isCustomer, isVIP } = useAuth();
  const [currentView, setCurrentView] = useState('home');
  const [userLocation, setUserLocation] = useState(null);
  const [nearbyInstallers, setNearbyInstallers] = useState([]);
  const [selectedService, setSelectedService] = useState(null);
  const [activeJob, setActiveJob] = useState(null);
  const [showAIChatbot, setShowAIChatbot] = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [autonomyLevel, setAutonomyLevel] = useState(96.3);
  const [locationError, setLocationError] = useState('');

  // Get user location on app load
  useEffect(() => {
    const initializeLocation = async () => {
      if (!isLocationAvailable()) {
        setLocationError('Location services not available on this device');
        // Use default location (Miami, FL)
        setUserLocation({ lat: 25.7617, lng: -80.1918 });
        return;
      }

      try {
        const location = await getCurrentLocation();
        setUserLocation({
          lat: location.lat,
          lng: location.lng
        });
        
        // Find nearby installers
        try {
          const installers = await findNearbyInstallers(location.lat, location.lng);
          setNearbyInstallers(installers);
        } catch (error) {
          console.error('Error finding installers:', error);
        }
      } catch (error) {
        console.log('Location access denied, using default location');
        setLocationError('Location access denied. Using default location.');
        setUserLocation({ lat: 25.7617, lng: -80.1918 }); // Miami fallback
      }
    };

    initializeLocation();
  }, []);

  // Enhanced AI Chatbot Component
  const EnhancedAIChatbot = () => {
    const [input, setInput] = useState('');
    const [isTyping, setIsTyping] = useState(false);

    const sendMessage = async (message, isUser = true) => {
      const newMessage = {
        id: Date.now(),
        role: isUser ? 'user' : 'assistant',
        content: message,
        timestamp: new Date()
      };
      setChatMessages(prev => [...prev, newMessage]);
      
      if (isUser) {
        setIsTyping(true);
        try {
          // Simulate AI response in demo mode
          setTimeout(() => {
            setIsTyping(false);
            const responses = [
              "I'm here to help with your roadside assistance needs! Our platform is 96.3% autonomous and can dispatch help in under 60 seconds.",
              "You can request emergency tire, battery, towing, lockout, fuel, mechanic, or pickup/delivery services. All installers are verified and insured.",
              "Our AI matches you with the best installer based on location, ratings, and availability. Payment is secure and automatic.",
              "VIP members get priority service, reduced fees, and access to premium installers. Would you like to learn more?",
              "Our new pickup & delivery service lets you get auto parts and tires delivered with custom pricing from providers!"
            ];
            const randomResponse = responses[Math.floor(Math.random() * responses.length)];
            sendMessage(randomResponse, false);
          }, 1000 + Math.random() * 2000);
        } catch (error) {
          setIsTyping(false);
          sendMessage("I'm having trouble processing your request. Please try again or contact support.", false);
        }
      }
    };

    const handleSubmit = (e) => {
      e.preventDefault();
      if (input.trim()) {
        sendMessage(input.trim());
        setInput('');
      }
    };

    // Initialize with greeting
    React.useEffect(() => {
      if (chatMessages.length === 0 && showAIChatbot) {
        const greeting = `Hi! I'm your AI assistant for Flats & Tows. Our platform is ${autonomyLevel}% autonomous - I can help with service requests, pricing, tracking, pickup/delivery, and more. How can I assist you today? 🤖`;
        sendMessage(greeting, false);
      }
    }, [showAIChatbot]);

    return (
      <div className="fixed bottom-24 right-6 z-50">
        <div className="bg-gradient-to-br from-slate-900/95 to-purple-900/95 backdrop-blur-xl border border-purple-500/30 rounded-2xl w-80 h-96 flex flex-col shadow-2xl">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-4 rounded-t-2xl flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                <Brain className="w-4 h-4 text-white" />
              </div>
              <div>
                <h4 className="text-white font-semibold text-sm">AI Assistant</h4>
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="text-white/80 text-xs">{autonomyLevel}% Autonomous</span>
                </div>
              </div>
            </div>
            <button 
              onClick={() => setShowAIChatbot(false)}
              className="text-white/70 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 p-4 overflow-y-auto space-y-3">
            {chatMessages.map((message) => (
              <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-3 rounded-xl text-sm ${
                  message.role === 'user' 
                    ? 'bg-blue-600 text-white rounded-br-sm' 
                    : 'bg-white/20 text-white rounded-bl-sm'
                }`}>
                  {message.content}
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-white/20 text-white p-3 rounded-xl rounded-bl-sm">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce delay-100"></div>
                    <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce delay-200"></div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <form onSubmit={handleSubmit} className="p-4 border-t border-white/10">
            <div className="flex space-x-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask me anything..."
                className="flex-1 bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-white/50 text-sm focus:outline-none focus:border-blue-500"
              />
              <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-500 text-white p-2 rounded-lg transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  // Enhanced Navigation
  const NavigationMenu = () => (
    <div className="fixed top-0 left-0 right-0 z-40 bg-gradient-to-r from-slate-900/95 to-purple-900/95 backdrop-blur-xl border-b border-white/20">
      <div className="max-w-6xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <CosmicLogo size="sm" />
          </div>
          
          <div className="hidden md:flex items-center space-x-6">
            <button 
              onClick={() => setCurrentView('home')}
              className={`text-sm font-medium transition-colors ${currentView === 'home' ? 'text-white' : 'text-white/70 hover:text-white'}`}
            >
              Home
            </button>
            {isInstaller && (
              <button 
                onClick={() => setCurrentView('installer-dashboard')}
                className={`text-sm font-medium transition-colors ${currentView === 'installer-dashboard' ? 'text-white' : 'text-white/70 hover:text-white'}`}
              >
                Dashboard
              </button>
            )}
            <button 
              onClick={() => setCurrentView('autonomous-engine')}
              className={`text-sm font-medium transition-colors flex items-center space-x-1 ${currentView === 'autonomous-engine' ? 'text-white' : 'text-white/70 hover:text-white'}`}
            >
              <Cpu className="w-4 h-4" />
              <span>AI Engine</span>
            </button>
            {!isVIP && (
              <button 
                onClick={() => setCurrentView('vip')}
                className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:scale-105 transition-transform"
              >
                <Crown className="w-4 h-4 inline mr-1" />
                Upgrade VIP
              </button>
            )}
          </div>
          
          <div className="flex items-center space-x-4">
            {profile && (
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-bold">
                    {profile.full_name?.charAt(0) || profile.email.charAt(0).toUpperCase()}
                  </span>
                </div>
                {isVIP && <Crown className="w-4 h-4 text-yellow-400" />}
              </div>
            )}
            
            <div className="flex items-center space-x-1 text-green-400 text-xs">
              <Activity className="w-3 h-3 animate-pulse" />
              <span>Live</span>
            </div>
            
            <button 
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="md:hidden text-white"
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {showMobileMenu && (
          <div className="md:hidden mt-4 pb-4 border-t border-white/20 pt-4">
            <div className="space-y-2">
              <button 
                onClick={() => { setCurrentView('home'); setShowMobileMenu(false); }}
                className="block w-full text-left text-white/70 hover:text-white py-2"
              >
                Home
              </button>
              {isInstaller && (
                <button 
                  onClick={() => { setCurrentView('installer-dashboard'); setShowMobileMenu(false); }}
                  className="block w-full text-left text-white/70 hover:text-white py-2"
                >
                  Dashboard
                </button>
              )}
              <button 
                onClick={() => { setCurrentView('autonomous-engine'); setShowMobileMenu(false); }}
                className="block w-full text-left text-white/70 hover:text-white py-2"
              >
                AI Engine
              </button>
              {!isVIP && (
                <button 
                  onClick={() => { setCurrentView('vip'); setShowMobileMenu(false); }}
                  className="block w-full text-left text-yellow-400 hover:text-yellow-300 py-2"
                >
                  Upgrade to VIP
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );

  // Emergency Request Flow (Enhanced with Pickup/Delivery)
  const EmergencyRequestFlow = () => {
    const [step, setStep] = useState(1);
    const [selectedLocation, setSelectedLocation] = useState(null);

    if (step === 1) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-red-900 via-red-800 to-orange-900 p-4 pt-20">
          <div className="max-w-md mx-auto">
            <div className="text-center mb-8 mt-8">
              <div className="w-24 h-24 bg-gradient-to-r from-red-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                <AlertCircle className="w-12 h-12 text-white animate-bounce" />
              </div>
              <h2 className="text-3xl font-bold text-white mb-2">EMERGENCY ASSISTANCE</h2>
              <p className="text-white/80">AI-powered instant dispatch</p>
              
              {/* Demo Mode Notice */}
              {isDemo && (
                <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-3 mt-4">
                  <div className="flex items-center justify-center space-x-2 text-blue-400">
                    <Sparkles className="w-4 h-4" />
                    <span className="text-sm">Demo Mode - Full experience without database</span>
                  </div>
                </div>
              )}
              
              {/* Location Status */}
              {locationError && (
                <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-lg p-3 mt-4">
                  <div className="flex items-center justify-center space-x-2 text-yellow-400">
                    <AlertCircle className="w-4 h-4" />
                    <span className="text-sm">{locationError}</span>
                  </div>
                </div>
              )}
              
              {userLocation && !locationError && (
                <div className="bg-white/10 rounded-lg p-3 mt-4 backdrop-blur-sm">
                  <div className="flex items-center justify-center space-x-2 text-green-400">
                    <MapPin className="w-4 h-4" />
                    <span className="text-sm">Location ready • {nearbyInstallers.length} installers nearby</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-cyan-400 text-xs mt-1">
                    <Cpu className="w-3 h-3 animate-pulse" />
                    <span>{autonomyLevel}% autonomous dispatch ready</span>
                  </div>
                </div>
              )}
            </div>

            {/* Location Picker */}
            <div className="mb-6">
              <LocationPicker
                onLocationSelect={(location) => {
                  setSelectedLocation(location);
                  setUserLocation({ lat: location.lat, lng: location.lng });
                }}
                initialLocation={userLocation}
              />
            </div>

            <div className="space-y-3">
              {[
                { id: 'tire', name: 'Tire Emergency', icon: Wrench, basePrice: 49, urgent: true, description: 'Flat tire, blowout, or tire change' },
                { id: 'battery', name: 'Dead Battery', icon: Battery, basePrice: 39, urgent: true, description: 'Jump start or battery replacement' },
                { id: 'towing', name: 'Need Towing', icon: Truck, basePrice: 89, urgent: false, description: 'Vehicle towing and transport' },
                { id: 'lockout', name: 'Locked Out', icon: Zap, basePrice: 59, urgent: true, description: 'Vehicle lockout assistance' },
                { id: 'fuel', name: 'Out of Gas', icon: Navigation, basePrice: 29, urgent: false, description: 'Emergency fuel delivery' },
                { id: 'pickup_delivery', name: 'Pickup & Delivery', icon: Package, basePrice: 35, urgent: false, description: 'Auto parts and tire delivery' }
              ].map((service) => {
                const IconComponent = service.icon;
                return (
                  <button
                    key={service.id}
                    onClick={() => {
                      if (!userLocation) {
                        alert('Please select your location first');
                        return;
                      }
                      setSelectedService(service);
                      if (service.id === 'pickup_delivery') {
                        setCurrentView('pickup-delivery');
                      } else {
                        setStep(2);
                      }
                    }}
                    className="w-full bg-white/10 border border-white/20 rounded-xl p-4 text-left hover:bg-white/20 transition-all duration-300 group backdrop-blur-sm"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-14 h-14 bg-gradient-to-r from-red-500 to-orange-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                        <IconComponent className="w-7 h-7 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="text-white font-semibold flex items-center space-x-2">
                          <span>{service.name}</span>
                          {service.urgent && <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full animate-pulse">URGENT</span>}
                          {service.id === 'pickup_delivery' && <span className="bg-purple-500 text-white text-xs px-2 py-1 rounded-full">NEW</span>}
                        </div>
                        <div className="text-white/60 text-sm">{service.description}</div>
                        <div className="flex items-center space-x-1 text-xs text-cyan-400 mt-1">
                          <Brain className="w-3 h-3" />
                          <span>AI auto-dispatch available</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-white font-bold text-xl">${service.basePrice}+</div>
                        <div className="text-white/60 text-xs">Starting at</div>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            <button 
              onClick={() => setCurrentView('home')}
              className="w-full mt-6 py-3 text-white/70 hover:text-white transition-colors"
            >
              ← Back to Home
            </button>
          </div>
        </div>
      );
    }

    if (step === 2 && selectedService && userLocation) {
      return (
        <LiveBidding
          serviceType={selectedService.id}
          location={userLocation}
          address={selectedLocation?.address || "Current Location"}
          description={`${selectedService.name} service needed`}
          onJobCreated={(job) => {
            setActiveJob(job);
            setStep(3);
          }}
        />
      );
    }

    if (step === 3 && activeJob) {
      return (
        <AdvancedJobTracking
          jobId={activeJob.id}
          onComplete={() => {
            setActiveJob(null);
            setCurrentView('home');
          }}
        />
      );
    }

    return null;
  };

  // Enhanced Homepage
  const HomePage = () => (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 pt-20">
      <main className="relative z-40 px-6 pt-8">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h2 className="text-4xl md:text-6xl font-black leading-tight mb-4">
            <span className="bg-gradient-to-r from-white via-blue-200 to-white bg-clip-text text-transparent">
              AUTONOMOUS
            </span>
            <br />
            <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
              MARKETPLACE
            </span>
          </h2>
          
          <p className="text-lg text-white/80 max-w-2xl mx-auto leading-relaxed mb-4">
            World's first {autonomyLevel}% autonomous roadside assistance marketplace. 
            AI-powered dispatch, instant payments, predictive scaling, plus pickup & delivery.
          </p>
          
          <div className="bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 rounded-xl p-4 inline-block mb-8">
            <div className="flex items-center space-x-3">
              <Cpu className="w-6 h-6 text-cyan-400 animate-pulse" />
              <div>
                <div className="text-2xl font-bold text-cyan-300">{autonomyLevel}%</div>
                <div className="text-cyan-200 text-sm">Fully Autonomous</div>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <button
              onClick={() => setCurrentView('emergency')}
              className="bg-gradient-to-r from-red-600 via-red-500 to-orange-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:scale-105 transition-transform shadow-xl animate-pulse"
            >
              🚨 Emergency Help
            </button>
            
            <button
              onClick={() => setCurrentView('pickup-delivery')}
              className="bg-gradient-to-r from-purple-500 to-pink-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:scale-105 transition-transform shadow-xl"
            >
              📦 Pickup & Delivery
            </button>
            
            {isInstaller && (
              <button
                onClick={() => setCurrentView('installer-dashboard')}
                className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:scale-105 transition-transform shadow-xl"
              >
                💰 Installer Hub
              </button>
            )}
            
            <button
              onClick={() => setCurrentView('autonomous-engine')}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:scale-105 transition-transform shadow-xl"
            >
              🤖 AI Engine
            </button>
          </div>

          {/* Enhanced Live Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            {[
              { icon: Users, label: "Live Installers", value: nearbyInstallers.length.toString(), color: "from-blue-500 to-purple-600", pulse: true },
              { icon: Cpu, label: "AI Accuracy", value: "96.8%", color: "from-cyan-500 to-blue-600", pulse: true },
              { icon: Clock, label: "Avg Response", value: "4.2s", color: "from-green-500 to-emerald-600", pulse: false },
              { icon: Star, label: "Satisfaction", value: "4.94★", color: "from-yellow-500 to-orange-600", pulse: false }
            ].map((stat, index) => {
              const IconComponent = stat.icon;
              return (
                <div key={index} className={`bg-gradient-to-br ${stat.color} rounded-xl p-4 text-center border border-white/10 hover:scale-105 transition-all duration-300 ${stat.pulse ? 'animate-pulse' : ''}`}>
                  <IconComponent className="w-6 h-6 text-white mx-auto mb-2" />
                  <div className="text-lg font-bold text-white">{stat.value}</div>
                  <div className="text-white/80 text-xs">{stat.label}</div>
                </div>
              );
            })}
          </div>

          {/* Autonomous Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6 text-center hover:scale-105 transition-transform">
              <div className="w-16 h-16 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Cpu className="w-8 h-8 text-white animate-pulse" />
              </div>
              <h3 className="text-white font-bold text-lg mb-2">Autonomous Dispatch</h3>
              <p className="text-white/70 text-sm">AI automatically matches and assigns jobs with 96.8% accuracy in under 5 seconds</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6 text-center hover:scale-105 transition-transform">
              <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-white font-bold text-lg mb-2">Instant Everything</h3>
              <p className="text-white/70 text-sm">Automated payments, instant payouts, real-time tracking - all without human intervention</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6 text-center hover:scale-105 transition-transform">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-white font-bold text-lg mb-2">Pickup & Delivery</h3>
              <p className="text-white/70 text-sm">Auto parts and tire delivery with custom pricing and negotiation capabilities</p>
            </div>
          </div>
        </div>
      </main>

      {/* Enhanced Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col space-y-3">
        <button
          onClick={() => setShowAIChatbot(true)}
          className="w-14 h-14 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-xl hover:scale-110 transition-all duration-300 group"
        >
          <Brain className="w-6 h-6 text-white group-hover:animate-pulse" />
          <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-400 rounded-full flex items-center justify-center animate-pulse">
            <span className="text-white text-xs font-bold">AI</span>
          </div>
        </button>

        <button
          onClick={() => setCurrentView('emergency')}
          className="w-16 h-16 bg-gradient-to-r from-red-500 to-orange-600 rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-all duration-300 animate-bounce"
        >
          <Phone className="w-8 h-8 text-white" />
        </button>
      </div>

      {showAIChatbot && <EnhancedAIChatbot />}
    </div>
  );

  // Main render logic with navigation
  return (
    <div className="min-h-screen">
      <NavigationMenu />
      
      {currentView === 'home' && <HomePage />}
      {currentView === 'emergency' && <EmergencyRequestFlow />}
      {currentView === 'pickup-delivery' && (
        <PickupDeliveryFlow
          onComplete={(data) => {
            console.log('Pickup/Delivery completed:', data);
            setCurrentView('home');
          }}
          onBack={() => setCurrentView('home')}
        />
      )}
      {currentView === 'installer-dashboard' && isInstaller && <InstallerDashboard />}
      {currentView === 'autonomous-engine' && <AutonomousDispatchEngine onJobAssigned={(job) => setActiveJob(job)} />}
      {currentView === 'vip' && <VIPMembershipPortal />}
    </div>
  );
};

export default FlatsAndTowsApp;