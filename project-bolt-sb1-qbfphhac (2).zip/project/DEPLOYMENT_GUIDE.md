# 🚀 Hostinger Domain Deployment Guide for Flats & Tows

## 📋 Prerequisites
- Hostinger hosting account with your domain
- Node.js 18+ installed locally
- Git repository access

## 🌐 Deployment Options

### Option 1: Static Site Hosting (Recommended)
Perfect for React apps with external APIs (Supabase)

#### Step 1: Build Your App
```bash
npm run build
```

#### Step 2: Upload to Hostinger
1. **Via File Manager:**
   - Login to Hostinger control panel
   - Go to File Manager
   - Navigate to `public_html` folder
   - Upload all files from `dist` folder
   - Ensure `.htaccess` file is uploaded

2. **Via FTP:**
   ```bash
   # Using FileZilla or similar FTP client
   Host: your-domain.com
   Username: your-hostinger-username
   Password: your-hostinger-password
   Port: 21
   
   # Upload dist/* to public_html/
   ```

#### Step 3: Configure Domain
1. In Hostinger control panel, go to **Domains**
2. Set your domain to point to `public_html`
3. Enable SSL certificate (free Let's Encrypt)

### Option 2: Node.js Hosting
If your Hostinger plan supports Node.js

#### Step 1: Enable Node.js
1. Go to Hostinger control panel
2. Find **Node.js** section
3. Create new Node.js app
4. Set Node.js version to 18+

#### Step 2: Deploy Code
```bash
# Clone your repository
git clone your-repo-url
cd flats-tows-app

# Install dependencies
npm install

# Build the app
npm run build

# Start the app
npm run preview
```

### Option 3: Netlify with Custom Domain
Deploy to Netlify and connect your Hostinger domain

#### Step 1: Deploy to Netlify
1. Connect your GitHub repository to Netlify
2. Set build command: `npm run build`
3. Set publish directory: `dist`

#### Step 2: Configure Custom Domain
1. In Netlify dashboard, go to **Domain settings**
2. Add your Hostinger domain
3. Update DNS records in Hostinger:
   ```
   Type: CNAME
   Name: www
   Value: your-netlify-site.netlify.app
   
   Type: A
   Name: @
   Value: 75.2.60.5 (Netlify's IP)
   ```

## 🔧 Environment Variables Setup

### For Static Hosting
Create `.env.production` file:
```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
VITE_STRIPE_PUBLISHABLE_KEY=pk_live_your-stripe-key
VITE_GOOGLE_MAPS_API_KEY=your-google-maps-key
```

### For Node.js Hosting
Set environment variables in Hostinger control panel:
- `NODE_ENV=production`
- `VITE_SUPABASE_URL=your-supabase-url`
- `VITE_SUPABASE_ANON_KEY=your-anon-key`
- `VITE_STRIPE_PUBLISHABLE_KEY=your-stripe-key`

## 🛡️ Security Configuration

### SSL Certificate
1. In Hostinger control panel
2. Go to **SSL** section
3. Enable **Let's Encrypt SSL** (free)
4. Force HTTPS redirects

### Domain Security
Add these DNS records for security:
```
Type: TXT
Name: @
Value: v=spf1 include:_spf.hostinger.com ~all

Type: TXT  
Name: _dmarc
Value: v=DMARC1; p=quarantine; rua=mailto:admin@your-domain.com
```

## 📱 Mobile App Configuration

### PWA Setup
The app includes PWA configuration. After deployment:
1. Test on mobile devices
2. Verify "Add to Home Screen" works
3. Check offline functionality

### App Store Deployment (Optional)
For native mobile apps:
1. Use Capacitor to build native apps
2. Deploy to App Store/Google Play
3. Configure deep linking to your domain

## 🔍 Testing Your Deployment

### Pre-deployment Checklist
- [ ] All environment variables configured
- [ ] SSL certificate installed
- [ ] DNS records updated
- [ ] .htaccess file uploaded
- [ ] Build completed successfully
- [ ] All routes work correctly

### Post-deployment Testing
```bash
# Test your domain
curl -I https://your-domain.com

# Check SSL
openssl s_client -connect your-domain.com:443

# Test API endpoints
curl https://your-domain.com/api/health
```

## 🚨 Troubleshooting

### Common Issues

#### 404 Errors on Refresh
**Problem:** React Router routes return 404
**Solution:** Ensure `.htaccess` file is uploaded and configured

#### API Calls Failing
**Problem:** CORS or environment variable issues
**Solution:** Check environment variables and API URLs

#### Slow Loading
**Problem:** Large bundle size
**Solution:** Enable compression in `.htaccess`

#### SSL Issues
**Problem:** Mixed content warnings
**Solution:** Ensure all resources use HTTPS

### Performance Optimization

#### Enable Compression
Already configured in `.htaccess`

#### CDN Setup
1. Enable Cloudflare in Hostinger
2. Configure caching rules
3. Enable minification

#### Image Optimization
```bash
# Optimize images before upload
npm install -g imagemin-cli
imagemin src/assets/* --out-dir=dist/assets
```

## 📞 Support

### Hostinger Support
- Live chat available 24/7
- Knowledge base: hostinger.com/tutorials
- Email: support@hostinger.com

### App-Specific Issues
- Check browser console for errors
- Verify environment variables
- Test API endpoints individually

## 🎯 Next Steps

1. **Monitor Performance:**
   - Set up Google Analytics
   - Monitor Core Web Vitals
   - Track user engagement

2. **SEO Optimization:**
   - Add meta tags
   - Configure sitemap
   - Set up Google Search Console

3. **Backup Strategy:**
   - Regular database backups
   - Code repository backups
   - Environment configuration backups

---

## 🚀 Quick Start Commands

```bash
# Build for production
npm run build

# Test production build locally
npm run preview

# Deploy to Hostinger (via FTP)
# Upload dist/* to public_html/

# Verify deployment
curl -I https://your-domain.com
```

Your Flats & Tows cosmic marketplace is ready to dominate the roadside assistance universe! 🌟