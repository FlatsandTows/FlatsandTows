/*
  # Fix Database Schema Issues

  1. Add Missing Tables
    - `installer_tax_info` - Tax information for 1099 forms
    - `installer_driver_licenses` - Driver license verification
    - `installer_profile_photos` - Profile photos for trust
    - `background_checks` - Background verification tracking
    - `verification_documents` - Document management
    - `notifications` - Notification logging
    - `push_tokens` - Push notification tokens
    - `emergency_broadcasts` - Emergency broadcast tracking
    - `autonomous_actions` - AI action logging
    - `fraud_flags` - Fraud detection flags
    - `quality_actions` - Quality assurance actions
    - `installer_flags` - Installer review flags
    - `user_activity_log` - User activity tracking

  2. Security
    - Enable RLS on all new tables
    - Add appropriate policies
*/

-- Create additional tables for verification system

-- Installer tax information (1099)
CREATE TABLE IF NOT EXISTS installer_tax_info (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  installer_id uuid NOT NULL REFERENCES installer_profiles(id) ON DELETE CASCADE,
  ssn text, -- Base64 encoded for security
  ein text,
  business_type text NOT NULL DEFAULT 'individual',
  legal_name text NOT NULL,
  business_name text,
  address text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  zip_code text NOT NULL,
  phone_number text NOT NULL,
  email text NOT NULL,
  status text DEFAULT 'pending_verification',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Driver license verification
CREATE TABLE IF NOT EXISTS installer_driver_licenses (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  installer_id uuid NOT NULL REFERENCES installer_profiles(id) ON DELETE CASCADE,
  license_number text NOT NULL,
  state text NOT NULL,
  expiration_date date NOT NULL,
  front_image_url text NOT NULL,
  back_image_url text NOT NULL,
  status text DEFAULT 'pending_verification',
  verified_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Profile photos
CREATE TABLE IF NOT EXISTS installer_profile_photos (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  installer_id uuid NOT NULL REFERENCES installer_profiles(id) ON DELETE CASCADE,
  photo_url text NOT NULL,
  status text DEFAULT 'pending_verification',
  verified_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Background checks
CREATE TABLE IF NOT EXISTS background_checks (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  installer_id uuid NOT NULL REFERENCES installer_profiles(id) ON DELETE CASCADE,
  status text DEFAULT 'initiated',
  check_type text DEFAULT 'comprehensive',
  provider text,
  external_id text,
  results jsonb DEFAULT '{}',
  completed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Verification documents storage
CREATE TABLE IF NOT EXISTS verification_documents (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  installer_id uuid NOT NULL REFERENCES installer_profiles(id) ON DELETE CASCADE,
  document_type text NOT NULL,
  file_url text NOT NULL,
  file_name text,
  file_size integer,
  mime_type text,
  status text DEFAULT 'uploaded',
  created_at timestamptz DEFAULT now()
);

-- Notifications log
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  type text NOT NULL, -- 'sms', 'push', 'email'
  recipient text NOT NULL, -- phone number, user_id, or email
  title text,
  message text NOT NULL,
  job_id uuid REFERENCES jobs(id),
  data jsonb DEFAULT '{}',
  external_id text, -- Twilio SID, FCM message ID, etc.
  status text DEFAULT 'sent',
  sent_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Push notification tokens
CREATE TABLE IF NOT EXISTS push_tokens (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  token text NOT NULL,
  platform text NOT NULL, -- 'ios', 'android', 'web'
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, token)
);

-- Emergency broadcasts
CREATE TABLE IF NOT EXISTS emergency_broadcasts (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  service_type service_type NOT NULL,
  location point NOT NULL,
  radius_miles integer DEFAULT 25,
  installers_notified integer DEFAULT 0,
  successful_notifications integer DEFAULT 0,
  broadcast_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Autonomous actions log
CREATE TABLE IF NOT EXISTS autonomous_actions (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  action_type text NOT NULL,
  metadata jsonb DEFAULT '{}',
  timestamp timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Fraud detection flags
CREATE TABLE IF NOT EXISTS fraud_flags (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES profiles(id),
  risk_score integer NOT NULL,
  flag_reason text NOT NULL,
  activity_count integer DEFAULT 0,
  auto_flagged boolean DEFAULT false,
  auto_blocked boolean DEFAULT false,
  resolved boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Quality assurance actions
CREATE TABLE IF NOT EXISTS quality_actions (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id uuid NOT NULL REFERENCES jobs(id),
  installer_id uuid NOT NULL REFERENCES installer_profiles(id),
  action_type text NOT NULL,
  rating integer,
  auto_created boolean DEFAULT false,
  resolved boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Installer flags for review
CREATE TABLE IF NOT EXISTS installer_flags (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  installer_id uuid NOT NULL REFERENCES installer_profiles(id),
  flag_type text NOT NULL,
  flag_reason text NOT NULL,
  auto_flagged boolean DEFAULT false,
  resolved boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- User activity log
CREATE TABLE IF NOT EXISTS user_activity_log (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES profiles(id),
  activity_type text NOT NULL,
  metadata jsonb DEFAULT '{}',
  ip_address inet,
  user_agent text,
  created_at timestamptz DEFAULT now()
);

-- Add missing columns to existing tables
DO $$
BEGIN
  -- Add verification status columns to installer_profiles
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'installer_profiles' AND column_name = 'verification_status'
  ) THEN
    ALTER TABLE installer_profiles ADD COLUMN verification_status text DEFAULT 'pending';
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'installer_profiles' AND column_name = 'tax_info_submitted'
  ) THEN
    ALTER TABLE installer_profiles ADD COLUMN tax_info_submitted boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'installer_profiles' AND column_name = 'license_verified'
  ) THEN
    ALTER TABLE installer_profiles ADD COLUMN license_verified boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'installer_profiles' AND column_name = 'photo_verified'
  ) THEN
    ALTER TABLE installer_profiles ADD COLUMN photo_verified boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'installer_profiles' AND column_name = 'last_location_update'
  ) THEN
    ALTER TABLE installer_profiles ADD COLUMN last_location_update timestamptz;
  END IF;
END $$;

-- Enable Row Level Security
ALTER TABLE installer_tax_info ENABLE ROW LEVEL SECURITY;
ALTER TABLE installer_driver_licenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE installer_profile_photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE background_checks ENABLE ROW LEVEL SECURITY;
ALTER TABLE verification_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE push_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE emergency_broadcasts ENABLE ROW LEVEL SECURITY;
ALTER TABLE autonomous_actions ENABLE ROW LEVEL SECURITY;
ALTER TABLE fraud_flags ENABLE ROW LEVEL SECURITY;
ALTER TABLE quality_actions ENABLE ROW LEVEL SECURITY;
ALTER TABLE installer_flags ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_activity_log ENABLE ROW LEVEL SECURITY;

-- RLS Policies

-- Installer tax info - only installer can access their own
CREATE POLICY "Installers can manage own tax info"
  ON installer_tax_info
  FOR ALL
  TO authenticated
  USING (auth.uid() = installer_id);

-- Driver licenses - only installer can access their own
CREATE POLICY "Installers can manage own driver license"
  ON installer_driver_licenses
  FOR ALL
  TO authenticated
  USING (auth.uid() = installer_id);

-- Profile photos - only installer can access their own
CREATE POLICY "Installers can manage own profile photos"
  ON installer_profile_photos
  FOR ALL
  TO authenticated
  USING (auth.uid() = installer_id);

-- Background checks - only installer can read their own
CREATE POLICY "Installers can read own background checks"
  ON background_checks
  FOR SELECT
  TO authenticated
  USING (auth.uid() = installer_id);

-- Verification documents - only installer can access their own
CREATE POLICY "Installers can manage own verification documents"
  ON verification_documents
  FOR ALL
  TO authenticated
  USING (auth.uid() = installer_id);

-- Notifications - users can read their own
CREATE POLICY "Users can read own notifications"
  ON notifications
  FOR SELECT
  TO authenticated
  USING (
    recipient = auth.uid()::text OR 
    recipient IN (
      SELECT phone FROM profiles WHERE id = auth.uid()
    ) OR
    recipient IN (
      SELECT email FROM profiles WHERE id = auth.uid()
    )
  );

-- Push tokens - users can manage their own
CREATE POLICY "Users can manage own push tokens"
  ON push_tokens
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

-- Emergency broadcasts - read only for authenticated users
CREATE POLICY "Authenticated users can read emergency broadcasts"
  ON emergency_broadcasts
  FOR SELECT
  TO authenticated
  USING (true);

-- Autonomous actions - read only for authenticated users
CREATE POLICY "Authenticated users can read autonomous actions"
  ON autonomous_actions
  FOR SELECT
  TO authenticated
  USING (true);

-- Fraud flags - users can read their own
CREATE POLICY "Users can read own fraud flags"
  ON fraud_flags
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Quality actions - installers can read their own
CREATE POLICY "Installers can read own quality actions"
  ON quality_actions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = installer_id);

-- Installer flags - installers can read their own
CREATE POLICY "Installers can read own flags"
  ON installer_flags
  FOR SELECT
  TO authenticated
  USING (auth.uid() = installer_id);

-- User activity log - users can read their own
CREATE POLICY "Users can read own activity log"
  ON user_activity_log
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_installer_tax_info_installer_id ON installer_tax_info (installer_id);
CREATE INDEX IF NOT EXISTS idx_installer_driver_licenses_installer_id ON installer_driver_licenses (installer_id);
CREATE INDEX IF NOT EXISTS idx_installer_profile_photos_installer_id ON installer_profile_photos (installer_id);
CREATE INDEX IF NOT EXISTS idx_background_checks_installer_id ON background_checks (installer_id);
CREATE INDEX IF NOT EXISTS idx_verification_documents_installer_id ON verification_documents (installer_id);
CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON notifications (recipient);
CREATE INDEX IF NOT EXISTS idx_push_tokens_user_id ON push_tokens (user_id);
CREATE INDEX IF NOT EXISTS idx_emergency_broadcasts_location ON emergency_broadcasts USING GIST (location);
CREATE INDEX IF NOT EXISTS idx_fraud_flags_user_id ON fraud_flags (user_id);
CREATE INDEX IF NOT EXISTS idx_quality_actions_installer_id ON quality_actions (installer_id);
CREATE INDEX IF NOT EXISTS idx_installer_flags_installer_id ON installer_flags (installer_id);
CREATE INDEX IF NOT EXISTS idx_user_activity_log_user_id ON user_activity_log (user_id);

-- Add triggers for updated_at
CREATE TRIGGER update_installer_tax_info_updated_at BEFORE UPDATE ON installer_tax_info FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_installer_driver_licenses_updated_at BEFORE UPDATE ON installer_driver_licenses FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_installer_profile_photos_updated_at BEFORE UPDATE ON installer_profile_photos FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_background_checks_updated_at BEFORE UPDATE ON background_checks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_push_tokens_updated_at BEFORE UPDATE ON push_tokens FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();