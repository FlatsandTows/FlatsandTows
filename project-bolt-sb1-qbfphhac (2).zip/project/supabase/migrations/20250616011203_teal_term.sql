/*
  # Initial Schema for Flats & Tows Marketplace

  1. New Tables
    - `profiles` - User profiles for both customers and installers
    - `installer_profiles` - Extended data for installers
    - `services` - Available service types
    - `service_requests` - Customer service requests
    - `bids` - Installer bids on service requests
    - `jobs` - Accepted jobs and their status
    - `payments` - Payment records and transactions
    - `reviews` - Customer reviews and ratings
    - `disputes` - Dispute management
    - `referrals` - Referral tracking
    - `memberships` - VIP membership management

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Secure data access based on user roles
*/

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- Create enum types
CREATE TYPE user_role AS ENUM ('customer', 'installer', 'admin');
CREATE TYPE service_type AS ENUM ('tire', 'battery', 'towing', 'lockout', 'fuel', 'mechanic');
CREATE TYPE request_status AS ENUM ('pending', 'bidding', 'assigned', 'in_progress', 'completed', 'cancelled', 'disputed');
CREATE TYPE bid_status AS ENUM ('pending', 'accepted', 'rejected', 'expired');
CREATE TYPE payment_status AS ENUM ('pending', 'processing', 'completed', 'failed', 'refunded');
CREATE TYPE dispute_status AS ENUM ('open', 'investigating', 'resolved', 'escalated');
CREATE TYPE membership_type AS ENUM ('free', 'vip', 'premium');

-- Profiles table (extends auth.users)
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text,
  phone text,
  role user_role DEFAULT 'customer',
  avatar_url text,
  location point,
  address text,
  city text,
  state text,
  zip_code text,
  is_verified boolean DEFAULT false,
  membership_type membership_type DEFAULT 'free',
  membership_expires_at timestamptz,
  referral_code text UNIQUE,
  referred_by uuid REFERENCES profiles(id),
  total_referral_earnings decimal(10,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Installer profiles table
CREATE TABLE IF NOT EXISTS installer_profiles (
  id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  business_name text NOT NULL,
  license_number text,
  insurance_policy text,
  specialties service_type[] DEFAULT '{}',
  service_radius integer DEFAULT 25, -- miles
  base_rates jsonb DEFAULT '{}', -- {"tire": 55, "battery": 45, etc}
  is_premium boolean DEFAULT false,
  premium_badge text,
  is_online boolean DEFAULT false,
  current_location point,
  vehicle_info jsonb DEFAULT '{}',
  tools_equipment text[],
  response_time_avg integer DEFAULT 15, -- minutes
  completion_rate decimal(3,2) DEFAULT 0.00,
  total_jobs integer DEFAULT 0,
  total_earnings decimal(10,2) DEFAULT 0,
  stripe_account_id text,
  auto_accept_jobs boolean DEFAULT false,
  max_concurrent_jobs integer DEFAULT 3,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Services table
CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  type service_type NOT NULL,
  name text NOT NULL,
  description text,
  base_price decimal(8,2) NOT NULL,
  estimated_duration integer, -- minutes
  is_emergency boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Service requests table
CREATE TABLE IF NOT EXISTS service_requests (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  customer_id uuid NOT NULL REFERENCES profiles(id),
  service_type service_type NOT NULL,
  status request_status DEFAULT 'pending',
  location point NOT NULL,
  address text NOT NULL,
  description text,
  urgency_level integer DEFAULT 1, -- 1-5 scale
  photos text[], -- URLs to uploaded photos
  preferred_arrival_time timestamptz,
  max_budget decimal(8,2),
  surge_multiplier decimal(3,2) DEFAULT 1.00,
  platform_fee_rate decimal(3,2) DEFAULT 0.12,
  bidding_ends_at timestamptz,
  assigned_installer_id uuid REFERENCES installer_profiles(id),
  estimated_completion timestamptz,
  actual_completion timestamptz,
  customer_notes text,
  installer_notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Bids table
CREATE TABLE IF NOT EXISTS bids (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  request_id uuid NOT NULL REFERENCES service_requests(id) ON DELETE CASCADE,
  installer_id uuid NOT NULL REFERENCES installer_profiles(id),
  price decimal(8,2) NOT NULL,
  estimated_arrival integer NOT NULL, -- minutes
  message text,
  status bid_status DEFAULT 'pending',
  expires_at timestamptz NOT NULL,
  match_score integer, -- AI matching score 0-100
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(request_id, installer_id)
);

-- Jobs table
CREATE TABLE IF NOT EXISTS jobs (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  request_id uuid NOT NULL REFERENCES service_requests(id),
  installer_id uuid NOT NULL REFERENCES installer_profiles(id),
  customer_id uuid NOT NULL REFERENCES profiles(id),
  bid_id uuid REFERENCES bids(id),
  service_type service_type NOT NULL,
  status request_status DEFAULT 'assigned',
  agreed_price decimal(8,2) NOT NULL,
  platform_fee decimal(8,2) NOT NULL,
  processing_fee decimal(8,2) DEFAULT 2.99,
  installer_payout decimal(8,2) NOT NULL,
  started_at timestamptz,
  completed_at timestamptz,
  location point NOT NULL,
  address text NOT NULL,
  customer_rating integer, -- 1-5 stars
  installer_rating integer, -- 1-5 stars
  customer_review text,
  installer_review text,
  photos_before text[],
  photos_after text[],
  additional_services jsonb DEFAULT '{}',
  tip_amount decimal(8,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Payments table
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id uuid NOT NULL REFERENCES jobs(id),
  customer_id uuid NOT NULL REFERENCES profiles(id),
  installer_id uuid NOT NULL REFERENCES installer_profiles(id),
  stripe_payment_intent_id text UNIQUE,
  stripe_transfer_id text,
  amount decimal(8,2) NOT NULL,
  platform_fee decimal(8,2) NOT NULL,
  processing_fee decimal(8,2) NOT NULL,
  installer_payout decimal(8,2) NOT NULL,
  status payment_status DEFAULT 'pending',
  payment_method jsonb,
  paid_at timestamptz,
  payout_at timestamptz,
  refunded_at timestamptz,
  refund_amount decimal(8,2),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id uuid NOT NULL REFERENCES jobs(id),
  reviewer_id uuid NOT NULL REFERENCES profiles(id),
  reviewee_id uuid NOT NULL REFERENCES profiles(id),
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review_text text,
  photos text[],
  is_public boolean DEFAULT true,
  helpful_votes integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Disputes table
CREATE TABLE IF NOT EXISTS disputes (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id uuid NOT NULL REFERENCES jobs(id),
  initiated_by uuid NOT NULL REFERENCES profiles(id),
  dispute_type text NOT NULL,
  description text NOT NULL,
  status dispute_status DEFAULT 'open',
  resolution_action text,
  resolution_amount decimal(8,2),
  resolved_by uuid REFERENCES profiles(id),
  resolved_at timestamptz,
  auto_resolved boolean DEFAULT false,
  evidence_photos text[],
  admin_notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Referrals table
CREATE TABLE IF NOT EXISTS referrals (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  referrer_id uuid NOT NULL REFERENCES profiles(id),
  referee_id uuid NOT NULL REFERENCES profiles(id),
  referral_code text NOT NULL,
  commission_rate decimal(3,2) DEFAULT 0.03, -- 3%
  total_earned decimal(8,2) DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Memberships table
CREATE TABLE IF NOT EXISTS memberships (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES profiles(id),
  type membership_type NOT NULL,
  stripe_subscription_id text UNIQUE,
  starts_at timestamptz NOT NULL,
  expires_at timestamptz,
  is_active boolean DEFAULT true,
  benefits jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Insert default services
INSERT INTO services (type, name, description, base_price, estimated_duration, is_emergency) VALUES
('tire', 'Tire Emergency', 'Flat tire repair or replacement', 55.00, 30, true),
('battery', 'Dead Battery', 'Jump start or battery replacement', 45.00, 20, true),
('towing', 'Vehicle Towing', 'Emergency towing service', 120.00, 45, false),
('lockout', 'Vehicle Lockout', 'Unlock your vehicle', 65.00, 15, true),
('fuel', 'Out of Gas', 'Emergency fuel delivery', 35.00, 20, false),
('mechanic', 'Mobile Mechanic', 'On-site vehicle repair', 85.00, 60, false);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE installer_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE bids ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE disputes ENABLE ROW LEVEL SECURITY;
ALTER TABLE referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE memberships ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can read own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Installer profiles policies
CREATE POLICY "Anyone can read installer profiles"
  ON installer_profiles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Installers can update own profile"
  ON installer_profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Installers can insert own profile"
  ON installer_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Services policies (public read)
CREATE POLICY "Anyone can read services"
  ON services
  FOR SELECT
  TO authenticated
  USING (true);

-- Service requests policies
CREATE POLICY "Customers can manage own requests"
  ON service_requests
  FOR ALL
  TO authenticated
  USING (auth.uid() = customer_id);

CREATE POLICY "Installers can read active requests"
  ON service_requests
  FOR SELECT
  TO authenticated
  USING (status IN ('pending', 'bidding'));

-- Bids policies
CREATE POLICY "Installers can manage own bids"
  ON bids
  FOR ALL
  TO authenticated
  USING (auth.uid() = installer_id);

CREATE POLICY "Customers can read bids on their requests"
  ON bids
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM service_requests 
      WHERE id = bids.request_id 
      AND customer_id = auth.uid()
    )
  );

-- Jobs policies
CREATE POLICY "Users can read own jobs"
  ON jobs
  FOR SELECT
  TO authenticated
  USING (auth.uid() = customer_id OR auth.uid() = installer_id);

CREATE POLICY "Users can update own jobs"
  ON jobs
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = customer_id OR auth.uid() = installer_id);

-- Payments policies
CREATE POLICY "Users can read own payments"
  ON payments
  FOR SELECT
  TO authenticated
  USING (auth.uid() = customer_id OR auth.uid() = installer_id);

-- Reviews policies
CREATE POLICY "Anyone can read public reviews"
  ON reviews
  FOR SELECT
  TO authenticated
  USING (is_public = true);

CREATE POLICY "Users can create reviews for their jobs"
  ON reviews
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = reviewer_id);

-- Disputes policies
CREATE POLICY "Users can read own disputes"
  ON disputes
  FOR SELECT
  TO authenticated
  USING (auth.uid() = initiated_by);

CREATE POLICY "Users can create disputes for their jobs"
  ON disputes
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = initiated_by);

-- Referrals policies
CREATE POLICY "Users can read own referrals"
  ON referrals
  FOR SELECT
  TO authenticated
  USING (auth.uid() = referrer_id OR auth.uid() = referee_id);

-- Memberships policies
CREATE POLICY "Users can read own memberships"
  ON memberships
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX idx_profiles_location ON profiles USING GIST (location);
CREATE INDEX idx_installer_profiles_location ON installer_profiles USING GIST (current_location);
CREATE INDEX idx_service_requests_location ON service_requests USING GIST (location);
CREATE INDEX idx_service_requests_status ON service_requests (status);
CREATE INDEX idx_bids_request_id ON bids (request_id);
CREATE INDEX idx_jobs_customer_id ON jobs (customer_id);
CREATE INDEX idx_jobs_installer_id ON jobs (installer_id);
CREATE INDEX idx_payments_job_id ON payments (job_id);
CREATE INDEX idx_reviews_reviewee_id ON reviews (reviewee_id);

-- Create functions for automatic updates
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Add triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_installer_profiles_updated_at BEFORE UPDATE ON installer_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_service_requests_updated_at BEFORE UPDATE ON service_requests FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_bids_updated_at BEFORE UPDATE ON bids FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_jobs_updated_at BEFORE UPDATE ON jobs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_payments_updated_at BEFORE UPDATE ON payments FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_disputes_updated_at BEFORE UPDATE ON disputes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_memberships_updated_at BEFORE UPDATE ON memberships FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();