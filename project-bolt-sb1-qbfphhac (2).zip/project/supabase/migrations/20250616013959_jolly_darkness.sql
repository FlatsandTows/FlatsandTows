/*
  # Add Missing PostGIS Functions and Enhancements

  1. PostGIS Functions
    - get_nearby_installers function for location-based search
    - calculate_distance function for distance calculations
  
  2. Additional Columns
    - Add missing Stripe-related columns to installer_profiles
    - Add location indexing improvements
  
  3. Performance Optimizations
    - Additional indexes for common queries
    - Materialized views for analytics
*/

-- Add missing columns to installer_profiles
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'installer_profiles' AND column_name = 'stripe_onboarding_complete'
  ) THEN
    ALTER TABLE installer_profiles ADD COLUMN stripe_onboarding_complete boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'installer_profiles' AND column_name = 'stripe_charges_enabled'
  ) THEN
    ALTER TABLE installer_profiles ADD COLUMN stripe_charges_enabled boolean DEFAULT false;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'installer_profiles' AND column_name = 'stripe_payouts_enabled'
  ) THEN
    ALTER TABLE installer_profiles ADD COLUMN stripe_payouts_enabled boolean DEFAULT false;
  END IF;
END $$;

-- Function to calculate distance between two points
CREATE OR REPLACE FUNCTION calculate_distance(
  lat1 FLOAT,
  lng1 FLOAT,
  lat2 FLOAT,
  lng2 FLOAT
)
RETURNS FLOAT AS $$
BEGIN
  RETURN ST_Distance(
    ST_GeogFromText('POINT(' || lng1 || ' ' || lat1 || ')'),
    ST_GeogFromText('POINT(' || lng2 || ' ' || lat2 || ')')
  ) * 0.000621371; -- Convert meters to miles
END;
$$ LANGUAGE plpgsql;

-- Function to get nearby installers with enhanced filtering
CREATE OR REPLACE FUNCTION get_nearby_installers(
  user_lat FLOAT,
  user_lng FLOAT,
  radius_miles FLOAT DEFAULT 25,
  service_type_filter TEXT DEFAULT NULL,
  is_online_only BOOLEAN DEFAULT true,
  limit_count INTEGER DEFAULT 50
)
RETURNS TABLE(
  id UUID,
  business_name TEXT,
  specialties service_type[],
  is_premium BOOLEAN,
  is_online BOOLEAN,
  current_location POINT,
  distance_miles FLOAT,
  response_time_avg INTEGER,
  completion_rate DECIMAL,
  total_jobs INTEGER,
  base_rates JSONB,
  stripe_account_id TEXT,
  stripe_onboarding_complete BOOLEAN
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    ip.id,
    ip.business_name,
    ip.specialties,
    ip.is_premium,
    ip.is_online,
    ip.current_location,
    calculate_distance(
      user_lat, 
      user_lng, 
      ST_Y(ip.current_location::geometry), 
      ST_X(ip.current_location::geometry)
    ) as distance_miles,
    ip.response_time_avg,
    ip.completion_rate,
    ip.total_jobs,
    ip.base_rates,
    ip.stripe_account_id,
    ip.stripe_onboarding_complete
  FROM installer_profiles ip
  WHERE 
    ip.current_location IS NOT NULL
    AND (NOT is_online_only OR ip.is_online = true)
    AND (service_type_filter IS NULL OR service_type_filter::service_type = ANY(ip.specialties))
    AND calculate_distance(
      user_lat, 
      user_lng, 
      ST_Y(ip.current_location::geometry), 
      ST_X(ip.current_location::geometry)
    ) <= radius_miles
    AND ip.stripe_onboarding_complete = true
  ORDER BY 
    ip.is_premium DESC,
    distance_miles ASC,
    ip.completion_rate DESC
  LIMIT limit_count;
END;
$$ LANGUAGE plpgsql;

-- Function to update installer location
CREATE OR REPLACE FUNCTION update_installer_location(
  installer_id UUID,
  new_lat FLOAT,
  new_lng FLOAT
)
RETURNS BOOLEAN AS $$
BEGIN
  UPDATE installer_profiles 
  SET 
    current_location = ST_Point(new_lng, new_lat),
    updated_at = now()
  WHERE id = installer_id;
  
  RETURN FOUND;
END;
$$ LANGUAGE plpgsql;

-- Function to calculate surge pricing
CREATE OR REPLACE FUNCTION calculate_surge_multiplier(
  service_location POINT,
  service_type_param service_type,
  request_time TIMESTAMPTZ DEFAULT now()
)
RETURNS DECIMAL AS $$
DECLARE
  base_multiplier DECIMAL := 1.0;
  hour_of_day INTEGER;
  day_of_week INTEGER;
  nearby_requests INTEGER;
  available_installers INTEGER;
BEGIN
  -- Get time factors
  hour_of_day := EXTRACT(HOUR FROM request_time);
  day_of_week := EXTRACT(DOW FROM request_time);
  
  -- Rush hour multiplier (7-9 AM, 5-7 PM)
  IF (hour_of_day BETWEEN 7 AND 9) OR (hour_of_day BETWEEN 17 AND 19) THEN
    base_multiplier := base_multiplier * 1.4;
  END IF;
  
  -- Night premium (10 PM - 6 AM)
  IF hour_of_day >= 22 OR hour_of_day <= 6 THEN
    base_multiplier := base_multiplier * 1.6;
  END IF;
  
  -- Weekend premium
  IF day_of_week IN (0, 6) THEN
    base_multiplier := base_multiplier * 1.2;
  END IF;
  
  -- Demand-based surge
  SELECT COUNT(*) INTO nearby_requests
  FROM service_requests sr
  WHERE 
    sr.status IN ('pending', 'bidding')
    AND sr.service_type = service_type_param
    AND ST_DWithin(
      sr.location::geography,
      service_location::geography,
      8047 -- 5 miles in meters
    )
    AND sr.created_at > (request_time - INTERVAL '1 hour');
  
  -- Available installers in area
  SELECT COUNT(*) INTO available_installers
  FROM installer_profiles ip
  WHERE 
    ip.is_online = true
    AND service_type_param = ANY(ip.specialties)
    AND ST_DWithin(
      ip.current_location::geography,
      service_location::geography,
      40234 -- 25 miles in meters
    );
  
  -- Apply demand surge
  IF available_installers > 0 AND nearby_requests > available_installers THEN
    base_multiplier := base_multiplier * (1.0 + (nearby_requests::DECIMAL / available_installers::DECIMAL) * 0.3);
  END IF;
  
  -- Cap at 3.0x
  RETURN LEAST(base_multiplier, 3.0);
END;
$$ LANGUAGE plpgsql;

-- Function to auto-match installers to requests
CREATE OR REPLACE FUNCTION auto_match_installers(request_id UUID)
RETURNS TABLE(installer_id UUID, match_score INTEGER) AS $$
DECLARE
  request_record service_requests%ROWTYPE;
BEGIN
  -- Get request details
  SELECT * INTO request_record FROM service_requests WHERE id = request_id;
  
  RETURN QUERY
  SELECT 
    ip.id as installer_id,
    (
      -- Base score
      50 +
      -- Distance score (closer = higher)
      GREATEST(0, 25 - CAST(calculate_distance(
        ST_Y(request_record.location::geometry),
        ST_X(request_record.location::geometry),
        ST_Y(ip.current_location::geometry),
        ST_X(ip.current_location::geometry)
      ) AS INTEGER)) +
      -- Premium installer bonus
      CASE WHEN ip.is_premium THEN 15 ELSE 0 END +
      -- Completion rate bonus
      CAST(ip.completion_rate * 10 AS INTEGER) +
      -- Experience bonus
      LEAST(10, ip.total_jobs / 10)
    ) as match_score
  FROM installer_profiles ip
  WHERE 
    ip.is_online = true
    AND request_record.service_type = ANY(ip.specialties)
    AND ip.stripe_onboarding_complete = true
    AND calculate_distance(
      ST_Y(request_record.location::geometry),
      ST_X(request_record.location::geometry),
      ST_Y(ip.current_location::geometry),
      ST_X(ip.current_location::geometry)
    ) <= ip.service_radius
  ORDER BY match_score DESC
  LIMIT 10;
END;
$$ LANGUAGE plpgsql;

-- Create additional performance indexes
CREATE INDEX IF NOT EXISTS idx_installer_profiles_online_specialties 
ON installer_profiles (is_online, specialties) 
WHERE is_online = true;

CREATE INDEX IF NOT EXISTS idx_service_requests_status_type 
ON service_requests (status, service_type);

CREATE INDEX IF NOT EXISTS idx_bids_status_price 
ON bids (status, price) 
WHERE status = 'pending';

CREATE INDEX IF NOT EXISTS idx_jobs_status_created 
ON jobs (status, created_at);

-- Create materialized view for installer analytics
CREATE MATERIALIZED VIEW IF NOT EXISTS installer_analytics AS
SELECT 
  ip.id,
  ip.business_name,
  ip.total_jobs,
  ip.total_earnings,
  ip.completion_rate,
  ip.response_time_avg,
  COUNT(j.id) as jobs_last_30_days,
  AVG(j.customer_rating) as avg_rating_30_days,
  SUM(p.installer_payout) as earnings_last_30_days
FROM installer_profiles ip
LEFT JOIN jobs j ON j.installer_id = ip.id 
  AND j.created_at > (now() - INTERVAL '30 days')
LEFT JOIN payments p ON p.job_id = j.id 
  AND p.status = 'completed'
GROUP BY ip.id, ip.business_name, ip.total_jobs, ip.total_earnings, 
         ip.completion_rate, ip.response_time_avg;

-- Create index on materialized view
CREATE UNIQUE INDEX IF NOT EXISTS idx_installer_analytics_id 
ON installer_analytics (id);

-- Function to refresh analytics (call this periodically)
CREATE OR REPLACE FUNCTION refresh_installer_analytics()
RETURNS VOID AS $$
BEGIN
  REFRESH MATERIALIZED VIEW CONCURRENTLY installer_analytics;
END;
$$ LANGUAGE plpgsql;